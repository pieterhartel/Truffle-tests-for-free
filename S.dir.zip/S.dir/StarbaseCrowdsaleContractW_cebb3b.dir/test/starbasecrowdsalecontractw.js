const StarbaseCrowdsaleContractW = artifacts.require( "./StarbaseCrowdsaleContractW.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "StarbaseCrowdsaleContractW" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x54c548703C6F423cf7ED22806B608d332FceBB3b", "0xC00cc57df9F1Fe1EBc9Eb660e7B98A6E7CbCFF21", "0xF70a642bD387F94380fFb90451C2c81d4Eb82CBc", "0x4F4e76761eb0a5A2992A6f3Ab1C90A874450EcCa", "0xE3472B100fa844ada53cF79b998a1A7BA31E4d95", "0x00a18486eC14de7946d538178AC0BB9e183D51Cf", "0x012D78b8ae3effb27D1A177cb14B2776562AA192", "0x8A6B81dB368C07bdE2A7a943BeC7649367AfA6a4", "0xB9F9D6B531546E4c80058BEe5749D72ffC76b54F", "0x008461b96A04895433FE547f28D7728Bc1d03b90", "0x385812B8367faB03aE57fDF2B1022948901417BE", "0x49d4cb2688dC10c451DC8faeE39c33F0feD8892D", "0x2F08fd787d40d254706D2f919E8B2dC60633255D", "0xC8AEC25691CE21Dcc905855C1162bF0bdCE8CD55", "0x095f850EeC0522B2E269aEa9DeDE4BC6967378F6", "0x0073d1F72CFaB3C02D0c48eF5DbB42798930CBF2", "0xabcEe54A5917505B4d9f57abB634A29CbD22E987", "0xC8912237e3219838C2349067c54f18C5162Fbf0d", "0xd8a48C0053af4997c768F059c7C697d8f7857fdA", "0x54e27782bc1a4b54a261B9aee7040354B1334841", "0x3dbe0A3e0fa494C5c012cf5b6B2caa5eD5312376", "0x6a9054EfcA894Cda71B0A71a6055e1E40F7cb7E0", "0x1C4Ba011e13f2f735Dee87c7801001eF5e7348D0", "0x56581592b526406391494002BDD9b664BD7980C2", "0x2B51e24E3Ce2a75956e0eFE4b9fd744685f8aCfb", "0x99752bAC97008d6bc2a6946d62378920b47563dE", "0xEe5905cD4C89C0cB178Aeb12A4BCD26e9Ea47d72", "0x4cEAf6b478432B21D6e1C4247E9Bbfb420177751", "0x7dAfD53AEE8982aB1D767830c2fe50f62E3a98E6", "0xDB476022B386999023bA303E3004B4E98A0E2e3A", "0xB1Fe569478506aeFEC2bcc84321e8d2053FE3fBB", "0x004FbF4dcB63D94b9B807274141DDE45994aed2c", "0xA5F66EaFB02Db5ccAcc4af8AdB536090C362f9B6"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}], name: "earlyPurchasedAmountBy", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startDate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "crowdsaleTokenAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "earlyPurchasesLoaded", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endedAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numOfLoadedCrowdsalePurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numOfLoadedEarlyPurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalRaisedAmountInCny", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "numOfPurchasedTokensOnEpBy", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "earlyPurchaseTokenAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "crowdsalePurchasesLoaded", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "starbaseEpAmendment", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "crowdsalePurchaseAmountBy", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "numOfPurchasedTokensOnCsBy", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "starbaseCrowdsale", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numOfDeliveredCrowdsalePurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numOfDeliveredEarlyPurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isEnded", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "earlyPurchasers", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokenWithdrawn", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalAmountOfCrowdsalePurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "starbaseToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalAmountOfEarlyPurchases", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "purchasedAmount", type: "uint256"}, {name: "rawAmount", type: "uint256"}, {name: "bonusBegin", type: "uint256"}, {name: "bonusEnd", type: "uint256"}, {name: "bonusTier", type: "uint256"}], name: "calculateBonusInRange", outputs: [{name: "bonus", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalAmountOfCrowdsalePurchasesWithoutBonus", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalAmountOfPresalePurchasesWithoutBonus", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "purchaseIdx", type: "uint256"}, {indexed: false, name: "rawAmount", type: "uint256"}, {indexed: false, name: "bonus", type: "uint256"}], name: "CrowdsalePurchaseBonusLog", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TokenWithdrawn(address,uint256)", "CrowdsalePurchaseBonusLog(uint256,uint256,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xa2bd9fcfcdba69f52bcd9a520846ad4bd685b187483f53efc42d035b2ddebff0", "0x6c33d023cecbdd7196dd93d7ec61a6abd788d04db1aaf47f40e1d0d95d5bd63d", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4556333 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4615010 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "StarbaseCrowdsaleContractW", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "earlyPurchasedAmountBy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyPurchasedAmountBy(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startDate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startDate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "crowdsaleTokenAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "crowdsaleTokenAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "earlyPurchasesLoaded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyPurchasesLoaded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endedAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endedAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numOfLoadedCrowdsalePurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numOfLoadedCrowdsalePurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numOfLoadedEarlyPurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numOfLoadedEarlyPurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalRaisedAmountInCny", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalRaisedAmountInCny()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "numOfPurchasedTokensOnEpBy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numOfPurchasedTokensOnEpBy(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "earlyPurchaseTokenAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyPurchaseTokenAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "crowdsalePurchasesLoaded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "crowdsalePurchasesLoaded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "starbaseEpAmendment", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "starbaseEpAmendment()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "crowdsalePurchaseAmountBy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "crowdsalePurchaseAmountBy(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "numOfPurchasedTokensOnCsBy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numOfPurchasedTokensOnCsBy(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "starbaseCrowdsale", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "starbaseCrowdsale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numOfDeliveredCrowdsalePurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numOfDeliveredCrowdsalePurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numOfDeliveredEarlyPurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numOfDeliveredEarlyPurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isEnded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isEnded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "earlyPurchasers", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyPurchasers(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenWithdrawn", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenWithdrawn(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalAmountOfCrowdsalePurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalAmountOfCrowdsalePurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "starbaseToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "starbaseToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalAmountOfEarlyPurchases", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalAmountOfEarlyPurchases()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "purchasedAmount", value: random.range( maxRandom )}, {type: "uint256", name: "rawAmount", value: random.range( maxRandom )}, {type: "uint256", name: "bonusBegin", value: random.range( maxRandom )}, {type: "uint256", name: "bonusEnd", value: random.range( maxRandom )}, {type: "uint256", name: "bonusTier", value: random.range( maxRandom )}], name: "calculateBonusInRange", outputs: [{name: "bonus", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateBonusInRange(uint256,uint256,uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value,methodCall.inputs[ 4 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalAmountOfCrowdsalePurchasesWithoutBonus", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalAmountOfCrowdsalePurchasesWithoutBonus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalAmountOfPresalePurchasesWithoutBonus", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalAmountOfPresalePurchasesWithoutBonus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "StarbaseCrowdsaleContractW", function( accounts ) {

	it( "TEST: StarbaseCrowdsaleContractW(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4556333", timeStamp: "1510735802", hash: "0xd33e66ebd460a080c758d5024fcbeb6c2fdc79c5a3cd3ec3b00b93053c2099d3", nonce: "159", blockHash: "0x6201a1a6c437793f8df3b194521602fbb01bda916885c81b4d9e6559a51dc26b", transactionIndex: "57", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: 0, value: "0", gas: "4712388", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x54d9df1b", contractAddress: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", cumulativeGasUsed: "3676657", gasUsed: "1816896", confirmations: "3185845"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "StarbaseCrowdsaleContractW", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = StarbaseCrowdsaleContractW.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510735802 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = StarbaseCrowdsaleContractW.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addEarlyPurchases(  )", async function( ) {
		const txOriginal = {blockNumber: "4556342", timeStamp: "1510735962", hash: "0x90b37578a4109ad2c3d939d2bb2299a38404e3982912d1a1db12093d54594f9c", nonce: "160", blockHash: "0xf7809ca9cf6953ade6f152f354f56d2f39db01180b6f87a58e44e6b7a08dde7e", transactionIndex: "12", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "4712388", gasPrice: "5000000000", isError: "0", txreceipt_status: "0", input: "0xfeb4ad89", contractAddress: "", cumulativeGasUsed: "1185726", gasUsed: "23862", confirmations: "3185836"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "addEarlyPurchases", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addEarlyPurchases()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510735962 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setup( addressList[4], addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4614026", timeStamp: "1511539448", hash: "0xf9fc4c957443ab9f7c17dcf4f4e0c56895804a1a80b9b2b05c8f55c38eea7d33", nonce: "164", blockHash: "0x3143c4e0a8cd3a6d412c1b280f91b90fc69caa7717eae70231bb4588883d9f8d", transactionIndex: "25", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x2d34ba79000000000000000000000000f70a642bd387f94380ffb90451c2c81d4eb82cbc0000000000000000000000004f4e76761eb0a5a2992a6f3ab1c90a874450ecca", contractAddress: "", cumulativeGasUsed: "795739", gasUsed: "138821", confirmations: "3128152"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "starbaseTokenAddress", value: addressList[4]}, {type: "address", name: "StarbaseCrowdsaleAddress", value: addressList[5]}], name: "setup", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setup(address,address)" ]( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1511539448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addEarlyPurchases(  )", async function( ) {
		const txOriginal = {blockNumber: "4614032", timeStamp: "1511539566", hash: "0x60573dab11d1b5fa11ca996d1183f46e1ba4a0b09d3d2f4f0d049563259c8c44", nonce: "165", blockHash: "0xa6d272a6e9592ebda8f03c5872eaf8272266746650afa8f3463454e89505b464", transactionIndex: "29", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfeb4ad89", contractAddress: "", cumulativeGasUsed: "6516661", gasUsed: "5848835", confirmations: "3128146"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "addEarlyPurchases", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addEarlyPurchases()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1511539566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614035", timeStamp: "1511539598", hash: "0x85302b3e5a054efe9c32eb0322581177cbed6514b5a8f5e08a865edeeffa7a1d", nonce: "5", blockHash: "0x937ae36de9f93343fece4d49c79399247cf03b817b2496bcadd85bb7b10997ca", transactionIndex: "2", from: "0xe3472b100fa844ada53cf79b998a1a7ba31e4d95", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "200000", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "95943", gasUsed: "22758", confirmations: "3128143"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1511539598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addEarlyPurchases(  )", async function( ) {
		const txOriginal = {blockNumber: "4614040", timeStamp: "1511539643", hash: "0xe139b8fd8199ee0e68bf93dcbabba9e0978f3703a0d26613de345ad2f25fedc7", nonce: "166", blockHash: "0x6345de967f23195eb496b6e091473da1752b2c0fb9b2baf96b967ab03023b9bb", transactionIndex: "4", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfeb4ad89", contractAddress: "", cumulativeGasUsed: "5987836", gasUsed: "5829815", confirmations: "3128138"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "addEarlyPurchases", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addEarlyPurchases()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1511539643 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addEarlyPurchases(  )", async function( ) {
		const txOriginal = {blockNumber: "4614060", timeStamp: "1511539909", hash: "0x260e5edfd03c6f3c8a4d537ed36ef87ddecfdcc2fd2304d6129e9a4b730323f8", nonce: "167", blockHash: "0x32fb39e5beac85e719522b4d6253444764571fb7a4fbab8edf8244a56d77ac9c", transactionIndex: "5", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfeb4ad89", contractAddress: "", cumulativeGasUsed: "1100794", gasUsed: "971689", confirmations: "3128118"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "addEarlyPurchases", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addEarlyPurchases()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1511539909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614064", timeStamp: "1511539968", hash: "0x14c0f0563f115bbc0319efc85a1a03aaaba4e47dc264dd57feecfbbd83be35f7", nonce: "168", blockHash: "0x1738ced032f960391008cff65803ef616cb3f6cc9b142a6d57c13492e6df3b82", transactionIndex: "18", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "6449280", gasUsed: "5850753", confirmations: "3128114"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1511539968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaseIdx", type: "uint256"}, {indexed: false, name: "rawAmount", type: "uint256"}, {indexed: false, name: "bonus", type: "uint256"}], name: "CrowdsalePurchaseBonusLog", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "0"}, {name: "rawAmount", type: "uint256", value: "1974"}, {name: "bonus", type: "uint256", value: "592"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "1"}, {name: "rawAmount", type: "uint256", value: "1991766"}, {name: "bonus", type: "uint256", value: "597529"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "2"}, {name: "rawAmount", type: "uint256", value: "2390"}, {name: "bonus", type: "uint256", value: "717"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "3"}, {name: "rawAmount", type: "uint256", value: "13386965"}, {name: "bonus", type: "uint256", value: "4016089"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "4"}, {name: "rawAmount", type: "uint256", value: "2158"}, {name: "bonus", type: "uint256", value: "647"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "5"}, {name: "rawAmount", type: "uint256", value: "32899198"}, {name: "bonus", type: "uint256", value: "9869759"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "6"}, {name: "rawAmount", type: "uint256", value: "12168"}, {name: "bonus", type: "uint256", value: "2433"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "7"}, {name: "rawAmount", type: "uint256", value: "279"}, {name: "bonus", type: "uint256", value: "55"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "8"}, {name: "rawAmount", type: "uint256", value: "588"}, {name: "bonus", type: "uint256", value: "117"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "9"}, {name: "rawAmount", type: "uint256", value: "1016"}, {name: "bonus", type: "uint256", value: "203"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "10"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "811"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "11"}, {name: "rawAmount", type: "uint256", value: "3346"}, {name: "bonus", type: "uint256", value: "669"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "12"}, {name: "rawAmount", type: "uint256", value: "11559"}, {name: "bonus", type: "uint256", value: "2311"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "13"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "14"}, {name: "rawAmount", type: "uint256", value: "11356"}, {name: "bonus", type: "uint256", value: "2271"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "15"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "16"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "17"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "18"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "19"}, {name: "rawAmount", type: "uint256", value: "46644"}, {name: "bonus", type: "uint256", value: "9328"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "20"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "21"}, {name: "rawAmount", type: "uint256", value: "2230"}, {name: "bonus", type: "uint256", value: "446"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "22"}, {name: "rawAmount", type: "uint256", value: "3042"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "23"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "24"}, {name: "rawAmount", type: "uint256", value: "35692"}, {name: "bonus", type: "uint256", value: "7138"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "25"}, {name: "rawAmount", type: "uint256", value: "12776"}, {name: "bonus", type: "uint256", value: "2555"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "26"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "27"}, {name: "rawAmount", type: "uint256", value: "600288"}, {name: "bonus", type: "uint256", value: "120057"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "28"}, {name: "rawAmount", type: "uint256", value: "527"}, {name: "bonus", type: "uint256", value: "105"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "29"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "1014"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "30"}, {name: "rawAmount", type: "uint256", value: "993"}, {name: "bonus", type: "uint256", value: "198"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "31"}, {name: "rawAmount", type: "uint256", value: "212"}, {name: "bonus", type: "uint256", value: "42"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "32"}, {name: "rawAmount", type: "uint256", value: "202800"}, {name: "bonus", type: "uint256", value: "40560"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "33"}, {name: "rawAmount", type: "uint256", value: "507"}, {name: "bonus", type: "uint256", value: "101"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "34"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "35"}, {name: "rawAmount", type: "uint256", value: "202800"}, {name: "bonus", type: "uint256", value: "40560"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "36"}, {name: "rawAmount", type: "uint256", value: "33462"}, {name: "bonus", type: "uint256", value: "6692"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "37"}, {name: "rawAmount", type: "uint256", value: "9024"}, {name: "bonus", type: "uint256", value: "1804"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "38"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "39"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "40"}, {name: "rawAmount", type: "uint256", value: "22308"}, {name: "bonus", type: "uint256", value: "4461"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "41"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "42"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "43"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "121"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "44"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "45"}, {name: "rawAmount", type: "uint256", value: "2879"}, {name: "bonus", type: "uint256", value: "575"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "46"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "47"}, {name: "rawAmount", type: "uint256", value: "3650"}, {name: "bonus", type: "uint256", value: "730"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "48"}, {name: "rawAmount", type: "uint256", value: "11154"}, {name: "bonus", type: "uint256", value: "2230"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "49"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "50"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "202"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "51"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "81"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "52"}, {name: "rawAmount", type: "uint256", value: "2433"}, {name: "bonus", type: "uint256", value: "486"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "53"}, {name: "rawAmount", type: "uint256", value: "40560"}, {name: "bonus", type: "uint256", value: "8112"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "54"}, {name: "rawAmount", type: "uint256", value: "101400"}, {name: "bonus", type: "uint256", value: "20280"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "55"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "56"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "57"}, {name: "rawAmount", type: "uint256", value: "1622"}, {name: "bonus", type: "uint256", value: "324"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "58"}, {name: "rawAmount", type: "uint256", value: "21496"}, {name: "bonus", type: "uint256", value: "4299"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "59"}, {name: "rawAmount", type: "uint256", value: "7909"}, {name: "bonus", type: "uint256", value: "1581"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "60"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "61"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "811"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "62"}, {name: "rawAmount", type: "uint256", value: "42588"}, {name: "bonus", type: "uint256", value: "8517"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "63"}, {name: "rawAmount", type: "uint256", value: "582"}, {name: "bonus", type: "uint256", value: "116"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "64"}, {name: "rawAmount", type: "uint256", value: "1967"}, {name: "bonus", type: "uint256", value: "393"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "65"}, {name: "rawAmount", type: "uint256", value: "40"}, {name: "bonus", type: "uint256", value: "8"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "66"}, {name: "rawAmount", type: "uint256", value: "40560"}, {name: "bonus", type: "uint256", value: "8112"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "67"}, {name: "rawAmount", type: "uint256", value: "3042"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "68"}, {name: "rawAmount", type: "uint256", value: "4546"}, {name: "bonus", type: "uint256", value: "909"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "69"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "811"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "70"}, {name: "rawAmount", type: "uint256", value: "12168"}, {name: "bonus", type: "uint256", value: "2433"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "71"}, {name: "rawAmount", type: "uint256", value: "7909"}, {name: "bonus", type: "uint256", value: "1581"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "72"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "40"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "73"}, {name: "rawAmount", type: "uint256", value: "12168"}, {name: "bonus", type: "uint256", value: "2433"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "74"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "75"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "40"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "76"}, {name: "rawAmount", type: "uint256", value: "7909"}, {name: "bonus", type: "uint256", value: "1581"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "77"}, {name: "rawAmount", type: "uint256", value: "40783"}, {name: "bonus", type: "uint256", value: "8156"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "78"}, {name: "rawAmount", type: "uint256", value: "61042"}, {name: "bonus", type: "uint256", value: "12208"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "79"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "80"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "81"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "81"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "4056"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "82"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "83"}, {name: "rawAmount", type: "uint256", value: "101400"}, {name: "bonus", type: "uint256", value: "20280"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "84"}, {name: "rawAmount", type: "uint256", value: "572"}, {name: "bonus", type: "uint256", value: "114"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "85"}, {name: "rawAmount", type: "uint256", value: "67938"}, {name: "bonus", type: "uint256", value: "13587"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "86"}, {name: "rawAmount", type: "uint256", value: "34983"}, {name: "bonus", type: "uint256", value: "6996"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "87"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "88"}, {name: "rawAmount", type: "uint256", value: "212"}, {name: "bonus", type: "uint256", value: "42"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "89"}, {name: "rawAmount", type: "uint256", value: "7199"}, {name: "bonus", type: "uint256", value: "1439"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "90"}, {name: "rawAmount", type: "uint256", value: "3042"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "91"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "40"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "92"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "202"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "93"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "94"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "95"}, {name: "rawAmount", type: "uint256", value: "1622"}, {name: "bonus", type: "uint256", value: "324"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "96"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "97"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "98"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "121"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "99"}, {name: "rawAmount", type: "uint256", value: "10160"}, {name: "bonus", type: "uint256", value: "2032"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "100"}, {name: "rawAmount", type: "uint256", value: "20153"}, {name: "bonus", type: "uint256", value: "4030"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "101"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "811"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "102"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "202"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "103"}, {name: "rawAmount", type: "uint256", value: "678"}, {name: "bonus", type: "uint256", value: "135"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "104"}, {name: "rawAmount", type: "uint256", value: "2453"}, {name: "bonus", type: "uint256", value: "490"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "105"}, {name: "rawAmount", type: "uint256", value: "40560"}, {name: "bonus", type: "uint256", value: "8112"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "106"}, {name: "rawAmount", type: "uint256", value: "304"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "107"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "40"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "108"}, {name: "rawAmount", type: "uint256", value: "257"}, {name: "bonus", type: "uint256", value: "51"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614072", timeStamp: "1511540085", hash: "0x3a9b7f4180839adb6ab89bc18e87d786df5444d945b8d2434d40fdf7f96438d7", nonce: "169", blockHash: "0x785380e530f9dd8f79c1072db3d46e5a77af902eba9bf6e30e7a7eb0b11e4088", transactionIndex: "2", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "5926680", gasUsed: "5827566", confirmations: "3128106"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1511540085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaseIdx", type: "uint256"}, {indexed: false, name: "rawAmount", type: "uint256"}, {indexed: false, name: "bonus", type: "uint256"}], name: "CrowdsalePurchaseBonusLog", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "109"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "811"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "110"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "111"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "112"}, {name: "rawAmount", type: "uint256", value: "1825"}, {name: "bonus", type: "uint256", value: "365"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "113"}, {name: "rawAmount", type: "uint256", value: "304"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "114"}, {name: "rawAmount", type: "uint256", value: "3123"}, {name: "bonus", type: "uint256", value: "624"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "115"}, {name: "rawAmount", type: "uint256", value: "6489"}, {name: "bonus", type: "uint256", value: "1297"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "116"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "4056"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "117"}, {name: "rawAmount", type: "uint256", value: "2417"}, {name: "bonus", type: "uint256", value: "483"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "118"}, {name: "rawAmount", type: "uint256", value: "19347"}, {name: "bonus", type: "uint256", value: "3869"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "119"}, {name: "rawAmount", type: "uint256", value: "6489"}, {name: "bonus", type: "uint256", value: "1297"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "120"}, {name: "rawAmount", type: "uint256", value: "63273"}, {name: "bonus", type: "uint256", value: "12654"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "121"}, {name: "rawAmount", type: "uint256", value: "709"}, {name: "bonus", type: "uint256", value: "141"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "122"}, {name: "rawAmount", type: "uint256", value: "25611"}, {name: "bonus", type: "uint256", value: "5122"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "123"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "202"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "124"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "125"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "126"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "127"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "128"}, {name: "rawAmount", type: "uint256", value: "9174"}, {name: "bonus", type: "uint256", value: "1834"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "129"}, {name: "rawAmount", type: "uint256", value: "47658"}, {name: "bonus", type: "uint256", value: "9531"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "130"}, {name: "rawAmount", type: "uint256", value: "133848"}, {name: "bonus", type: "uint256", value: "26769"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "131"}, {name: "rawAmount", type: "uint256", value: "50700"}, {name: "bonus", type: "uint256", value: "10140"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "132"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "133"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "4056"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "134"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "135"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "136"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "81"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "137"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "138"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "139"}, {name: "rawAmount", type: "uint256", value: "4664"}, {name: "bonus", type: "uint256", value: "932"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "140"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "141"}, {name: "rawAmount", type: "uint256", value: "15818"}, {name: "bonus", type: "uint256", value: "2495"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "142"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "143"}, {name: "rawAmount", type: "uint256", value: "18252"}, {name: "bonus", type: "uint256", value: "2737"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "144"}, {name: "rawAmount", type: "uint256", value: "4867"}, {name: "bonus", type: "uint256", value: "730"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "145"}, {name: "rawAmount", type: "uint256", value: "584"}, {name: "bonus", type: "uint256", value: "87"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "146"}, {name: "rawAmount", type: "uint256", value: "9126"}, {name: "bonus", type: "uint256", value: "1368"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "147"}, {name: "rawAmount", type: "uint256", value: "20"}, {name: "bonus", type: "uint256", value: "3"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "148"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "149"}, {name: "rawAmount", type: "uint256", value: "13790"}, {name: "bonus", type: "uint256", value: "2068"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "150"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "151"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "152"}, {name: "rawAmount", type: "uint256", value: "60637"}, {name: "bonus", type: "uint256", value: "9095"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "153"}, {name: "rawAmount", type: "uint256", value: "304"}, {name: "bonus", type: "uint256", value: "45"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "154"}, {name: "rawAmount", type: "uint256", value: "1241"}, {name: "bonus", type: "uint256", value: "186"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "155"}, {name: "rawAmount", type: "uint256", value: "4745"}, {name: "bonus", type: "uint256", value: "711"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "156"}, {name: "rawAmount", type: "uint256", value: "4745"}, {name: "bonus", type: "uint256", value: "711"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "157"}, {name: "rawAmount", type: "uint256", value: "141"}, {name: "bonus", type: "uint256", value: "21"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "158"}, {name: "rawAmount", type: "uint256", value: "15744"}, {name: "bonus", type: "uint256", value: "2361"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "159"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "760"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "160"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "161"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "162"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "163"}, {name: "rawAmount", type: "uint256", value: "4867"}, {name: "bonus", type: "uint256", value: "730"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "164"}, {name: "rawAmount", type: "uint256", value: "10951"}, {name: "bonus", type: "uint256", value: "1642"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "165"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "166"}, {name: "rawAmount", type: "uint256", value: "12573"}, {name: "bonus", type: "uint256", value: "1885"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "167"}, {name: "rawAmount", type: "uint256", value: "1419"}, {name: "bonus", type: "uint256", value: "212"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "168"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "169"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "170"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "171"}, {name: "rawAmount", type: "uint256", value: "154"}, {name: "bonus", type: "uint256", value: "23"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "172"}, {name: "rawAmount", type: "uint256", value: "304"}, {name: "bonus", type: "uint256", value: "45"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "173"}, {name: "rawAmount", type: "uint256", value: "8112"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "174"}, {name: "rawAmount", type: "uint256", value: "12168"}, {name: "bonus", type: "uint256", value: "1825"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "175"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "176"}, {name: "rawAmount", type: "uint256", value: "709"}, {name: "bonus", type: "uint256", value: "106"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "177"}, {name: "rawAmount", type: "uint256", value: "10342"}, {name: "bonus", type: "uint256", value: "1551"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "178"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "179"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "180"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "181"}, {name: "rawAmount", type: "uint256", value: "32448"}, {name: "bonus", type: "uint256", value: "4867"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "182"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "91"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "183"}, {name: "rawAmount", type: "uint256", value: "4001"}, {name: "bonus", type: "uint256", value: "600"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "184"}, {name: "rawAmount", type: "uint256", value: "1051"}, {name: "bonus", type: "uint256", value: "157"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "185"}, {name: "rawAmount", type: "uint256", value: "4015"}, {name: "bonus", type: "uint256", value: "602"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "186"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "187"}, {name: "rawAmount", type: "uint256", value: "1987"}, {name: "bonus", type: "uint256", value: "298"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "188"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "189"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "190"}, {name: "rawAmount", type: "uint256", value: "8112"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "191"}, {name: "rawAmount", type: "uint256", value: "8112"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "192"}, {name: "rawAmount", type: "uint256", value: "9291"}, {name: "bonus", type: "uint256", value: "1393"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "193"}, {name: "rawAmount", type: "uint256", value: "28392"}, {name: "bonus", type: "uint256", value: "4258"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "194"}, {name: "rawAmount", type: "uint256", value: "19233"}, {name: "bonus", type: "uint256", value: "2884"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "195"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "196"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "197"}, {name: "rawAmount", type: "uint256", value: "2920"}, {name: "bonus", type: "uint256", value: "438"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "198"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "199"}, {name: "rawAmount", type: "uint256", value: "507"}, {name: "bonus", type: "uint256", value: "76"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "200"}, {name: "rawAmount", type: "uint256", value: "2636"}, {name: "bonus", type: "uint256", value: "395"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "201"}, {name: "rawAmount", type: "uint256", value: "5577"}, {name: "bonus", type: "uint256", value: "836"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "202"}, {name: "rawAmount", type: "uint256", value: "2372"}, {name: "bonus", type: "uint256", value: "355"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "203"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "204"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "91"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "205"}, {name: "rawAmount", type: "uint256", value: "2839"}, {name: "bonus", type: "uint256", value: "425"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "206"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "207"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "208"}, {name: "rawAmount", type: "uint256", value: "30420"}, {name: "bonus", type: "uint256", value: "4563"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "209"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "760"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "210"}, {name: "rawAmount", type: "uint256", value: "285"}, {name: "bonus", type: "uint256", value: "42"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "211"}, {name: "rawAmount", type: "uint256", value: "16224"}, {name: "bonus", type: "uint256", value: "2433"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "212"}, {name: "rawAmount", type: "uint256", value: "20"}, {name: "bonus", type: "uint256", value: "3"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "213"}, {name: "rawAmount", type: "uint256", value: "2636"}, {name: "bonus", type: "uint256", value: "395"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "214"}, {name: "rawAmount", type: "uint256", value: "3042"}, {name: "bonus", type: "uint256", value: "456"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "215"}, {name: "rawAmount", type: "uint256", value: "7098"}, {name: "bonus", type: "uint256", value: "1064"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "216"}, {name: "rawAmount", type: "uint256", value: "18252"}, {name: "bonus", type: "uint256", value: "2737"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "217"}, {name: "rawAmount", type: "uint256", value: "26364"}, {name: "bonus", type: "uint256", value: "3954"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "218"}, {name: "rawAmount", type: "uint256", value: "223"}, {name: "bonus", type: "uint256", value: "33"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "219"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "760"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614073", timeStamp: "1511540091", hash: "0xcaa2b8e3d4f38a87373bdf22258fe1c9720c46ea97d5bb02733ddf7a2633acb9", nonce: "170", blockHash: "0x7ec837f7831b9391988812ed8356b12b0077bcd0289a26d5376208a0438edba4", transactionIndex: "12", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "6164662", gasUsed: "5836028", confirmations: "3128105"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1511540091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaseIdx", type: "uint256"}, {indexed: false, name: "rawAmount", type: "uint256"}, {indexed: false, name: "bonus", type: "uint256"}], name: "CrowdsalePurchaseBonusLog", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "220"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "221"}, {name: "rawAmount", type: "uint256", value: "5881"}, {name: "bonus", type: "uint256", value: "882"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "222"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "223"}, {name: "rawAmount", type: "uint256", value: "6286"}, {name: "bonus", type: "uint256", value: "942"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "224"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "225"}, {name: "rawAmount", type: "uint256", value: "507"}, {name: "bonus", type: "uint256", value: "76"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "226"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "91"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "227"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "228"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "229"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "230"}, {name: "rawAmount", type: "uint256", value: "275"}, {name: "bonus", type: "uint256", value: "41"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "231"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "232"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "233"}, {name: "rawAmount", type: "uint256", value: "58812"}, {name: "bonus", type: "uint256", value: "8821"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "234"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "235"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "236"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "237"}, {name: "rawAmount", type: "uint256", value: "3879"}, {name: "bonus", type: "uint256", value: "581"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "238"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "239"}, {name: "rawAmount", type: "uint256", value: "101"}, {name: "bonus", type: "uint256", value: "15"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "240"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "760"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "241"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "242"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "243"}, {name: "rawAmount", type: "uint256", value: "618"}, {name: "bonus", type: "uint256", value: "92"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "244"}, {name: "rawAmount", type: "uint256", value: "15210"}, {name: "bonus", type: "uint256", value: "2281"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "245"}, {name: "rawAmount", type: "uint256", value: "8862"}, {name: "bonus", type: "uint256", value: "1329"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "246"}, {name: "rawAmount", type: "uint256", value: "3650"}, {name: "bonus", type: "uint256", value: "547"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "247"}, {name: "rawAmount", type: "uint256", value: "420"}, {name: "bonus", type: "uint256", value: "63"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "248"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "760"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "249"}, {name: "rawAmount", type: "uint256", value: "9126"}, {name: "bonus", type: "uint256", value: "1368"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "250"}, {name: "rawAmount", type: "uint256", value: "2636"}, {name: "bonus", type: "uint256", value: "395"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "251"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "91"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "252"}, {name: "rawAmount", type: "uint256", value: "40965"}, {name: "bonus", type: "uint256", value: "6144"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "253"}, {name: "rawAmount", type: "uint256", value: "23119"}, {name: "bonus", type: "uint256", value: "3467"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "254"}, {name: "rawAmount", type: "uint256", value: "446"}, {name: "bonus", type: "uint256", value: "66"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "255"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "256"}, {name: "rawAmount", type: "uint256", value: "730"}, {name: "bonus", type: "uint256", value: "109"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "257"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "258"}, {name: "rawAmount", type: "uint256", value: "1856"}, {name: "bonus", type: "uint256", value: "278"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "259"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "260"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "261"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "262"}, {name: "rawAmount", type: "uint256", value: "223080"}, {name: "bonus", type: "uint256", value: "33462"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "263"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "264"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "265"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "266"}, {name: "rawAmount", type: "uint256", value: "724"}, {name: "bonus", type: "uint256", value: "108"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "267"}, {name: "rawAmount", type: "uint256", value: "36504"}, {name: "bonus", type: "uint256", value: "5475"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "268"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "269"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "270"}, {name: "rawAmount", type: "uint256", value: "38532"}, {name: "bonus", type: "uint256", value: "5779"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "271"}, {name: "rawAmount", type: "uint256", value: "11762"}, {name: "bonus", type: "uint256", value: "1764"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "272"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "273"}, {name: "rawAmount", type: "uint256", value: "8112"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "274"}, {name: "rawAmount", type: "uint256", value: "60"}, {name: "bonus", type: "uint256", value: "9"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "275"}, {name: "rawAmount", type: "uint256", value: "101"}, {name: "bonus", type: "uint256", value: "15"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "276"}, {name: "rawAmount", type: "uint256", value: "48062"}, {name: "bonus", type: "uint256", value: "7209"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "277"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "278"}, {name: "rawAmount", type: "uint256", value: "141"}, {name: "bonus", type: "uint256", value: "21"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "279"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "280"}, {name: "rawAmount", type: "uint256", value: "1825"}, {name: "bonus", type: "uint256", value: "273"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "281"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "282"}, {name: "rawAmount", type: "uint256", value: "60840"}, {name: "bonus", type: "uint256", value: "9126"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "283"}, {name: "rawAmount", type: "uint256", value: "2294"}, {name: "bonus", type: "uint256", value: "344"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "284"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "285"}, {name: "rawAmount", type: "uint256", value: "669"}, {name: "bonus", type: "uint256", value: "100"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "286"}, {name: "rawAmount", type: "uint256", value: "5859"}, {name: "bonus", type: "uint256", value: "878"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "287"}, {name: "rawAmount", type: "uint256", value: "58467"}, {name: "bonus", type: "uint256", value: "8770"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "288"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "289"}, {name: "rawAmount", type: "uint256", value: "162240"}, {name: "bonus", type: "uint256", value: "24336"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "290"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "291"}, {name: "rawAmount", type: "uint256", value: "30622"}, {name: "bonus", type: "uint256", value: "4593"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "292"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "293"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "294"}, {name: "rawAmount", type: "uint256", value: "4563"}, {name: "bonus", type: "uint256", value: "684"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "295"}, {name: "rawAmount", type: "uint256", value: "21"}, {name: "bonus", type: "uint256", value: "3"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "296"}, {name: "rawAmount", type: "uint256", value: "223"}, {name: "bonus", type: "uint256", value: "33"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "297"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "298"}, {name: "rawAmount", type: "uint256", value: "2636"}, {name: "bonus", type: "uint256", value: "395"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "299"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "300"}, {name: "rawAmount", type: "uint256", value: "8112"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "301"}, {name: "rawAmount", type: "uint256", value: "26364"}, {name: "bonus", type: "uint256", value: "3954"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "302"}, {name: "rawAmount", type: "uint256", value: "19468"}, {name: "bonus", type: "uint256", value: "2920"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "303"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "304"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "305"}, {name: "rawAmount", type: "uint256", value: "2297"}, {name: "bonus", type: "uint256", value: "344"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "306"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "307"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "308"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "309"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "310"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "311"}, {name: "rawAmount", type: "uint256", value: "5272"}, {name: "bonus", type: "uint256", value: "790"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "312"}, {name: "rawAmount", type: "uint256", value: "3042"}, {name: "bonus", type: "uint256", value: "456"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "313"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "314"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "315"}, {name: "rawAmount", type: "uint256", value: "9937"}, {name: "bonus", type: "uint256", value: "1490"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "316"}, {name: "rawAmount", type: "uint256", value: "10342"}, {name: "bonus", type: "uint256", value: "1551"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "317"}, {name: "rawAmount", type: "uint256", value: "30420"}, {name: "bonus", type: "uint256", value: "4563"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "318"}, {name: "rawAmount", type: "uint256", value: "811"}, {name: "bonus", type: "uint256", value: "121"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "319"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "320"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "321"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "322"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "323"}, {name: "rawAmount", type: "uint256", value: "8112"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "324"}, {name: "rawAmount", type: "uint256", value: "30420"}, {name: "bonus", type: "uint256", value: "4563"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "325"}, {name: "rawAmount", type: "uint256", value: "811"}, {name: "bonus", type: "uint256", value: "121"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "326"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "327"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "328"}, {name: "rawAmount", type: "uint256", value: "60835"}, {name: "bonus", type: "uint256", value: "9125"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614074", timeStamp: "1511540101", hash: "0xfd2ab9fce796f099ec28931beac2716825e3bca477b05fe12149d27995e8dcc2", nonce: "171", blockHash: "0xe7fb599e3a94ee0888055d7e482e430ad94f571ce1c04e07c63bd0de46724612", transactionIndex: "7", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "5840284", gasUsed: "5638725", confirmations: "3128104"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1511540101 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaseIdx", type: "uint256"}, {indexed: false, name: "rawAmount", type: "uint256"}, {indexed: false, name: "bonus", type: "uint256"}], name: "CrowdsalePurchaseBonusLog", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "329"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "330"}, {name: "rawAmount", type: "uint256", value: "14196"}, {name: "bonus", type: "uint256", value: "2129"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "331"}, {name: "rawAmount", type: "uint256", value: "1642"}, {name: "bonus", type: "uint256", value: "246"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "332"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "333"}, {name: "rawAmount", type: "uint256", value: "1628"}, {name: "bonus", type: "uint256", value: "244"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "334"}, {name: "rawAmount", type: "uint256", value: "15548"}, {name: "bonus", type: "uint256", value: "2332"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "335"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "336"}, {name: "rawAmount", type: "uint256", value: "12168"}, {name: "bonus", type: "uint256", value: "1825"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "337"}, {name: "rawAmount", type: "uint256", value: "1419"}, {name: "bonus", type: "uint256", value: "212"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "338"}, {name: "rawAmount", type: "uint256", value: "936"}, {name: "bonus", type: "uint256", value: "140"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "339"}, {name: "rawAmount", type: "uint256", value: "5768"}, {name: "bonus", type: "uint256", value: "865"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "340"}, {name: "rawAmount", type: "uint256", value: "1386"}, {name: "bonus", type: "uint256", value: "207"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "341"}, {name: "rawAmount", type: "uint256", value: "6793"}, {name: "bonus", type: "uint256", value: "1018"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "342"}, {name: "rawAmount", type: "uint256", value: "1419"}, {name: "bonus", type: "uint256", value: "212"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "343"}, {name: "rawAmount", type: "uint256", value: "1723"}, {name: "bonus", type: "uint256", value: "258"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "344"}, {name: "rawAmount", type: "uint256", value: "841"}, {name: "bonus", type: "uint256", value: "126"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "345"}, {name: "rawAmount", type: "uint256", value: "141"}, {name: "bonus", type: "uint256", value: "21"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "346"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "347"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "348"}, {name: "rawAmount", type: "uint256", value: "811"}, {name: "bonus", type: "uint256", value: "121"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "349"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "350"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "351"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "352"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "353"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "354"}, {name: "rawAmount", type: "uint256", value: "1961"}, {name: "bonus", type: "uint256", value: "294"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "355"}, {name: "rawAmount", type: "uint256", value: "2230"}, {name: "bonus", type: "uint256", value: "334"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "356"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "357"}, {name: "rawAmount", type: "uint256", value: "5471"}, {name: "bonus", type: "uint256", value: "820"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "358"}, {name: "rawAmount", type: "uint256", value: "2230"}, {name: "bonus", type: "uint256", value: "334"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "359"}, {name: "rawAmount", type: "uint256", value: "1216"}, {name: "bonus", type: "uint256", value: "182"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "360"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "361"}, {name: "rawAmount", type: "uint256", value: "12168"}, {name: "bonus", type: "uint256", value: "1825"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "362"}, {name: "rawAmount", type: "uint256", value: "608"}, {name: "bonus", type: "uint256", value: "91"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "363"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "364"}, {name: "rawAmount", type: "uint256", value: "8107"}, {name: "bonus", type: "uint256", value: "1216"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "365"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "366"}, {name: "rawAmount", type: "uint256", value: "7098"}, {name: "bonus", type: "uint256", value: "1064"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "367"}, {name: "rawAmount", type: "uint256", value: "55386"}, {name: "bonus", type: "uint256", value: "8307"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "368"}, {name: "rawAmount", type: "uint256", value: "1622"}, {name: "bonus", type: "uint256", value: "243"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "369"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "370"}, {name: "rawAmount", type: "uint256", value: "425"}, {name: "bonus", type: "uint256", value: "63"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "371"}, {name: "rawAmount", type: "uint256", value: "1622"}, {name: "bonus", type: "uint256", value: "243"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "372"}, {name: "rawAmount", type: "uint256", value: "91"}, {name: "bonus", type: "uint256", value: "13"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "373"}, {name: "rawAmount", type: "uint256", value: "547"}, {name: "bonus", type: "uint256", value: "82"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "374"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "375"}, {name: "rawAmount", type: "uint256", value: "1926"}, {name: "bonus", type: "uint256", value: "288"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "376"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "377"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "60"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "378"}, {name: "rawAmount", type: "uint256", value: "2048"}, {name: "bonus", type: "uint256", value: "307"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "379"}, {name: "rawAmount", type: "uint256", value: "932"}, {name: "bonus", type: "uint256", value: "139"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "380"}, {name: "rawAmount", type: "uint256", value: "6084"}, {name: "bonus", type: "uint256", value: "912"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "381"}, {name: "rawAmount", type: "uint256", value: "709"}, {name: "bonus", type: "uint256", value: "106"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "382"}, {name: "rawAmount", type: "uint256", value: "4841"}, {name: "bonus", type: "uint256", value: "726"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "383"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "384"}, {name: "rawAmount", type: "uint256", value: "904"}, {name: "bonus", type: "uint256", value: "135"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "385"}, {name: "rawAmount", type: "uint256", value: "16224"}, {name: "bonus", type: "uint256", value: "2433"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "386"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "387"}, {name: "rawAmount", type: "uint256", value: "1480"}, {name: "bonus", type: "uint256", value: "222"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "388"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "389"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "390"}, {name: "rawAmount", type: "uint256", value: "1014"}, {name: "bonus", type: "uint256", value: "152"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "391"}, {name: "rawAmount", type: "uint256", value: "360"}, {name: "bonus", type: "uint256", value: "54"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "392"}, {name: "rawAmount", type: "uint256", value: "1419"}, {name: "bonus", type: "uint256", value: "212"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "393"}, {name: "rawAmount", type: "uint256", value: "10748"}, {name: "bonus", type: "uint256", value: "1612"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "394"}, {name: "rawAmount", type: "uint256", value: "229"}, {name: "bonus", type: "uint256", value: "34"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "395"}, {name: "rawAmount", type: "uint256", value: "672"}, {name: "bonus", type: "uint256", value: "100"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "396"}, {name: "rawAmount", type: "uint256", value: "10140"}, {name: "bonus", type: "uint256", value: "1521"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "397"}, {name: "rawAmount", type: "uint256", value: "5714"}, {name: "bonus", type: "uint256", value: "857"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "398"}, {name: "rawAmount", type: "uint256", value: "507"}, {name: "bonus", type: "uint256", value: "76"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "399"}, {name: "rawAmount", type: "uint256", value: "709"}, {name: "bonus", type: "uint256", value: "106"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "400"}, {name: "rawAmount", type: "uint256", value: "5475"}, {name: "bonus", type: "uint256", value: "821"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "401"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "608"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "402"}, {name: "rawAmount", type: "uint256", value: "811"}, {name: "bonus", type: "uint256", value: "121"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "403"}, {name: "rawAmount", type: "uint256", value: "640"}, {name: "bonus", type: "uint256", value: "96"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "404"}, {name: "rawAmount", type: "uint256", value: "851"}, {name: "bonus", type: "uint256", value: "127"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "405"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "30"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "406"}, {name: "rawAmount", type: "uint256", value: "174258"}, {name: "bonus", type: "uint256", value: "26138"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "407"}, {name: "rawAmount", type: "uint256", value: "14358"}, {name: "bonus", type: "uint256", value: "2153"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "408"}, {name: "rawAmount", type: "uint256", value: "1521"}, {name: "bonus", type: "uint256", value: "228"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "409"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "3042"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "410"}, {name: "rawAmount", type: "uint256", value: "101"}, {name: "bonus", type: "uint256", value: "15"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "411"}, {name: "rawAmount", type: "uint256", value: "101"}, {name: "bonus", type: "uint256", value: "15"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "412"}, {name: "rawAmount", type: "uint256", value: "152100"}, {name: "bonus", type: "uint256", value: "20658"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "413"}, {name: "rawAmount", type: "uint256", value: "590"}, {name: "bonus", type: "uint256", value: "59"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "414"}, {name: "rawAmount", type: "uint256", value: "7300"}, {name: "bonus", type: "uint256", value: "730"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "415"}, {name: "rawAmount", type: "uint256", value: "1642"}, {name: "bonus", type: "uint256", value: "164"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "416"}, {name: "rawAmount", type: "uint256", value: "5070"}, {name: "bonus", type: "uint256", value: "507"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "417"}, {name: "rawAmount", type: "uint256", value: "405"}, {name: "bonus", type: "uint256", value: "40"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "418"}, {name: "rawAmount", type: "uint256", value: "3362"}, {name: "bonus", type: "uint256", value: "336"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "419"}, {name: "rawAmount", type: "uint256", value: "39525"}, {name: "bonus", type: "uint256", value: "3952"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "420"}, {name: "rawAmount", type: "uint256", value: "40"}, {name: "bonus", type: "uint256", value: "4"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "421"}, {name: "rawAmount", type: "uint256", value: "168"}, {name: "bonus", type: "uint256", value: "16"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "422"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "202"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "423"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "20"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "424"}, {name: "rawAmount", type: "uint256", value: "4056"}, {name: "bonus", type: "uint256", value: "405"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "425"}, {name: "rawAmount", type: "uint256", value: "2433"}, {name: "bonus", type: "uint256", value: "243"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "426"}, {name: "rawAmount", type: "uint256", value: "2433"}, {name: "bonus", type: "uint256", value: "243"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "427"}, {name: "rawAmount", type: "uint256", value: "2028"}, {name: "bonus", type: "uint256", value: "202"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "428"}, {name: "rawAmount", type: "uint256", value: "202"}, {name: "bonus", type: "uint256", value: "20"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "429"}, {name: "rawAmount", type: "uint256", value: "20280"}, {name: "bonus", type: "uint256", value: "2028"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "430"}, {name: "rawAmount", type: "uint256", value: "1419"}, {name: "bonus", type: "uint256", value: "141"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "431"}, {name: "rawAmount", type: "uint256", value: "1622"}, {name: "bonus", type: "uint256", value: "162"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}, {name: "CrowdsalePurchaseBonusLog", events: [{name: "purchaseIdx", type: "uint256", value: "432"}, {name: "rawAmount", type: "uint256", value: "7098"}, {name: "bonus", type: "uint256", value: "709"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614083", timeStamp: "1511540226", hash: "0x342cd0116697b7bed5f5e43520ead305bba78503035e449f86300aee73fa1999", nonce: "172", blockHash: "0x1ccd7570a446f27ca136836ff7a32f2153bfcc32270a7a4a06c2df823890c2d4", transactionIndex: "29", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "651161", gasUsed: "23365", confirmations: "3128095"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1511540226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614083", timeStamp: "1511540226", hash: "0x6edd57406ab67ed192bd1290c4023ed6344a3f0a37b4f288eaec602525e0a63e", nonce: "173", blockHash: "0x1ccd7570a446f27ca136836ff7a32f2153bfcc32270a7a4a06c2df823890c2d4", transactionIndex: "30", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "674526", gasUsed: "23365", confirmations: "3128095"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1511540226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614083", timeStamp: "1511540226", hash: "0xc8e49f4bd2ecb86ba04f8eda0c39450ad346170e5ce431af30c4bab6df25ed2d", nonce: "174", blockHash: "0x1ccd7570a446f27ca136836ff7a32f2153bfcc32270a7a4a06c2df823890c2d4", transactionIndex: "31", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "697891", gasUsed: "23365", confirmations: "3128095"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1511540226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: loadCrowdsalePurchases( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4614083", timeStamp: "1511540226", hash: "0x5d890da5da088308f3193ed557db86d00c8a0bade782f258735671c2ee92f053", nonce: "175", blockHash: "0x1ccd7570a446f27ca136836ff7a32f2153bfcc32270a7a4a06c2df823890c2d4", transactionIndex: "32", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0xdb1e0eec0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "721256", gasUsed: "23365", confirmations: "3128095"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "numOfPresalePurchases", value: "6"}], name: "loadCrowdsalePurchases", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadCrowdsalePurchases(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1511540226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614098", timeStamp: "1511540398", hash: "0x4048e3b45cb25855eb994e45e5db496964e10cd9a74f1386b5d1445801aec639", nonce: "6", blockHash: "0xd37b1aa1338b7eb4f549097d16af7305d917095cdf25c721c5678250de919ac8", transactionIndex: "12", from: "0xe3472b100fa844ada53cf79b998a1a7ba31e4d95", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "200000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "657354", gasUsed: "122543", confirmations: "3128080"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1511540398 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xe3472b100fa844ada53cf79b998a1a7ba31e4d95"}, {name: "tokenCount", type: "uint256", value: "73021409239911388652"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614183", timeStamp: "1511541766", hash: "0x900ca5ed7dd11dc7aeb2b12b1d6ddb998d7b2ceb7dea2579242bf2415569a190", nonce: "2", blockHash: "0x54612da2160a85a0677c32d56cf162a74da357b3deb17d28d2d046816532c889", transactionIndex: "27", from: "0x00a18486ec14de7946d538178ac0bb9e183d51cf", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "1173893", gasUsed: "107543", confirmations: "3127995"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1511541766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x00a18486ec14de7946d538178ac0bb9e183d51cf"}, {name: "tokenCount", type: "uint256", value: "66736589312830833452026"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "75992965000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614201", timeStamp: "1511542028", hash: "0xd2252b996fa9c3b1880bf9e539b1b494305de04892ee30eb0b2b9b942e2cab04", nonce: "245", blockHash: "0xc2809d562a5eba55bb847a70001221618697e09985d7519c7b5d5ef976669b8b", transactionIndex: "25", from: "0x012d78b8ae3effb27d1a177cb14b2776562aa192", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "826427", gasUsed: "107543", confirmations: "3127977"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1511542028 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x012d78b8ae3effb27d1a177cb14b2776562aa192"}, {name: "tokenCount", type: "uint256", value: "7740269379430607197181"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "4013551919464322755" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614202", timeStamp: "1511542061", hash: "0xb7e189a1065c148e7355268d1421aaccad4420dcf9123a6b13ba9df9c9f13ba9", nonce: "130", blockHash: "0x53786ae658870deda1d42782103fddac7780896df9e741fbe6dbb75711400c03", transactionIndex: "115", from: "0x8a6b81db368c07bde2a7a943bec7649367afa6a4", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "5405993", gasUsed: "107543", confirmations: "3127976"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1511542061 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x8a6b81db368c07bde2a7a943bec7649367afa6a4"}, {name: "tokenCount", type: "uint256", value: "7740269379430607197181"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "60367029913770" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614221", timeStamp: "1511542265", hash: "0x9437a0abf9137c42809ca35614aeb3a4ec0619f388c128daa554b4f1a719e97b", nonce: "1083", blockHash: "0x3d46354359039cccb410b7b4dd0d40d6fa653b80b885ddaa9af911db084731b5", transactionIndex: "0", from: "0xb9f9d6b531546e4c80058bee5749d72ffc76b54f", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "107543", gasUsed: "107543", confirmations: "3127957"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1511542265 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xb9f9d6b531546e4c80058bee5749d72ffc76b54f"}, {name: "tokenCount", type: "uint256", value: "58056999078177729755358"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3444641180744214" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614223", timeStamp: "1511542297", hash: "0xbb454af6c6df9f8ffee3e72cfbe180303142bcdb85a4ca77fb04a29532a5dd9c", nonce: "1", blockHash: "0xa623501df723553aa431a42fac2541e12f1ac3217fa177d3975cc1fd497c9a91", transactionIndex: "50", from: "0x008461b96a04895433fe547f28d7728bc1d03b90", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "1372210", gasUsed: "107543", confirmations: "3127955"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1511542297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x008461b96a04895433fe547f28d7728bc1d03b90"}, {name: "tokenCount", type: "uint256", value: "3870134689715303598590"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "11850595000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614262", timeStamp: "1511542804", hash: "0x9c6fb19f405c3bb74acf9ccc676808b3d626166320214e356ab7f2a5c1e68565", nonce: "20", blockHash: "0x0e5b2d5ce8691b2456f64e5921efb760b52af6b30a3e7178342b7b80c3c549c8", transactionIndex: "8", from: "0x385812b8367fab03ae57fdf2b1022948901417be", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "316627", gasUsed: "107543", confirmations: "3127916"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1511542804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x385812b8367fab03ae57fdf2b1022948901417be"}, {name: "tokenCount", type: "uint256", value: "332572689228210969100844"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "13695706310805996" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614358", timeStamp: "1511544153", hash: "0x552f4e8d2b17ac9e60c8af17787d9ab43469f2589564bc113de94ee3e047bb3d", nonce: "53", blockHash: "0x7e54e3103896bb3d18cc8da592c32bbc8239326021f242321c5c16f2f8a669cc", transactionIndex: "2", from: "0x49d4cb2688dc10c451dc8faee39c33f0fed8892d", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "149543", gasUsed: "107543", confirmations: "3127820"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1511544153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x49d4cb2688dc10c451dc8faee39c33f0fed8892d"}, {name: "tokenCount", type: "uint256", value: "27401283817276748591908"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "998572000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614358", timeStamp: "1511544153", hash: "0xa54ebff194d07e917a8e2db4f76b2b873d32064010966e3b2e1ffcdbaaa5e4f4", nonce: "104", blockHash: "0x7e54e3103896bb3d18cc8da592c32bbc8239326021f242321c5c16f2f8a669cc", transactionIndex: "102", from: "0x2f08fd787d40d254706d2f919e8b2dc60633255d", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "3966680", gasUsed: "107543", confirmations: "3127820"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511544153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x2f08fd787d40d254706d2f919e8b2dc60633255d"}, {name: "tokenCount", type: "uint256", value: "9675336724288258996476"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "418469000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614361", timeStamp: "1511544181", hash: "0xcadb8208eb5c38addd7d774a44b13f2d655a801db71068372ef272f896df26be", nonce: "225", blockHash: "0x687e75bd8a369209a1358e0339947233bd558d47192ad620d2932f17d90d0900", transactionIndex: "59", from: "0xc8aec25691ce21dcc905855c1162bf0bdce8cd55", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "3223131", gasUsed: "107543", confirmations: "3127817"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511544181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xc8aec25691ce21dcc905855c1162bf0bdce8cd55"}, {name: "tokenCount", type: "uint256", value: "19352333026059243251786"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "297838133952466471224" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614474", timeStamp: "1511545976", hash: "0x2b2ec0edaf2804f00a7aaaf9a5321660c0251af405f6c50dbb7941a4719812df", nonce: "3", blockHash: "0xb2701ed2670395ad2d3797bcfc41cc5a7a176d092bd6f6209ee8bac226c6a080", transactionIndex: "22", from: "0x095f850eec0522b2e269aea9dede4bc6967378f6", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "799677", gasUsed: "107543", confirmations: "3127704"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511545976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x095f850eec0522b2e269aea9dede4bc6967378f6"}, {name: "tokenCount", type: "uint256", value: "23222467715774546850376"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "88044217048714660" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614488", timeStamp: "1511546150", hash: "0xeb2c0678ac27f8b6df79e93cc4f039965f08544167ebf7121bace767fd3119e5", nonce: "1", blockHash: "0x40eb6807dc3b224b260bee1d343915ec8fed726f1aaba2aaa57a652d6d68a3d3", transactionIndex: "118", from: "0x0073d1f72cfab3c02d0c48ef5dbb42798930cbf2", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "3860740", gasUsed: "107543", confirmations: "3127690"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511546150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x0073d1f72cfab3c02d0c48ef5dbb42798930cbf2"}, {name: "tokenCount", type: "uint256", value: "11610404069145910795771"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "134831230000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614529", timeStamp: "1511546790", hash: "0x894b87e527267a50ec2174c6ba844c0e973e5f6dc11171817df656c78e7a0656", nonce: "123", blockHash: "0xde2d843abce2f678eee1627d0654f4753c6da44e7e0729deb0c6ef2ca06f7def", transactionIndex: "130", from: "0xabcee54a5917505b4d9f57abb634a29cbd22e987", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "4770785", gasUsed: "107543", confirmations: "3127649"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511546790 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xabcee54a5917505b4d9f57abb634a29cbd22e987"}, {name: "tokenCount", type: "uint256", value: "3870134689715303598590"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "27818349127108316" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614546", timeStamp: "1511547054", hash: "0x80cdf43f38a9b5a8c4d710996c5bb30e71858c87edeb00df64db024099c87e3c", nonce: "52", blockHash: "0xa8ebc8c47bebf3b19e6b4e17d42b9cc4426b6edf89e9bbf1e736cfcea0c5dbec", transactionIndex: "113", from: "0xc8912237e3219838c2349067c54f18c5162fbf0d", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "5525994", gasUsed: "44691", confirmations: "3127632"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511547054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "291220746338829950" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614561", timeStamp: "1511547245", hash: "0x68e8e61491657de3daad6e207a999020686b78a05ef58d502e44c210b891617f", nonce: "7", blockHash: "0x0f0abe5cbbe53fed942f9f17dc06fa8eaf587a81d58e32d4abb7c64184a22fa8", transactionIndex: "9", from: "0xd8a48c0053af4997c768f059c7c697d8f7857fda", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "520265", gasUsed: "107543", confirmations: "3127617"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511547245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xd8a48c0053af4997c768f059c7c697d8f7857fda"}, {name: "tokenCount", type: "uint256", value: "8882058687545585274295"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "72241193000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614598", timeStamp: "1511547837", hash: "0x4228991976b548fe91be89c3ef3fe1f0d4265159917006dd27f38938f3b60e80", nonce: "79", blockHash: "0xb9ee50d35f473fdc3ab62232b3120c0473e8ff28ebde38af48dc2bedab634a91", transactionIndex: "8", from: "0x54e27782bc1a4b54a261b9aee7040354b1334841", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "580598", gasUsed: "107543", confirmations: "3127580"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511547837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x54e27782bc1a4b54a261b9aee7040354b1334841"}, {name: "tokenCount", type: "uint256", value: "20193738809800949480124"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "52174543149720316" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614598", timeStamp: "1511547837", hash: "0xa0270224ac546a976a53c0b9be5ec952a62a8fa6e94bcf0b71f9868a57425a38", nonce: "98", blockHash: "0xb9ee50d35f473fdc3ab62232b3120c0473e8ff28ebde38af48dc2bedab634a91", transactionIndex: "48", from: "0x3dbe0a3e0fa494c5c012cf5b6b2caa5ed5312376", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "1621421", gasUsed: "107543", confirmations: "3127580"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511547837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x3dbe0a3e0fa494c5c012cf5b6b2caa5ed5312376"}, {name: "tokenCount", type: "uint256", value: "13545471414003562595067"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "54665509280992235" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614631", timeStamp: "1511548166", hash: "0xb62dd8b0085e31fc83bc9bf8a0239e404a74c01f7aa2096af191057097b72178", nonce: "18", blockHash: "0xdc1d05c35caa28d6cd793131b6e90fcecbb7a2e247da4d80a2e32cfb6aa1773e", transactionIndex: "8", from: "0x6a9054efca894cda71b0a71a6055e1e40f7cb7e0", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "353786", gasUsed: "107543", confirmations: "3127547"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511548166 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x6a9054efca894cda71b0a71a6055e1e40f7cb7e0"}, {name: "tokenCount", type: "uint256", value: "3870134689715303598590"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "58157973233574827" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614688", timeStamp: "1511548764", hash: "0x0e0293faa9a1070498b0787799a6378b72fba278ff1f9c228188f6a338ff9793", nonce: "86", blockHash: "0x2920cff32add4db4d0d657a71f31bdb094a70bb85dd4bb2b24ae9fd7edc16444", transactionIndex: "69", from: "0x1c4ba011e13f2f735dee87c7801001ef5e7348d0", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "3773745", gasUsed: "107543", confirmations: "3127490"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511548764 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x1c4ba011e13f2f735dee87c7801001ef5e7348d0"}, {name: "tokenCount", type: "uint256", value: "4441029343772792637147"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "7107122173135631" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614700", timeStamp: "1511548937", hash: "0x0a2a32e08cefa0eddc185efb7189c59530c3ebfe7d3cb526bb0ec478337421b7", nonce: "11", blockHash: "0x4af0ef3fb5a46429d9cdeb2e64d7ddd7f3db6c579e3fd677f34d1670144ee11f", transactionIndex: "7", from: "0x56581592b526406391494002bdd9b664bd7980c2", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "22000", gasPrice: "40000000000", isError: "1", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "169000", gasUsed: "22000", confirmations: "3127478"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "94889120707248425" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614706", timeStamp: "1511549017", hash: "0xeb554a5c2f91f50e626813794b94f8368e709e4512c935d6bc31ff69c64ffbde", nonce: "5", blockHash: "0xf4666b47a16aa4a31aa3fab2e4702cb45edfc8c97dd7a7c6bed5eb7a7d1ed810", transactionIndex: "46", from: "0x00a18486ec14de7946d538178ac0bb9e183d51cf", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "2139094", gasUsed: "23654", confirmations: "3127472"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511549017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "75992965000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614721", timeStamp: "1511549184", hash: "0xff1306a45652f0a11227095717e8f16df9f86a73abdf0e069a34eea4d2fbb39b", nonce: "6", blockHash: "0xb4fcea1d1a08fc02ec1a0574ceb855aecd977c6b2ccf1f98d6712fa5dd0df563", transactionIndex: "22", from: "0x00a18486ec14de7946d538178ac0bb9e183d51cf", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "613329", gasUsed: "23654", confirmations: "3127457"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511549184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "75992965000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614732", timeStamp: "1511549393", hash: "0x202469877da0a76bd638f4d18360b753212709283e0c1c0a88e1047fb65c6cd6", nonce: "8", blockHash: "0x73cfb40041041b4dd4e4755e256d709043d900ec12421e178bb254622dd8ddd5", transactionIndex: "1", from: "0x2b51e24e3ce2a75956e0efe4b9fd744685f8acfb", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "59000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "128543", gasUsed: "107543", confirmations: "3127446"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511549393 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x2b51e24e3ce2a75956e0efe4b9fd744685f8acfb"}, {name: "tokenCount", type: "uint256", value: "8707803051859433096828"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "112882041000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614746", timeStamp: "1511549547", hash: "0xd9ac94086638f8e0e5ca5e8cd8f2a2e4467f1c1652dfd7e4c619acee783f8362", nonce: "9", blockHash: "0xc4740157cfb90818a0eafaec6b622b27fbc55b87cf751eaed61fae74ce19a26b", transactionIndex: "1", from: "0x2b51e24e3ce2a75956e0efe4b9fd744685f8acfb", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "59000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "44654", gasUsed: "23654", confirmations: "3127432"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511549547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "112882041000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614748", timeStamp: "1511549573", hash: "0x29b6a565969923c497acd1367ea7b79093cc74c47f72239428db69dafa2cd072", nonce: "54", blockHash: "0xf64b599f622ad12967e4201e91c49f41b0d8b307724ae45733e280fb6c61e185", transactionIndex: "5", from: "0x99752bac97008d6bc2a6946d62378920b47563de", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "44691", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "628188", gasUsed: "44691", confirmations: "3127430"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511549573 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "41622862000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614758", timeStamp: "1511549692", hash: "0x2d1b33c6448b6b2d2580a97ee7cc5c996790b174eb9855dc4280ae270a82b064", nonce: "10", blockHash: "0x1bf980e22c91ff1585e42a2e62c4ff0efa45fda2f1b59382d7e54204eb35b0c1", transactionIndex: "1", from: "0x2b51e24e3ce2a75956e0efe4b9fd744685f8acfb", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "200000", gasPrice: "59000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "44654", gasUsed: "23654", confirmations: "3127420"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511549692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "112882041000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614759", timeStamp: "1511549711", hash: "0xfc12c038361caf5a84f6fa7620ac7f9100e27f34036f8de502d6864baaa40fb6", nonce: "7", blockHash: "0x0d3aea092d617cd8151dd60a127ea8ea4cc99897fcbe5618eae6baa2b1ede190", transactionIndex: "13", from: "0x00a18486ec14de7946d538178ac0bb9e183d51cf", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "870928", gasUsed: "23654", confirmations: "3127419"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511549711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "75992965000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614763", timeStamp: "1511549741", hash: "0x973e67c498bdfca859c5e6f52289f046e8b50b44d7e7cf41db4ac377c8ab558d", nonce: "3", blockHash: "0xbf5897ab87d7b06c5d133c34312cfa56a9ace796a582510d0d049f52fc4fb55c", transactionIndex: "2", from: "0xee5905cd4c89c0cb178aeb12a4bcd26e9ea47d72", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "222733", gasUsed: "107543", confirmations: "3127415"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511549741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xee5905cd4c89c0cb178aeb12a4bcd26e9ea47d72"}, {name: "tokenCount", type: "uint256", value: "6228394292667896400304"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "48389057890390846" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614786", timeStamp: "1511549972", hash: "0x9e0aa032351db81bd9ba3477df8c84d7a9258c3af8a407a6caeeef8af7c691d6", nonce: "41", blockHash: "0xe0ece1f608ead7f8c560184d6d87c0e437cb67f0871a9d74b829dddb93da759d", transactionIndex: "59", from: "0x4ceaf6b478432b21d6e1c4247e9bbfb420177751", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "6185903", gasUsed: "107543", confirmations: "3127392"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511549972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x4ceaf6b478432b21d6e1c4247e9bbfb420177751"}, {name: "tokenCount", type: "uint256", value: "2643706929981337320992"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "3164851575173415" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614934", timeStamp: "1511551803", hash: "0x0f0ca1a0daa2dfe50d9d1744983d860aebd2a768223f5a5a025d5fdbb7240018", nonce: "215", blockHash: "0x22d17335548b78fb5c96e3c58c31eec8de3e5ab46ad0be386439dd2228731b4a", transactionIndex: "102", from: "0x7dafd53aee8982ab1d767830c2fe50f62e3a98e6", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "123023", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "3225558", gasUsed: "123023", confirmations: "3127244"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511551803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x7dafd53aee8982ab1d767830c2fe50f62e3a98e6"}, {name: "tokenCount", type: "uint256", value: "9711919399866864370371"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "3655580690883391" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614950", timeStamp: "1511552051", hash: "0x3c50a43fb25304d2db289fc19d2413a3d1db98e0acbaf70ab8c13e5492a804ec", nonce: "18", blockHash: "0x811d0188daa53e85827233c63d385148db7fd822a4d0631c17b34f362de6bdc2", transactionIndex: "3", from: "0xdb476022b386999023ba303e3004b4e98a0e2e3a", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "258671", gasUsed: "107543", confirmations: "3127228"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511552051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xdb476022b386999023ba303e3004b4e98a0e2e3a"}, {name: "tokenCount", type: "uint256", value: "12962959717566996744679"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "105424546712206495" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4614977", timeStamp: "1511552489", hash: "0xc4cc46d79dccee436cc4cc56c09f7cdf8f56ed57594fd0dd4fb920b346d59466", nonce: "182", blockHash: "0xf3d58cec53a6fd179ab8d4dd09c79a23606198b95600304d88f7db18930ba2b0", transactionIndex: "1", from: "0xb1fe569478506aefec2bcc84321e8d2053fe3fbb", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "300000", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "128543", gasUsed: "107543", confirmations: "3127201"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511552489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0xb1fe569478506aefec2bcc84321e8d2053fe3fbb"}, {name: "tokenCount", type: "uint256", value: "385021975992260049259"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "205900000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4615004", timeStamp: "1511552864", hash: "0x26ef4f7817b208c05993a1ad2eb694704d618b20fed0c1e8ef135b5d8a6d5d0d", nonce: "3", blockHash: "0x7b893c1133859943e47b404f21e3c035912f167dcbbd02eeb068fdab847e4d5d", transactionIndex: "32", from: "0x004fbf4dcb63d94b9b807274141dde45994aed2c", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "107543", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "980557", gasUsed: "107543", confirmations: "3127174"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511552864 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "purchaser", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "TokenWithdrawn", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenWithdrawn", events: [{name: "purchaser", type: "address", value: "0x004fbf4dcb63d94b9b807274141dde45994aed2c"}, {name: "tokenCount", type: "uint256", value: "6497245844869388331253"}], address: "0x54c548703c6f423cf7ed22806b608d332fcebb3b"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "29519150000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4615004", timeStamp: "1511552864", hash: "0xfdff397a52b0a377556f2a91a02c1e1a7f5b2274df410f4d1bbbfee916f04486", nonce: "183", blockHash: "0x7b893c1133859943e47b404f21e3c035912f167dcbbd02eeb068fdab847e4d5d", transactionIndex: "79", from: "0xb1fe569478506aefec2bcc84321e8d2053fe3fbb", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "1000000", gasPrice: "50000000000", isError: "0", txreceipt_status: "0", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "4181524", gasUsed: "23654", confirmations: "3127174"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511552864 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "205900000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPurchasedTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "4615010", timeStamp: "1511552956", hash: "0x679ecaf5afd94839bf9d0eb158e5215bfe2d7bf1fcce156fd1547a5f4f6ab348", nonce: "22", blockHash: "0xfbcfa42518e1757a9513f5815b7d3b81f72462c6c0973b903cdf39a1eb6f8caa", transactionIndex: "11", from: "0xa5f66eafb02db5ccacc4af8adb536090c362f9b6", to: "0x54c548703c6f423cf7ed22806b608d332fcebb3b", value: "0", gas: "44691", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbecd7027", contractAddress: "", cumulativeGasUsed: "276913", gasUsed: "44691", confirmations: "3127168"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPurchasedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPurchasedTokens()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511552956 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "5283525991936440" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
