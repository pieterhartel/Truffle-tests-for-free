const SecondPriceAuction = artifacts.require( "./SecondPriceAuction.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SecondPriceAuction" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x54a2d42a40F51259DedD1978F6c118a0f0Eff078", "0x000355D475475a487E682c1940EC45664a32b308", "0x1e2F058C43ac8965938F6e9CA286685A3E63F24E", "0xb59f67A8BfF5d8Cd03f6AC17265c550Ed8F33907", "0x3BfC20f0B9aFcAcE800D73D2191166FF16540258", "0x0019CbE96BE7c69A8218237AaDff5f9657965F02", "0x00729f3355FdF72962E9734FFA26CCFF9e64C0Ac", "0x13376a50540351f4D0242E20256E857A80bC86b0", "0xaDdb5210DcE9127918Db041CaEE93BE7b50CE633", "0x386c6c6A0df3Ebf66B64cb34C6f8834b9711A2E1", "0x002408a2f9BBF1fEe7A53eB361F8eB2Ce47aa6af", "0x70f055cd7B671c7d5f167C93b506f30EE46C9938", "0xED53F7C273F524Da37F189E800b9bB66ec9EA26d", "0xE6C6C739e406Cf3ccb1c666D24CFd200585FaAFe", "0x001BDd794E80B596665dFED06d2876EEDFe4F1EC", "0x061C15a9cE506d6169Cb3f7269B6B426c1D7223c", "0x0569Baf12b57bE4808c0539B9eB6B34b0fca7466", "0xF170D28A026Ca70f9c4A011409cFf2D195d0359B", "0x17d907986cF67F89Bc3EF8E874391495a0640395", "0x00812Ef6564c068b4612E2c1f289358A115B2DdC", "0xD8F150fEB4983f36Ab7bf83F0829c94A00471c1E", "0x3Fb4981d33258835eD1de86668344EE3f08C626D", "0x005E42814cDf3Db319923b257A0e0A48e3Ee5350", "0x63C62D874eD1c6fB31eCF56529892875Ac6B467B", "0x4185524e7B4ec8f909A435F4Ac705f9348105b32", "0xE8Fc0738b7450ebf2b496CD15652b1805346be72", "0xD665D007E518f7Db66810C06aEC94cE80f1dC777", "0xB3C2a4ce7ce57A74371b7E3dAE8f3393229c2aaC", "0x2c840D94DCF091b87Fd63Db7Eb0885d9ca4B5f79", "0xB4fcdF9E6c5fC7AB486cb70177E3676f1dF239f4", "0x002309DF96687e44280BB72c3818358FAEeB699c", "0x7A669ef68dA390965Ed95CCE8F02f6A11a6520ba", "0x00004c5c68dE80a76948DfCF7a77045aF476d346", "0x6C11fA9F82689AA0D4D41F2ed3E3A80932707B46", "0x0017dD07201d4f2F7cf7B46d5B54f710Ab579F4C", "0xc163730557Af3cC84dFFd66afFB23d2347154257", "0x600011fEe56096e5858518Ba9d12C43474866e37", "0x4678b10000b032197AE5a403058Cd72096198650", "0x00FCaf0A13A98B04a3080D7e246FfA7D072777e7", "0x3518a8c749b8c46685B5bFBB5AC32932edAfC9F9", "0x6641a9a247811657A0c435567260eEA47c3FC81A", "0x00DB158028c2d7dB707c525956aA3fDE0409ecA0", "0x009978D735F1A23Bb6922B620c490AC4aBa66CFD", "0x44e5715F7db1a59DE2af178cDAD023b16E39dA31", "0x0055a15e869bB215E605335181284aEe8bE30A50", "0xC094df9784E3a409A27f39875a85D47fb9D6D520", "0x67936306C1490dB7C491B0fE56BCf067eDE1Fd28", "0x9f043f875302e01D60D90831Ca17593557969B10", "0x032F6B944721fD338858bcC0e323D9aFe77E0a40", "0xcd0cbe2EefA616252E493B03b5C2dbB9060784Ff", "0x00E5cDD4B7b3a78a4277749957553371cb6B2310", "0x022070e52aD6F0425f72feB16636FFFce243529C", "0xbdAc7423cA974DEB9f4D5db731cbc3f5C64E3f4B", "0x0887159799951fa038ECD71Dd8335d2c19D14d29", "0x0089698aB4f16050d36225631917D4Db489DC251"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "ERA_PERIOD", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "certifier", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isActive", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_value", type: "uint256"}], name: "bonus", outputs: [{name: "extra", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "eraIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalAccounted", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DIVISOR", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "buyins", outputs: [{name: "accounted", type: "uint128"}, {name: "received", type: "uint128"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BONUS_MIN_DURATION", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DUST_LIMIT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "calculateEndTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalFinalised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BONUS_LATCH", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "USDWEI", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenContract", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensAvailable", outputs: [{name: "tokens", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "beginTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lastNewInterest", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "STATEMENT_HASH", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxPurchase", outputs: [{name: "spend", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BONUS_MAX_DURATION", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentPrice", outputs: [{name: "weiPerIndivisibleTokenPart", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_value", type: "uint256"}], name: "theDeal", outputs: [{name: "accounted", type: "uint256"}, {name: "refund", type: "bool"}, {name: "price", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenCap", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "currentBonus", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "allFinalised", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "admin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "Buyin", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}], name: "Uninjected", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "era", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}, {indexed: false, name: "accounted", type: "uint256"}], name: "Ticked", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}], name: "Ended", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Finalised", type: "event"}, {anonymous: false, inputs: [], name: "Retired", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Buyin(address,uint256,uint256,uint256)", "Injected(address,uint256,uint256)", "Uninjected(address)", "Ticked(uint256,uint256,uint256)", "Ended(uint256)", "Finalised(address,uint256)", "Retired()"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x332ff6f9deafa8e3394664e234c5b6ecd51769ea7a7170a2bf25fa8687cf620e", "0x2ae7c31359dcbe79d8c73f09dfd8402987b1236967e2224d8d398f6f40f46dd7", "0xc807cb02fce253121bbcda57e2aba8cdfa080d7650a91ac39520a8a9e4b5ffa9", "0x82fbbe47003f3ca8230f7ab30eeabd25f09023e15ca04dc5bd49ac1a11a223b9", "0x601095663bda08ac0f932087ef2eb08e42e4bcd1927f3a8d9500f6ad2c5aef90", "0xd8a5cca1cc817d045ce0d6e405348bae3f2558baca99f954815924542f8e5164", "0xc15f68f0a72806ff3f8bf2435385a67c4c22413f1c7931ef7bcea718e6ffcf03"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4357051 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4357248 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_certifierContract", value: 4}, {type: "address", name: "_tokenContract", value: 5}, {type: "address", name: "_treasury", value: 6}, {type: "address", name: "_admin", value: 7}, {type: "uint256", name: "_beginTime", value: "1508061642"}, {type: "uint256", name: "_tokenCap", value: "5000000000"}], name: "SecondPriceAuction", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "ERA_PERIOD", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ERA_PERIOD()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "certifier", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "certifier()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isActive", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isActive()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_value", value: random.range( maxRandom )}], name: "bonus", outputs: [{name: "extra", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bonus(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "eraIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "eraIndex()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalAccounted", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalAccounted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DIVISOR", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DIVISOR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "buyins", outputs: [{name: "accounted", type: "uint128"}, {name: "received", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyins(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BONUS_MIN_DURATION", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BONUS_MIN_DURATION()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DUST_LIMIT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DUST_LIMIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "calculateEndTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateEndTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalFinalised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalFinalised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BONUS_LATCH", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BONUS_LATCH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "USDWEI", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "USDWEI()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenContract", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenContract()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensAvailable", outputs: [{name: "tokens", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensAvailable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "treasury()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "beginTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "beginTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lastNewInterest", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lastNewInterest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "STATEMENT_HASH", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "STATEMENT_HASH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxPurchase", outputs: [{name: "spend", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxPurchase()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BONUS_MAX_DURATION", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BONUS_MAX_DURATION()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentPrice", outputs: [{name: "weiPerIndivisibleTokenPart", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalReceived()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_value", value: random.range( maxRandom )}], name: "theDeal", outputs: [{name: "accounted", type: "uint256"}, {name: "refund", type: "bool"}, {name: "price", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "theDeal(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenCap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenCap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentBonus", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentBonus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "allFinalised", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allFinalised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "admin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "admin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SecondPriceAuction", function( accounts ) {

	it( "TEST: SecondPriceAuction( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4357051", timeStamp: "1507745739", hash: "0x8855a52e9e244a0b224f22d69b410109516753d04ddb0b00471a8169f8e90773", nonce: "1", blockHash: "0xa8d80d3a6de9116b7963bc65273d83931ca603b137b2f44628cc704bcc623045", transactionIndex: "19", from: "0x000355d475475a487e682c1940ec45664a32b308", to: 0, value: "0", gas: "1675024", gasPrice: "23001000004", isError: "0", txreceipt_status: "", input: "0x3f2febcb0000000000000000000000001e2f058c43ac8965938f6e9ca286685a3e63f24e000000000000000000000000b59f67a8bff5d8cd03f6ac17265c550ed8f339070000000000000000000000003bfc20f0b9afcace800d73d2191166ff165402580000000000000000000000000019cbe96be7c69a8218237aadff5f9657965f020000000000000000000000000000000000000000000000000000000059e331ca000000000000000000000000000000000000000000000000000000012a05f200", contractAddress: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", cumulativeGasUsed: "2016780", gasUsed: "1395853", confirmations: "3360488"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_certifierContract", value: addressList[4]}, {type: "address", name: "_tokenContract", value: addressList[5]}, {type: "address", name: "_treasury", value: addressList[6]}, {type: "address", name: "_admin", value: addressList[7]}, {type: "uint256", name: "_beginTime", value: "1508061642"}, {type: "uint256", name: "_tokenCap", value: "5000000000"}], name: "SecondPriceAuction", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SecondPriceAuction.new( addressList[4], addressList[5], addressList[6], addressList[7], "1508061642", "5000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1507745739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SecondPriceAuction.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "55213106499535152" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[8], \"3344000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357229", timeStamp: "1507750854", hash: "0xb189cb8a302ebea831c3d99db7407a0c90912be910d3b2631fd2039db0c9a060", nonce: "0", blockHash: "0x9f10f78ed68ad99ac2eaaa99620d21817eb29eff947959dbb3958ea279a22829", transactionIndex: "19", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000000729f3355fdf72962e9734ffa26ccff9e64c0ac0000000000000000000000000000000000000000000000b547528aba8a400000", contractAddress: "", cumulativeGasUsed: "959698", gasUsed: "94550", confirmations: "3360310"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[8]}, {type: "uint128", name: "_received", value: "3344000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[8], "3344000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1507750854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x00729f3355fdf72962e9734ffa26ccff9e64c0ac"}, {name: "accounted", type: "uint256", value: "3845600000000000000000"}, {name: "received", type: "uint256", value: "3344000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[9], \"300000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357232", timeStamp: "1507750990", hash: "0xf3399a90a22a0cf56ec2ebf636a3a59d3d20b642a52c4ad5231517059385ebf3", nonce: "1", blockHash: "0x7b5fa6d869f270aaebabce45f555cb2df804d9fad4a44a9b79da73d477b9bded", transactionIndex: "121", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000013376a50540351f4d0242e20256e857a80bc86b000000000000000000000000000000000000000000000001043561a8829300000", contractAddress: "", cumulativeGasUsed: "4103557", gasUsed: "64614", confirmations: "3360307"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[9]}, {type: "uint128", name: "_received", value: "300000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[9], "300000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1507750990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x13376a50540351f4d0242e20256e857a80bc86b0"}, {name: "accounted", type: "uint256", value: "345000000000000000000"}, {name: "received", type: "uint256", value: "300000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[10], \"350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x73b97c4ec0eb5f85256c934079f71b533637f9d1cb9c6115c477c5f84ef243ff", nonce: "2", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "59", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000addb5210dce9127918db041caee93be7b50ce633000000000000000000000000000000000000000000000012f939c99edab80000", contractAddress: "", cumulativeGasUsed: "2410851", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[10]}, {type: "uint128", name: "_received", value: "350000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[10], "350000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xaddb5210dce9127918db041caee93be7b50ce633"}, {name: "accounted", type: "uint256", value: "402500000000000000000"}, {name: "received", type: "uint256", value: "350000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[11], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xac7b9201b3946b34c27fdd1761ace127b7b192f49eda44b34eecea205f91fb81", nonce: "3", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "60", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000386c6c6a0df3ebf66b64cb34c6f8834b9711a2e100000000000000000000000000000000000000000000000ad78ebc5ac6200000", contractAddress: "", cumulativeGasUsed: "2475465", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[11]}, {type: "uint128", name: "_received", value: "200000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[11], "200000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x386c6c6a0df3ebf66b64cb34c6f8834b9711a2e1"}, {name: "accounted", type: "uint256", value: "230000000000000000000"}, {name: "received", type: "uint256", value: "200000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[12], \"194237617400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xdd3458cad4f3856ef252d8e33c29afb2adc90e068c850e5af0c46de5e48976f8", nonce: "4", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "61", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000002408a2f9bbf1fee7a53eb361f8eb2ce47aa6af0000000000000000000000000000000000000000000000694be2671a5c54e000", contractAddress: "", cumulativeGasUsed: "2540079", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[12]}, {type: "uint128", name: "_received", value: "1942376174000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[12], "1942376174000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x002408a2f9bbf1fee7a53eb361f8eb2ce47aa6af"}, {name: "accounted", type: "uint256", value: "2233732600100000000000"}, {name: "received", type: "uint256", value: "1942376174000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[13], \"16805028000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x3a4beadc1ac2c2a488626776c404a755a8cfb88b253a4455ff35553b2a36f22b", nonce: "5", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "62", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000070f055cd7b671c7d5f167c93b506f30ee46c9938000000000000000000000000000000000000000000000000e93773eddc7e4000", contractAddress: "", cumulativeGasUsed: "2604693", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[13]}, {type: "uint128", name: "_received", value: "16805028000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[13], "16805028000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x70f055cd7b671c7d5f167c93b506f30ee46c9938"}, {name: "accounted", type: "uint256", value: "19325782200000000000"}, {name: "received", type: "uint256", value: "16805028000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[14], \"67220112000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xed0c7c62fa83faa3264765e51ea411cc74e679fa696fb1f6e81aa9d0066b9a09", nonce: "6", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "63", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000ed53f7c273f524da37f189e800b9bb66ec9ea26d000000000000000000000000000000000000000000000003a4ddcfb771f90000", contractAddress: "", cumulativeGasUsed: "2669243", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[14]}, {type: "uint128", name: "_received", value: "67220112000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[14], "67220112000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xed53f7c273f524da37f189e800b9bb66ec9ea26d"}, {name: "accounted", type: "uint256", value: "77303128800000000000"}, {name: "received", type: "uint256", value: "67220112000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[15], \"48559404000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x862492b2843f5154cf720b346af307c64733f85c15e7dda67bf968cd84742747", nonce: "7", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "64", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000e6c6c739e406cf3ccb1c666d24cfd200585faafe000000000000000000000000000000000000000000000002a1e5a8a8c4aec000", contractAddress: "", cumulativeGasUsed: "2733857", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[15]}, {type: "uint128", name: "_received", value: "48559404000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[15], "48559404000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xe6c6c739e406cf3ccb1c666d24cfd200585faafe"}, {name: "accounted", type: "uint256", value: "55843314600000000000"}, {name: "received", type: "uint256", value: "48559404000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[16], \"110000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xda439414fba3f6b6afc9a09073d17d8de21285730e7e74ebb85fe4ad4e5adbc6", nonce: "8", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "65", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000001bdd794e80b596665dfed06d2876eedfe4f1ec0000000000000000000000000000000000000000000002544faa778090e00000", contractAddress: "", cumulativeGasUsed: "2798471", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[16]}, {type: "uint128", name: "_received", value: "11000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[16], "11000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x001bdd794e80b596665dfed06d2876eedfe4f1ec"}, {name: "accounted", type: "uint256", value: "12650000000000000000000"}, {name: "received", type: "uint256", value: "11000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[17], \"525000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x357af2b25e453d663c9b0d3f94480f629fa553608f13d51d6a0caf43b09f7640", nonce: "9", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "66", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000061c15a9ce506d6169cb3f7269b6b426c1d7223c00000000000000000000000000000000000000000000001c75d6ae6e48140000", contractAddress: "", cumulativeGasUsed: "2863085", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[17]}, {type: "uint128", name: "_received", value: "525000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[17], "525000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x061c15a9ce506d6169cb3f7269b6b426c1d7223c"}, {name: "accounted", type: "uint256", value: "603750000000000000000"}, {name: "received", type: "uint256", value: "525000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[18], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x07c4eeebf582cce84aaa4c8e1d2d88c3d90b521b0e3bd876bb04469bae769893", nonce: "10", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "67", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000000569baf12b57be4808c0539b9eb6b34b0fca74660000000000000000000000000000000000000000000000a2a15d09519be00000", contractAddress: "", cumulativeGasUsed: "2927699", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[18]}, {type: "uint128", name: "_received", value: "3000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[18], "3000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x0569baf12b57be4808c0539b9eb6b34b0fca7466"}, {name: "accounted", type: "uint256", value: "3450000000000000000000"}, {name: "received", type: "uint256", value: "3000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[19], \"350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x03f54d0e4c06b4d06e4f3121033caa3ebe31889d486471f29d2db46b9082b9d7", nonce: "11", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "68", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000f170d28a026ca70f9c4a011409cff2d195d0359b0000000000000000000000000000000000000000000000bdbc41e0348b300000", contractAddress: "", cumulativeGasUsed: "2992313", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[19]}, {type: "uint128", name: "_received", value: "3500000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[19], "3500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xf170d28a026ca70f9c4a011409cff2d195d0359b"}, {name: "accounted", type: "uint256", value: "4025000000000000000000"}, {name: "received", type: "uint256", value: "3500000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[20], \"250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xe44ac09b2622d722e2309b2f4a074e2b95cadda3d639ddab12791fbb9144f816", nonce: "12", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "69", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000017d907986cf67f89bc3ef8e874391495a064039500000000000000000000000000000000000000000000000d8d726b7177a80000", contractAddress: "", cumulativeGasUsed: "3056927", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[20]}, {type: "uint128", name: "_received", value: "250000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[20], "250000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x17d907986cf67f89bc3ef8e874391495a0640395"}, {name: "accounted", type: "uint256", value: "287500000000000000000"}, {name: "received", type: "uint256", value: "250000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[21], \"280000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x4903ddae47c951a53b3927e33eb249262006888273308b242e9a480c32f7f26d", nonce: "13", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "70", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000000812ef6564c068b4612e2c1f289358a115b2ddc00000000000000000000000000000000000000000000000f2dc7d47f15600000", contractAddress: "", cumulativeGasUsed: "3121477", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[21]}, {type: "uint128", name: "_received", value: "280000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[21], "280000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x00812ef6564c068b4612e2c1f289358a115b2ddc"}, {name: "accounted", type: "uint256", value: "322000000000000000000"}, {name: "received", type: "uint256", value: "280000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[22], \"450000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x58e8233f3db834b7a2ae0fcfe49d17783d518db6caf4c7ce7a8193b4b57882dc", nonce: "14", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "71", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000d8f150feb4983f36ab7bf83f0829c94a00471c1e0000000000000000000000000000000000000000000000f3f20b8dfa69d00000", contractAddress: "", cumulativeGasUsed: "3186027", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[22]}, {type: "uint128", name: "_received", value: "4500000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[22], "4500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xd8f150feb4983f36ab7bf83f0829c94a00471c1e"}, {name: "accounted", type: "uint256", value: "5175000000000000000000"}, {name: "received", type: "uint256", value: "4500000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[23], \"292600000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x9c44100ff91a1c50dde4739e87f38e06daf875eaca38912ae2b0cd002887854b", nonce: "15", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "72", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000003fb4981d33258835ed1de86668344ee3f08c626d00000000000000000000000000000000000000000000009e9e68396338f80000", contractAddress: "", cumulativeGasUsed: "3250641", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[23]}, {type: "uint128", name: "_received", value: "2926000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[23], "2926000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x3fb4981d33258835ed1de86668344ee3f08c626d"}, {name: "accounted", type: "uint256", value: "3364900000000000000000"}, {name: "received", type: "uint256", value: "2926000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[24], \"318000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x797aae4fdd21e6c9b3727e26022a0bb03bc3ce5a9e1a79b51906b5e018b4a854", nonce: "16", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "73", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000005e42814cdf3db319923b257a0e0a48e3ee53500000000000000000000000000000000000000000000000ac635d7fa34e300000", contractAddress: "", cumulativeGasUsed: "3315191", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[24]}, {type: "uint128", name: "_received", value: "3180000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[24], "3180000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x005e42814cdf3db319923b257a0e0a48e3ee5350"}, {name: "accounted", type: "uint256", value: "3657000000000000000000"}, {name: "received", type: "uint256", value: "3180000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[25], \"672201123000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xb7b409def5b35ce1073770e1fa3a10ed9a09009bd6385040e0d8c2015481cc46", nonce: "17", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "74", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000063c62d874ed1c6fb31ecf56529892875ac6b467b00000000000000000000000000000000000000000000002470aa1fe4f1a93000", contractAddress: "", cumulativeGasUsed: "3379869", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[25]}, {type: "uint128", name: "_received", value: "672201123000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[25], "672201123000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x63c62d874ed1c6fb31ecf56529892875ac6b467b"}, {name: "accounted", type: "uint256", value: "773031291450000000000"}, {name: "received", type: "uint256", value: "672201123000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[26], \"330000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xce106cfd9b8020b3e369ab736467375d172b30771cc7c95b33b6471c54ea9346", nonce: "18", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "75", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000004185524e7b4ec8f909a435f4ac705f9348105b32000000000000000000000000000000000000000000000011e3ab8395c6e80000", contractAddress: "", cumulativeGasUsed: "3444483", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[26]}, {type: "uint128", name: "_received", value: "330000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[26], "330000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x4185524e7b4ec8f909a435f4ac705f9348105b32"}, {name: "accounted", type: "uint256", value: "379500000000000000000"}, {name: "received", type: "uint256", value: "330000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[27], \"97130854000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x2aeea36b409c7505b2bb43d1e16175e682d4f8aead62682d41048bc952c9c03d", nonce: "19", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "76", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000e8fc0738b7450ebf2b496cd15652b1805346be7200000000000000000000000000000000000000000000000543f61d1778546000", contractAddress: "", cumulativeGasUsed: "3509161", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[27]}, {type: "uint128", name: "_received", value: "97130854000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[27], "97130854000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xe8fc0738b7450ebf2b496cd15652b1805346be72"}, {name: "accounted", type: "uint256", value: "111700482100000000000"}, {name: "received", type: "uint256", value: "97130854000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[28], \"504150842000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xb0f84faae306bd866db2f8c5cf30a9d5a447ae371e630031b233b1d5fb835b3e", nonce: "20", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "77", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "1", txreceipt_status: "", input: "0xbac6068c000000000000000000000000d665d007e518f7db66810c06aec94ce80f1dc77700000000000000000000000000000000000000000000001b547f97b18015a000", contractAddress: "", cumulativeGasUsed: "4449161", gasUsed: "940000", confirmations: "3360305"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[28]}, {type: "uint128", name: "_received", value: "504150842000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[29], \"900000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x66bb990d2f4d039eddc1eafc9a97cb9e4327cfea56c553d9ee67226ad72fdbbe", nonce: "21", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "78", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000b3c2a4ce7ce57a74371b7e3dae8f3393229c2aac000000000000000000000000000000000000000000000030ca024f987b900000", contractAddress: "", cumulativeGasUsed: "4513775", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[29]}, {type: "uint128", name: "_received", value: "900000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[29], "900000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xb3c2a4ce7ce57a74371b7e3dae8f3393229c2aac"}, {name: "accounted", type: "uint256", value: "1035000000000000000000"}, {name: "received", type: "uint256", value: "900000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[30], \"330000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xaefb854c5cd49889494558fba3d6900e69631f0a273dec6caa19d238468d45e6", nonce: "22", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "79", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000002c840d94dcf091b87fd63db7eb0885d9ca4b5f790000000000000000000000000000000000000000000000b2e4b323d9c5100000", contractAddress: "", cumulativeGasUsed: "4578389", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[30]}, {type: "uint128", name: "_received", value: "3300000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[30], "3300000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x2c840d94dcf091b87fd63db7eb0885d9ca4b5f79"}, {name: "accounted", type: "uint256", value: "3795000000000000000000"}, {name: "received", type: "uint256", value: "3300000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[31], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x4b77f602cdbcb03e6a974be7dea2b2cfe620b41fc30c7c16d92f2d056f871e78", nonce: "23", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "80", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000b4fcdf9e6c5fc7ab486cb70177e3676f1df239f400000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "4643003", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[31]}, {type: "uint128", name: "_received", value: "2000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[31], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xb4fcdf9e6c5fc7ab486cb70177e3676f1df239f4"}, {name: "accounted", type: "uint256", value: "2300000000000000000000"}, {name: "received", type: "uint256", value: "2000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[32], \"555000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x1add63933ea46bcf5cc0f079b142fa43eac920f57d50e0ff4a630509fdd60753", nonce: "24", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "81", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000002309df96687e44280bb72c3818358faeeb699c00000000000000000000000000000000000000000000001e162c177be5cc0000", contractAddress: "", cumulativeGasUsed: "4707553", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[32]}, {type: "uint128", name: "_received", value: "555000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[32], "555000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x002309df96687e44280bb72c3818358faeeb699c"}, {name: "accounted", type: "uint256", value: "638250000000000000000"}, {name: "received", type: "uint256", value: "555000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[33], \"100830168000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x626340168b9950ed8f2c73aa908f7eb411560846efb1ed62df4be96c0092c4eb", nonce: "25", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "82", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000007a669ef68da390965ed95cce8f02f6a11a6520ba000000000000000000000000000000000000000000000005774cb7932af58000", contractAddress: "", cumulativeGasUsed: "4772231", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[33]}, {type: "uint128", name: "_received", value: "100830168000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[33], "100830168000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x7a669ef68da390965ed95cce8f02f6a11a6520ba"}, {name: "accounted", type: "uint256", value: "115954693200000000000"}, {name: "received", type: "uint256", value: "100830168000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[34], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x32ad5d6289743246b37b21708aee258efb571f0a2458e86357e77ec71199a36d", nonce: "26", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "83", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000000004c5c68de80a76948dfcf7a77045af476d34600000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4836717", gasUsed: "64486", confirmations: "3360305"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[34]}, {type: "uint128", name: "_received", value: "1500000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[34], "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x00004c5c68de80a76948dfcf7a77045af476d346"}, {name: "accounted", type: "uint256", value: "1725000000000000000000"}, {name: "received", type: "uint256", value: "1500000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[35], \"2618647000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xe49760a8976f30971d1fde8af269af88fca63dbd2950dd3b0d8455f3682a38a8", nonce: "27", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "84", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000006c11fa9f82689aa0d4d41f2ed3e3a80932707b4600000000000000000000000000000000000000000000000024574d9283247000", contractAddress: "", cumulativeGasUsed: "4901331", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[35]}, {type: "uint128", name: "_received", value: "2618647000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[35], "2618647000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x6c11fa9f82689aa0d4d41f2ed3e3a80932707b46"}, {name: "accounted", type: "uint256", value: "3011444050000000000"}, {name: "received", type: "uint256", value: "2618647000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[36], \"40332067000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x4494244bba4988b97a9696f2fe07216fcbe461917568481be42fccc75e0f0bcd", nonce: "28", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "85", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000000017dd07201d4f2f7cf7b46d5b54f710ab579f4c0000000000000000000000000000000000000000000000022fb8493f80413000", contractAddress: "", cumulativeGasUsed: "4965945", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[36]}, {type: "uint128", name: "_received", value: "40332067000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[36], "40332067000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x0017dd07201d4f2f7cf7b46d5b54f710ab579f4c"}, {name: "accounted", type: "uint256", value: "46381877050000000000"}, {name: "received", type: "uint256", value: "40332067000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[37], \"168050281000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xd8e7a1acd44cc97351a93aea376c01aec65d14e56dc8873add3bbf1c32defa8c", nonce: "29", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "86", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000c163730557af3cc84dffd66affb23d23471542570000000000000000000000000000000000000000000000091c2a883371939000", contractAddress: "", cumulativeGasUsed: "5030623", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[37]}, {type: "uint128", name: "_received", value: "168050281000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[37], "168050281000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xc163730557af3cc84dffd66affb23d2347154257"}, {name: "accounted", type: "uint256", value: "193257823150000000000"}, {name: "received", type: "uint256", value: "168050281000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[38], \"180000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xed4b1cb274ca4fa88f60950df57507648a2efda09fd6423c9800169998c1be2d", nonce: "30", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "87", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000600011fee56096e5858518ba9d12c43474866e37000000000000000000000000000000000000000000000009c2007651b2500000", contractAddress: "", cumulativeGasUsed: "5095109", gasUsed: "64486", confirmations: "3360305"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[38]}, {type: "uint128", name: "_received", value: "180000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[38], "180000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x600011fee56096e5858518ba9d12c43474866e37"}, {name: "accounted", type: "uint256", value: "207000000000000000000"}, {name: "received", type: "uint256", value: "180000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[39], \"700000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xa04243644fac0b81f24b6d02ccb5656db80a2ee92299bf0d443a236160dada8f", nonce: "31", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "88", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000004678b10000b032197ae5a403058cd7209619865000000000000000000000000000000000000000000000017b7883c06916600000", contractAddress: "", cumulativeGasUsed: "5159659", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[39]}, {type: "uint128", name: "_received", value: "7000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[39], "7000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x4678b10000b032197ae5a403058cd72096198650"}, {name: "accounted", type: "uint256", value: "8050000000000000000000"}, {name: "received", type: "uint256", value: "7000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[40], \"98721137000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x2585596ed0ae2f530eab985ced9e98582a408109c7540aafe4c73736d566375f", nonce: "32", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "89", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000000fcaf0a13a98b04a3080d7e246ffa7d072777e70000000000000000000000000000000000000000000000055a07ef0df3ac1000", contractAddress: "", cumulativeGasUsed: "5224273", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[40]}, {type: "uint128", name: "_received", value: "98721137000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[40], "98721137000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x00fcaf0a13a98b04a3080d7e246ffa7d072777e7"}, {name: "accounted", type: "uint256", value: "113529307550000000000"}, {name: "received", type: "uint256", value: "98721137000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[41], \"504108157000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xc3c45f0fc1358d7e7130678f2924f6e9c5c0810431bca3ce88006b068eef94dc", nonce: "33", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "90", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000003518a8c749b8c46685b5bfbb5ac32932edafc9f900000000000000000000000000000000000000000000001b53e7f1e979d8d000", contractAddress: "", cumulativeGasUsed: "5288951", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[41]}, {type: "uint128", name: "_received", value: "504108157000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[41], "504108157000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x3518a8c749b8c46685b5bfbb5ac32932edafc9f9"}, {name: "accounted", type: "uint256", value: "579724380550000000000"}, {name: "received", type: "uint256", value: "504108157000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[42], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x46dfd152f61b04ac8f7d56ccd427b8653cccc0c600e31cf276d34cee2f6a5a6f", nonce: "34", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "91", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000006641a9a247811657a0c435567260eea47c3fc81a000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "5353565", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[42]}, {type: "uint128", name: "_received", value: "50000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[42], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x6641a9a247811657a0c435567260eea47c3fc81a"}, {name: "accounted", type: "uint256", value: "57500000000000000000"}, {name: "received", type: "uint256", value: "50000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[43], \"134440225000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x9dc52e0dada1508dc2e02b664618c727a57ea8fd978c4729583f9781070fddf6", nonce: "35", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "92", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000000db158028c2d7db707c525956aa3fde0409eca000000000000000000000000000000000000000000000000749bba057b8971000", contractAddress: "", cumulativeGasUsed: "5418179", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[43]}, {type: "uint128", name: "_received", value: "134440225000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[43], "134440225000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x00db158028c2d7db707c525956aa3fde0409eca0"}, {name: "accounted", type: "uint256", value: "154606258750000000000"}, {name: "received", type: "uint256", value: "134440225000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[44], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xe62bc430094dfb4554edfaebb7961f728ecfe340082421ff0228d2840df2ecad", nonce: "36", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "93", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000009978d735f1a23bb6922b620c490ac4aba66cfd00000000000000000000000000000000000000000000010f0cf064dd59200000", contractAddress: "", cumulativeGasUsed: "5482793", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[44]}, {type: "uint128", name: "_received", value: "5000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[44], "5000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x009978d735f1a23bb6922b620c490ac4aba66cfd"}, {name: "accounted", type: "uint256", value: "5750000000000000000000"}, {name: "received", type: "uint256", value: "5000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[45], \"350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x6f2df4397773a080c12a03741cd61b15e21455b88fc7b34c1f87006e05b80fef", nonce: "37", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "94", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000044e5715f7db1a59de2af178cdad023b16e39da310000000000000000000000000000000000000000000007695a92c20d6fe00000", contractAddress: "", cumulativeGasUsed: "5547471", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[45]}, {type: "uint128", name: "_received", value: "35000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[45], "35000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x44e5715f7db1a59de2af178cdad023b16e39da31"}, {name: "accounted", type: "uint256", value: "40250000000000000000000"}, {name: "received", type: "uint256", value: "35000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[46], \"863500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x8dca2cefd258713c76b31c10e6664c7ea8377d4121cb293f9364f7234c178ee8", nonce: "38", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "95", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000000055a15e869bb215e605335181284aee8be30a5000000000000000000000000000000000000000000000002ecf7842fb1dce0000", contractAddress: "", cumulativeGasUsed: "5612021", gasUsed: "64550", confirmations: "3360305"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[46]}, {type: "uint128", name: "_received", value: "863500000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[46], "863500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x0055a15e869bb215e605335181284aee8be30a50"}, {name: "accounted", type: "uint256", value: "993025000000000000000"}, {name: "received", type: "uint256", value: "863500000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[47], \"809323405600000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x66ae640fdcbe03bcf29b662e1c27f6151b3b01239b84c5dacb8aa9cd09e4a2bc", nonce: "39", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "96", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000c094df9784e3a409a27f39875a85d47fb9d6d5200000000000000000000000000000000000000000000001b6bc2f5623e5e08000", contractAddress: "", cumulativeGasUsed: "5676763", gasUsed: "64742", confirmations: "3360305"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[47]}, {type: "uint128", name: "_received", value: "8093234056000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[47], "8093234056000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xc094df9784e3a409a27f39875a85d47fb9d6d520"}, {name: "accounted", type: "uint256", value: "9307219164400000000000"}, {name: "received", type: "uint256", value: "8093234056000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[48], \"809323406000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0x87794bc575822e31e3d36c3b447cec7a95dcf4d0c8b57896294d30bb41efea5b", nonce: "40", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "97", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000067936306c1490db7c491b0fe56bcf067ede1fd2800000000000000000000000000000000000000000000002bdf9e55c71f3ee000", contractAddress: "", cumulativeGasUsed: "5741441", gasUsed: "64678", confirmations: "3360305"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[48]}, {type: "uint128", name: "_received", value: "809323406000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[48], "809323406000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x67936306c1490db7c491b0fe56bcf067ede1fd28"}, {name: "accounted", type: "uint256", value: "930721916900000000000"}, {name: "received", type: "uint256", value: "809323406000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[49], \"415000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357234", timeStamp: "1507751025", hash: "0xec0f87c9815c20fab40de028aedf90ad18cacc67aaef19e199aca4d7388dbc1d", nonce: "41", blockHash: "0xba84143f6c4b8e947a84d71dd512c1906996779b7bec5ada25c51c90ce476277", transactionIndex: "98", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000009f043f875302e01d60d90831ca17593557969b100000000000000000000000000000000000000000000000167f482d3c5b1c0000", contractAddress: "", cumulativeGasUsed: "5806055", gasUsed: "64614", confirmations: "3360305"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[49]}, {type: "uint128", name: "_received", value: "415000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[49], "415000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1507751025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x9f043f875302e01d60d90831ca17593557969b10"}, {name: "accounted", type: "uint256", value: "477250000000000000000"}, {name: "received", type: "uint256", value: "415000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[50], \"336100561000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357236", timeStamp: "1507751081", hash: "0x6bb2a11e831eb49ed9a97d8ee16342ff08e171a32ed7275f44fc445bd7f13326", nonce: "42", blockHash: "0x14fa214bd2566ffb2c3c4c005b09e282f572b1a32a188ca4aa573aabfc77a664", transactionIndex: "22", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000032f6b944721fd338858bcc0e323d9afe77e0a4000000000000000000000000000000000000000000000001238550f7e0e821000", contractAddress: "", cumulativeGasUsed: "1220782", gasUsed: "64678", confirmations: "3360303"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[50]}, {type: "uint128", name: "_received", value: "336100561000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[50], "336100561000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1507751081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x032f6b944721fd338858bcc0e323d9afe77e0a40"}, {name: "accounted", type: "uint256", value: "386515645150000000000"}, {name: "received", type: "uint256", value: "336100561000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[51], \"700000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357238", timeStamp: "1507751188", hash: "0x2402dee2677b6da242305fb11217685affce2618ba21d7f01bf524dc643da341", nonce: "43", blockHash: "0xbd6636a6211b99285fbaa487c09468b561af7a96b824a6fb8920f8ae2e20b3b2", transactionIndex: "26", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000cd0cbe2eefa616252e493b03b5c2dbb9060784ff000000000000000000000000000000000000000000000025f273933db5700000", contractAddress: "", cumulativeGasUsed: "2101667", gasUsed: "64614", confirmations: "3360301"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[51]}, {type: "uint128", name: "_received", value: "700000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[51], "700000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1507751188 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xcd0cbe2eefa616252e493b03b5c2dbb9060784ff"}, {name: "accounted", type: "uint256", value: "805000000000000000000"}, {name: "received", type: "uint256", value: "700000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[52], \"598899320000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357240", timeStamp: "1507751264", hash: "0x89a66367a84f152bee94899643795dde2e9c525fad02a9cbb5954db27fc61924", nonce: "44", blockHash: "0x5c4b361ad067067502c6195e226e20e3e99a565bb2db2f9e4f6252c1fa02acab", transactionIndex: "34", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c00000000000000000000000000e5cdd4b7b3a78a4277749957553371cb6b23100000000000000000000000000000000000000000000000207765ce6f76ff8000", contractAddress: "", cumulativeGasUsed: "2239198", gasUsed: "64614", confirmations: "3360299"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[52]}, {type: "uint128", name: "_received", value: "598899320000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[52], "598899320000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1507751264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x00e5cdd4b7b3a78a4277749957553371cb6b2310"}, {name: "accounted", type: "uint256", value: "688734218000000000000"}, {name: "received", type: "uint256", value: "598899320000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[53], \"260932340600000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357241", timeStamp: "1507751319", hash: "0xd682cdf9459c9f2e90cd99667136dfcc7263d49699cb58c537e1a6aa7917b5a5", nonce: "45", blockHash: "0x4ea52a733850a7fa56cac79b34e9e390c5d58e0d833d06f22f1009bcae4a5421", transactionIndex: "83", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000022070e52ad6f0425f72feb16636fffce243529c00000000000000000000000000000000000000000000008d73a2f4f8165ee000", contractAddress: "", cumulativeGasUsed: "2642940", gasUsed: "64678", confirmations: "3360298"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[53]}, {type: "uint128", name: "_received", value: "2609323406000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[53], "2609323406000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1507751319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x022070e52ad6f0425f72feb16636fffce243529c"}, {name: "accounted", type: "uint256", value: "3000721916900000000000"}, {name: "received", type: "uint256", value: "2609323406000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[54], \"168050280600000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357242", timeStamp: "1507751360", hash: "0xe0318529505dd1a9e374bde7323dcdb9de58ab31e3783fdf84f4b66d02bb9463", nonce: "46", blockHash: "0xf77771a0baa8d091f834c7b32ea04acfb9ee123a785e3d1c8c409e7a8e25377d", transactionIndex: "95", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c000000000000000000000000bdac7423ca974deb9f4d5db731cbc3f5c64e3f4b00000000000000000000000000000000000000000000005b19a94e5f1d2f6000", contractAddress: "", cumulativeGasUsed: "3172538", gasUsed: "64678", confirmations: "3360297"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[54]}, {type: "uint128", name: "_received", value: "1680502806000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[54], "1680502806000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1507751360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0xbdac7423ca974deb9f4d5db731cbc3f5c64e3f4b"}, {name: "accounted", type: "uint256", value: "1932578226900000000000"}, {name: "received", type: "uint256", value: "1680502806000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[55], \"169957915000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357246", timeStamp: "1507751459", hash: "0x2d604d25cb0af9507307d19dbe9f4eda9d47ecd0da5149c2c6bab99d1958e03c", nonce: "47", blockHash: "0x3c06572c71cfab0e796f110a1bcdc1b83995274be4b4ba5a62585d1fe3bffd62", transactionIndex: "52", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000000887159799951fa038ecd71dd8335d2c19d14d2900000000000000000000000000000000000000000000000936a3cf378508b000", contractAddress: "", cumulativeGasUsed: "2589579", gasUsed: "64678", confirmations: "3360293"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[55]}, {type: "uint128", name: "_received", value: "169957915000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[55], "169957915000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1507751459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x0887159799951fa038ecd71dd8335d2c19d14d29"}, {name: "accounted", type: "uint256", value: "195451602250000000000"}, {name: "received", type: "uint256", value: "169957915000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: inject( addressList[56], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4357248", timeStamp: "1507751524", hash: "0x13eb10f749f5b4087378e861e9a1a8443f22f1676591f8d2eb1359a4dbb08948", nonce: "48", blockHash: "0x74caa600527116c5ca3b111c6b37d42ee727b64efbc0ed3e700a5c589243c46a", transactionIndex: "25", from: "0x0019cbe96be7c69a8218237aadff5f9657965f02", to: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078", value: "0", gas: "940000", gasPrice: "22284624259", isError: "0", txreceipt_status: "", input: "0xbac6068c0000000000000000000000000089698ab4f16050d36225631917d4db489dc25100000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "2019824", gasUsed: "64550", confirmations: "3360291"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_who", value: addressList[56]}, {type: "uint128", name: "_received", value: "1000000000000000000000"}], name: "inject", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "inject(address,uint128)" ]( addressList[56], "1000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1507751524 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "accounted", type: "uint256"}, {indexed: false, name: "received", type: "uint256"}], name: "Injected", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Injected", events: [{name: "who", type: "address", value: "0x0089698ab4f16050d36225631917d4db489dc251"}, {name: "accounted", type: "uint256", value: "1150000000000000000000"}, {name: "received", type: "uint256", value: "1000000000000000000000"}], address: "0x54a2d42a40f51259dedd1978f6c118a0f0eff078"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1835897144113978540" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
