const StarbaseMarketingCampaign = artifacts.require( "./StarbaseMarketingCampaign.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "StarbaseMarketingCampaign" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xED9d813c4a82A9D76ebA8Ea666A7A0ab95F7bb29", "0xC00cc57df9F1Fe1EBc9Eb660e7B98A6E7CbCFF21", "0x00aFF4aE48e55fe4032a542745512e07CcEf8F4B", "0x0035F5fA0AadaEd083E5f4fb8Fae40624772091c", "0x00AC9A1B323A83b192C081DD39c4540D35145972", "0xF70a642bD387F94380fFb90451C2c81d4Eb82CBc", "0x07283Ba3173D6869d3395BB23272a7FA5D0B151E", "0x085DdA9064279c575b51B1A15282768387D1BDDD", "0x1Aea9A05535D63b7Bf132cBDF9B5b3d8Ba4B4f57", "0x02F1B4D2e91013e36A173600c1cda6Ec70A70eF2", "0x0D134Bd2B25c2e8bB6871283AF78Ac3Db7A53cDd", "0x2725FC22cDd2b41C50F0A564FE18597E876c70f7", "0x0B92db394eC8368aE1f1622ea48EfB23be1bcD93", "0x277e14A5111247c9a77c0493888b73c44fd00e93", "0x194509D7cad53212bd9A332D5FBFE136341f0eBb", "0x247DE5EBA63E6599B243bde47680ace07A2D61E2", "0x1eB5e9e5ff561Deea952C6f8544454F71a554e2C", "0x243848caEF2012ae55fdb7062508AF84977144Ca", "0x134342210990c23e58caC9224Af88882F455A75c", "0x16E9831450d675f95221f8528e0767b08B18d728", "0x251402227bCe7264aA6c3813EcD6f1e89946e232", "0x06e11c380Ef72F920A8e8853aB88914B31263a65", "0x0Fb8cD2AeBE3dAF33428a5bC4E950C3A8e400E00", "0x08e4b3fed3E8Cc6A51e34Cf22269Ee15874d9051", "0x077A1da04BdDD9e05d3ddaf516a7b021A96eF14d", "0x26184d4cF83fE42d0F6E43dfeb649259200C8018", "0x0214Aa92ff9598173b746f901Bb135D22450be91", "0x1D20ECdcAAD1875a796a136B59ba1eC59f37b6F3", "0x276bEadD2E70277A354fD69885bc940Eae648E35", "0x168633e2333cbC1D74fB6C70AfF7A5DB1515Ddf8", "0x1EC71522243214f1f50E26A9fb99545079A837B0", "0x02A28573D76ed340799eFa3DD5e9A9CC329e6B87", "0x12D63D55F304e9d3A500E2D2Cd5E4951ba5FA770", "0x22314348624cbe6ceC28B8F26f41CC56e04f153a", "0x063a56d112e09D50f01f19DA1128A84eC6f06D24", "0x13B50C69b351f4d51890B98AccB745558b63F5DC", "0x0A23427FEB1075439F17cc2A17777339aE16b440", "0x00d97D7f128D251Cfd3Bd638FE300Abf3037C736", "0x0C7a2eB5B17325dE8A68caFbe123e8E89FF07A1e", "0x0f36594825424B9bf71a6666836dfe717F2b3ce7", "0x0236685a7500A752cAAC80FDFa6a33732aa88414", "0x20Bd862FE9E8a25D0Ad5714d0a37cF4E2DB6A2BF", "0x1ceddD7225737c3AB169946Eb2368DB1c38A4ae0", "0x05D482FAD972CF1b1aFf560B38b712D94f00C40D"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "contributors", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numberOfContributors", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "contributorAddress", type: "address"}, {name: "contributionId", type: "string"}], name: "getContributorInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "bool"}, {name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "starbaseToken", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "contributor", outputs: [{name: "rewardedTokens", type: "uint256"}, {name: "isContributor", type: "bool"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["NewContributor(address,uint256)", "WithdrawContributorsToken(address,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x80f8a8834707e8354b741b30bf6902630c62f9a409323711bf0f361f48f032da", "0xd849f8aadc62851c8ee5bc2c5760f8382a20816410f901c74d4c58e30eaa986c", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4307260 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4686253 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "StarbaseMarketingCampaign", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "contributors", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contributors(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numberOfContributors", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numberOfContributors()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "contributionId", value: random.string( maxRandom )}], name: "getContributorInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "bool"}, {name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getContributorInfo(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "starbaseToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "starbaseToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "contributor", outputs: [{name: "rewardedTokens", type: "uint256"}, {name: "isContributor", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contributor(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "StarbaseMarketingCampaign", function( accounts ) {

	it( "TEST: StarbaseMarketingCampaign(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4307260", timeStamp: "1506249343", hash: "0x6d2c7fa0791b9d77bce531ee881709eaac28919a83579462c38eeb2453bd4de4", nonce: "34", blockHash: "0x60507cfe8ce9441c80b0f21dade095477059657eff616046ca8bb406c2e8fd6d", transactionIndex: "20", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: 0, value: "0", gas: "4712388", gasPrice: "12600000000", isError: "0", txreceipt_status: "", input: "0xd9f02210", contractAddress: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", cumulativeGasUsed: "1466490", gasUsed: "604436", confirmations: "3399955"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "StarbaseMarketingCampaign", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = StarbaseMarketingCampaign.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1506249343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = StarbaseMarketingCampaign.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[4], \"550000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4685734", timeStamp: "1512571882", hash: "0x85e067274804403ab825148f76b4735d250a8aa6da3a681d9fc07ee343c21021", nonce: "179", blockHash: "0x6edce54a9aabe5e7bc41707e02cf17738bc9a78ca14666795bba4e7b36e84f01", transactionIndex: "44", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "100000", gasPrice: "45000000000", isError: "1", txreceipt_status: "0", input: "0x572bcfe100000000000000000000000000aff4ae48e55fe4032a542745512e07ccef8f4b00000000000000000000000000000000000000000000001dd0c885f9a0d8000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353864333730636338323631326336363465623461363435", contractAddress: "", cumulativeGasUsed: "2273675", gasUsed: "100000", confirmations: "3021481"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[4]}, {type: "uint256", name: "tokenCount", value: "550000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|58d370cc82612c664eb4a645`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[5], \"825000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4685737", timeStamp: "1512571913", hash: "0x7bd24c7a77fce7ca0bf57881cc125e8b8dd614a2fa0eab832f6ab6f196ea8849", nonce: "180", blockHash: "0x1fac4ef0c1b2cc77d112ab7edccd26b6cc360decb20b043536f4bfaa73ca5a97", transactionIndex: "59", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "100000", gasPrice: "50400000000", isError: "1", txreceipt_status: "0", input: "0x572bcfe10000000000000000000000000035f5fa0aadaed083e5f4fb8fae40624772091c00000000000000000000000000000000000000000000002cb92cc8f67144000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353930653232623735303866636135323763633331356537", contractAddress: "", cumulativeGasUsed: "2200160", gasUsed: "100000", confirmations: "3021478"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[5]}, {type: "uint256", name: "tokenCount", value: "825000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|590e22b7508fca527cc315e7`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[6], \"755000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4685737", timeStamp: "1512571913", hash: "0x3899301cb3ef33ef94a7d7bb359bbec724d406dd12fa3007225b64eb73fd57bb", nonce: "181", blockHash: "0x1fac4ef0c1b2cc77d112ab7edccd26b6cc360decb20b043536f4bfaa73ca5a97", transactionIndex: "108", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "100000", gasPrice: "45000000000", isError: "1", txreceipt_status: "0", input: "0x572bcfe100000000000000000000000000ac9a1b323a83b192c081dd39c4540d35145972000000000000000000000000000000000000000000000028edbad3d6abec000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353931346464623934626235383731353238343131366235", contractAddress: "", cumulativeGasUsed: "4767714", gasUsed: "100000", confirmations: "3021478"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[6]}, {type: "uint256", name: "tokenCount", value: "755000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|5914ddb94bb58715284116b5`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[4], \"550000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4685749", timeStamp: "1512572205", hash: "0x0a385d1ff6d4e9b0a729b43b66e395e3fc1bbd3b70f8f12a5bf3993bc2bb8527", nonce: "182", blockHash: "0x0d11e93e07ae113b863e555cfde9f81575c3c61cd0cce758f4986405bb90e452", transactionIndex: "89", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "0", input: "0x572bcfe100000000000000000000000000aff4ae48e55fe4032a542745512e07ccef8f4b00000000000000000000000000000000000000000000001dd0c885f9a0d8000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353864333730636338323631326336363465623461363435", contractAddress: "", cumulativeGasUsed: "4838213", gasUsed: "132139", confirmations: "3021466"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[4]}, {type: "uint256", name: "tokenCount", value: "550000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|58d370cc82612c664eb4a645`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[4], "550000000000000000000", `1_auth0|58d370cc82612c664eb4a645`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1512572205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[5], \"825000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4685760", timeStamp: "1512572380", hash: "0xf2c9d637abbcd1b3b9d96122bfc7548fe528a7919193132b9c79c0e4d3ac0472", nonce: "183", blockHash: "0x5ae92a0bf1545b3688149280ae97dbfac9cf74eac932638f264ee2355a97f07f", transactionIndex: "108", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "0", input: "0x572bcfe10000000000000000000000000035f5fa0aadaed083e5f4fb8fae40624772091c00000000000000000000000000000000000000000000002cb92cc8f67144000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353930653232623735303866636135323763633331356537", contractAddress: "", cumulativeGasUsed: "4286955", gasUsed: "132139", confirmations: "3021455"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[5]}, {type: "uint256", name: "tokenCount", value: "825000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|590e22b7508fca527cc315e7`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[5], "825000000000000000000", `1_auth0|590e22b7508fca527cc315e7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1512572380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[6], \"755000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4685760", timeStamp: "1512572380", hash: "0x2f7769d1421690ec6915c985f578a4a607842dd7bedde54751d262b76c6ce08c", nonce: "184", blockHash: "0x5ae92a0bf1545b3688149280ae97dbfac9cf74eac932638f264ee2355a97f07f", transactionIndex: "109", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "0", input: "0x572bcfe100000000000000000000000000ac9a1b323a83b192c081dd39c4540d35145972000000000000000000000000000000000000000000000028edbad3d6abec000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353931346464623934626235383731353238343131366235", contractAddress: "", cumulativeGasUsed: "4419094", gasUsed: "132139", confirmations: "3021455"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[6]}, {type: "uint256", name: "tokenCount", value: "755000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|5914ddb94bb58715284116b5`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[6], "755000000000000000000", `1_auth0|5914ddb94bb58715284116b5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1512572380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setup( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4686087", timeStamp: "1512577422", hash: "0xe7da05e4aade48168d4bcb732f1b67923c1e552caba49ea1f957a3ac484a4383", nonce: "185", blockHash: "0x20ae7a86c87c0d5d1bbfc25c5190e672155dac1cb80af0e3b3f3c2a6bf611514", transactionIndex: "10", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "6000000", gasPrice: "52000000000", isError: "0", txreceipt_status: "1", input: "0x66d38203000000000000000000000000f70a642bd387f94380ffb90451c2c81d4eb82cbc", contractAddress: "", cumulativeGasUsed: "569065", gasUsed: "43915", confirmations: "3021128"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "starbaseTokenAddress", value: addressList[7]}], name: "setup", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setup(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1512577422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[4], \"550000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686119", timeStamp: "1512577921", hash: "0x3601a7e7136c9827f5bca61b62d08b240bb486dce9950467687e12672bae85e5", nonce: "186", blockHash: "0xb76156cad7a5aec26be415a64b7596c1f43d0ee6e418bdc86db0c313edd30bad", transactionIndex: "34", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000000aff4ae48e55fe4032a542745512e07ccef8f4b00000000000000000000000000000000000000000000001dd0c885f9a0d8000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353864333730636338323631326336363465623461363435", contractAddress: "", cumulativeGasUsed: "1573320", gasUsed: "164013", confirmations: "3021096"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[4]}, {type: "uint256", name: "tokenCount", value: "550000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|58d370cc82612c664eb4a645`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[4], "550000000000000000000", `1_auth0|58d370cc82612c664eb4a645`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1512577921 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x00aff4ae48e55fe4032a542745512e07ccef8f4b"}, {name: "tokenCount", type: "uint256", value: "550000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x00aff4ae48e55fe4032a542745512e07ccef8f4b"}, {name: "tokenWithdrawn", type: "uint256", value: "550000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[5], \"825000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686133", timeStamp: "1512578140", hash: "0xe6a5b28647c7ef4a00ddedcb1d1585667eaa0c3a9fee178f177bf34cd895f3b3", nonce: "187", blockHash: "0x9fb9771cb17dc7b4e5663e07a8a09656afdbd04ba9eca8fcb34797dd0452714f", transactionIndex: "29", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000035f5fa0aadaed083e5f4fb8fae40624772091c00000000000000000000000000000000000000000000002cb92cc8f67144000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353930653232623735303866636135323763633331356537", contractAddress: "", cumulativeGasUsed: "2123754", gasUsed: "149013", confirmations: "3021082"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[5]}, {type: "uint256", name: "tokenCount", value: "825000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|590e22b7508fca527cc315e7`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[5], "825000000000000000000", `1_auth0|590e22b7508fca527cc315e7`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1512578140 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0035f5fa0aadaed083e5f4fb8fae40624772091c"}, {name: "tokenCount", type: "uint256", value: "825000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0035f5fa0aadaed083e5f4fb8fae40624772091c"}, {name: "tokenWithdrawn", type: "uint256", value: "825000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[6], \"755000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686142", timeStamp: "1512578284", hash: "0xa4e67c0fb4a3b9bc269ae40b42130281629b6d6d2817d7f737af096736091535", nonce: "188", blockHash: "0x57050b237ecc5f2b14c651d901dab83acaddd85ccc6c65f2cd6d05f2e3eed003", transactionIndex: "79", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000000ac9a1b323a83b192c081dd39c4540d35145972000000000000000000000000000000000000000000000028edbad3d6abec000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020315f61757468307c353931346464623934626235383731353238343131366235", contractAddress: "", cumulativeGasUsed: "4805066", gasUsed: "149013", confirmations: "3021073"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[6]}, {type: "uint256", name: "tokenCount", value: "755000000000000000000"}, {type: "string", name: "contributionId", value: `1_auth0|5914ddb94bb58715284116b5`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[6], "755000000000000000000", `1_auth0|5914ddb94bb58715284116b5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1512578284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x00ac9a1b323a83b192c081dd39c4540d35145972"}, {name: "tokenCount", type: "uint256", value: "755000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x00ac9a1b323a83b192c081dd39c4540d35145972"}, {name: "tokenWithdrawn", type: "uint256", value: "755000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[8], \"150000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686179", timeStamp: "1512578909", hash: "0x7a6caf41dfaa1995bf55063bbf63cb34a2e5e765d9caa3af850ccaec95979502", nonce: "189", blockHash: "0x17475adde7d1e3ef7cf3bfb973dc271a59e4c05fd044c957655e192e9cfe6d08", transactionIndex: "38", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000007283ba3173d6869d3395bb23272a7fa5d0b151e00000000000000000000000000000000000000000000000821ab0d441498000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353863363661663361366335633734383537626539343131", contractAddress: "", cumulativeGasUsed: "2863466", gasUsed: "149077", confirmations: "3021036"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[8]}, {type: "uint256", name: "tokenCount", value: "150000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58c66af3a6c5c74857be9411`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[8], "150000000000000000000", `2_auth0|58c66af3a6c5c74857be9411`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1512578909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x07283ba3173d6869d3395bb23272a7fa5d0b151e"}, {name: "tokenCount", type: "uint256", value: "150000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x07283ba3173d6869d3395bb23272a7fa5d0b151e"}, {name: "tokenWithdrawn", type: "uint256", value: "150000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[9], \"1260000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x1183127ca555f5cc927d2077f434e8df0de7db5332ba0ab85507381554c7afa5", nonce: "190", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "31", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000085dda9064279c575b51b1a15282768387d1bddd0000000000000000000000000000000000000000000000444e033c3be030000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353863656437663739323966353836363564376530623865", contractAddress: "", cumulativeGasUsed: "1956721", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[9]}, {type: "uint256", name: "tokenCount", value: "1260000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58ced7f7929f58665d7e0b8e`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[9], "1260000000000000000000", `2_auth0|58ced7f7929f58665d7e0b8e`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x085dda9064279c575b51b1a15282768387d1bddd"}, {name: "tokenCount", type: "uint256", value: "1260000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x085dda9064279c575b51b1a15282768387d1bddd"}, {name: "tokenWithdrawn", type: "uint256", value: "1260000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[10], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0xaf797ac9b79a96afce6f141bb2f58df6cd9716964dc38acaf3691986a787f79b", nonce: "191", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "32", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000001aea9a05535d63b7bf132cbdf9b5b3d8ba4b4f57000000000000000000000000000000000000000000000043c33c19375648000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353863656465646135383665626234323630353636616164", contractAddress: "", cumulativeGasUsed: "2105798", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[10]}, {type: "uint256", name: "tokenCount", value: "1250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58cededa586ebb4260566aad`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[10], "1250000000000000000000", `2_auth0|58cededa586ebb4260566aad`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x1aea9a05535d63b7bf132cbdf9b5b3d8ba4b4f57"}, {name: "tokenCount", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x1aea9a05535d63b7bf132cbdf9b5b3d8ba4b4f57"}, {name: "tokenWithdrawn", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[11], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x2d87e5c09f7ee1e65422a655eafca19d762a38668c2711006d75a23fab969778", nonce: "192", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "33", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000002f1b4d2e91013e36a173600c1cda6ec70a70ef2000000000000000000000000000000000000000000000043c33c19375648000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353863663664633639323966353836363564376530653138", contractAddress: "", cumulativeGasUsed: "2254811", gasUsed: "149013", confirmations: "3021034"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[11]}, {type: "uint256", name: "tokenCount", value: "1250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58cf6dc6929f58665d7e0e18`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[11], "1250000000000000000000", `2_auth0|58cf6dc6929f58665d7e0e18`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x02f1b4d2e91013e36a173600c1cda6ec70a70ef2"}, {name: "tokenCount", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x02f1b4d2e91013e36a173600c1cda6ec70a70ef2"}, {name: "tokenWithdrawn", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[12], \"170500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0xac05645a386b13fdef29464f546a77281ed36712dbda6aa4feca681a515bb8b9", nonce: "193", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "34", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000d134bd2b25c2e8bb6871283af78ac3db7a53cdd00000000000000000000000000000000000000000000005c6da0d285d904000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353863666536396539323966353836363564376531373031", contractAddress: "", cumulativeGasUsed: "2403888", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[12]}, {type: "uint256", name: "tokenCount", value: "1705000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58cfe69e929f58665d7e1701`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[12], "1705000000000000000000", `2_auth0|58cfe69e929f58665d7e1701`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0d134bd2b25c2e8bb6871283af78ac3db7a53cdd"}, {name: "tokenCount", type: "uint256", value: "1705000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0d134bd2b25c2e8bb6871283af78ac3db7a53cdd"}, {name: "tokenWithdrawn", type: "uint256", value: "1705000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[13], \"750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0xbc6c11c479d625160b8d5f41e3005ee0d6d51124bf13aeeb8d17e2ded4aff5e8", nonce: "194", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "35", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000002725fc22cdd2b41c50f0a564fe18597e876c70f7000000000000000000000000000000000000000000000028a857425466f8000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864306337666535383665626234323630353637663536", contractAddress: "", cumulativeGasUsed: "2552965", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[13]}, {type: "uint256", name: "tokenCount", value: "750000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d0c7fe586ebb4260567f56`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[13], "750000000000000000000", `2_auth0|58d0c7fe586ebb4260567f56`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x2725fc22cdd2b41c50f0a564fe18597e876c70f7"}, {name: "tokenCount", type: "uint256", value: "750000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x2725fc22cdd2b41c50f0a564fe18597e876c70f7"}, {name: "tokenWithdrawn", type: "uint256", value: "750000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[14], \"110000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0xf1ea9d3895cda1b420cc2e1311d4f983fa82eed528f97c551883c830545aeca9", nonce: "195", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "36", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000b92db394ec8368ae1f1622ea48efb23be1bcd9300000000000000000000000000000000000000000000003ba1910bf341b0000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864306438343739323966353836363564376532306435", contractAddress: "", cumulativeGasUsed: "2702042", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[14]}, {type: "uint256", name: "tokenCount", value: "1100000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d0d847929f58665d7e20d5`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[14], "1100000000000000000000", `2_auth0|58d0d847929f58665d7e20d5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0b92db394ec8368ae1f1622ea48efb23be1bcd93"}, {name: "tokenCount", type: "uint256", value: "1100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0b92db394ec8368ae1f1622ea48efb23be1bcd93"}, {name: "tokenWithdrawn", type: "uint256", value: "1100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[15], \"80000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x8a99502b23e8dda78befce859b118825f1ff5b87b0029c93190280667017b89c", nonce: "196", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "37", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000277e14a5111247c9a77c0493888b73c44fd00e93000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864316131663839323966353836363564376533343066", contractAddress: "", cumulativeGasUsed: "2851119", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[15]}, {type: "uint256", name: "tokenCount", value: "80000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d1a1f8929f58665d7e340f`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[15], "80000000000000000000", `2_auth0|58d1a1f8929f58665d7e340f`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x277e14a5111247c9a77c0493888b73c44fd00e93"}, {name: "tokenCount", type: "uint256", value: "80000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x277e14a5111247c9a77c0493888b73c44fd00e93"}, {name: "tokenWithdrawn", type: "uint256", value: "80000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[16], \"725000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x7c70a29d01ef6a95b520e47ecca3be385e61626c05f20130bd35e5dd07af5656", nonce: "197", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "38", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000194509d7cad53212bd9a332d5fbfe136341f0ebb00000000000000000000000000000000000000000000018905f62bda8e08000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864323633663739323966353836363564376533633530", contractAddress: "", cumulativeGasUsed: "3000260", gasUsed: "149141", confirmations: "3021034"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[16]}, {type: "uint256", name: "tokenCount", value: "7250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d263f7929f58665d7e3c50`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[16], "7250000000000000000000", `2_auth0|58d263f7929f58665d7e3c50`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x194509d7cad53212bd9a332d5fbfe136341f0ebb"}, {name: "tokenCount", type: "uint256", value: "7250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x194509d7cad53212bd9a332d5fbfe136341f0ebb"}, {name: "tokenWithdrawn", type: "uint256", value: "7250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[17], \"124000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0xdd1e932d535746dba258c1da6be1bdc546c00d18e2018dd03b6efe6d48b0a5c2", nonce: "198", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "39", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000247de5eba63e6599b243bde47680ace07a2d61e20000000000000000000000000000000000000000000000433874f632cc60000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864326263373465613362633332633861666361636233", contractAddress: "", cumulativeGasUsed: "3149337", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[17]}, {type: "uint256", name: "tokenCount", value: "1240000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d2bc74ea3bc32c8afcacb3`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[17], "1240000000000000000000", `2_auth0|58d2bc74ea3bc32c8afcacb3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x247de5eba63e6599b243bde47680ace07a2d61e2"}, {name: "tokenCount", type: "uint256", value: "1240000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x247de5eba63e6599b243bde47680ace07a2d61e2"}, {name: "tokenWithdrawn", type: "uint256", value: "1240000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[4], \"840000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x3c22dd9d3f2563783e3f371c37c9de03ea241da7e57431463bb29bc80370c4d9", nonce: "199", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "40", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000000aff4ae48e55fe4032a542745512e07ccef8f4b00000000000000000000000000000000000000000000002d89577d7d4020000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864333730636338323631326336363465623461363435", contractAddress: "", cumulativeGasUsed: "3220491", gasUsed: "71154", confirmations: "3021034"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[4]}, {type: "uint256", name: "tokenCount", value: "840000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d370cc82612c664eb4a645`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[4], "840000000000000000000", `2_auth0|58d370cc82612c664eb4a645`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x00aff4ae48e55fe4032a542745512e07ccef8f4b"}, {name: "tokenWithdrawn", type: "uint256", value: "840000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[18], \"605000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x1942069c2ffe0bba27df05a98c632ec92aabd9d965fcf9ee6e5d3c331fd22257", nonce: "200", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "41", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000001eb5e9e5ff561deea952c6f8544454f71a554e2c000000000000000000000000000000000000000000000020cc0fc6929754000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864336430663365613362633332633861666362643438", contractAddress: "", cumulativeGasUsed: "3369568", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[18]}, {type: "uint256", name: "tokenCount", value: "605000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d3d0f3ea3bc32c8afcbd48`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[18], "605000000000000000000", `2_auth0|58d3d0f3ea3bc32c8afcbd48`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x1eb5e9e5ff561deea952c6f8544454f71a554e2c"}, {name: "tokenCount", type: "uint256", value: "605000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x1eb5e9e5ff561deea952c6f8544454f71a554e2c"}, {name: "tokenWithdrawn", type: "uint256", value: "605000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[19], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0xd5d6bbe22a59001af534fe35a86faf3ebdf9ad4f5b2cf4d1bf931f790cc48cfd", nonce: "201", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "42", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000243848caef2012ae55fdb7062508af84977144ca000000000000000000000000000000000000000000000043c33c19375648000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864346336396539303066623732616232336139383462", contractAddress: "", cumulativeGasUsed: "3518645", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[19]}, {type: "uint256", name: "tokenCount", value: "1250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d4c69e900fb72ab23a984b`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[19], "1250000000000000000000", `2_auth0|58d4c69e900fb72ab23a984b`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x243848caef2012ae55fdb7062508af84977144ca"}, {name: "tokenCount", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x243848caef2012ae55fdb7062508af84977144ca"}, {name: "tokenWithdrawn", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[20], \"131000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x4763dce9bcbdb26746cfac7bb6fa52286eb34205d2f847f842e94c1f77811695", nonce: "202", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "43", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000134342210990c23e58cac9224af88882f455a75c00000000000000000000000000000000000000000000004703e6eb5291b8000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864353238353465613362633332633861666363663438", contractAddress: "", cumulativeGasUsed: "3667722", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[20]}, {type: "uint256", name: "tokenCount", value: "1310000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d52854ea3bc32c8afccf48`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[20], "1310000000000000000000", `2_auth0|58d52854ea3bc32c8afccf48`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x134342210990c23e58cac9224af88882f455a75c"}, {name: "tokenCount", type: "uint256", value: "1310000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x134342210990c23e58cac9224af88882f455a75c"}, {name: "tokenWithdrawn", type: "uint256", value: "1310000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[21], \"410000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x944ee2920029cd26b804ea4838ed44c261081d8e5286bf9653d3a3f3fe45bba8", nonce: "203", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "44", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000016e9831450d675f95221f8528e0767b08b18d72800000000000000000000000000000000000000000000001639e49bba1628000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864366138326662326538373030323639353165656663", contractAddress: "", cumulativeGasUsed: "3816799", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[21]}, {type: "uint256", name: "tokenCount", value: "410000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d6a82fb2e870026951eefc`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[21], "410000000000000000000", `2_auth0|58d6a82fb2e870026951eefc`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x16e9831450d675f95221f8528e0767b08b18d728"}, {name: "tokenCount", type: "uint256", value: "410000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x16e9831450d675f95221f8528e0767b08b18d728"}, {name: "tokenWithdrawn", type: "uint256", value: "410000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[22], \"152000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686181", timeStamp: "1512578931", hash: "0x7cc24d8613ffe05933fc130e7e0ee4d8453e708938b2987759cd21932cd7929e", nonce: "204", blockHash: "0x76757a802f5dc458116db434a5cf581c08004b1e840bbecc8724a8b5edc48118", transactionIndex: "45", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000251402227bce7264aa6c3813ecd6f1e89946e232000000000000000000000000000000000000000000000052663ccab1e1c0000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864383937353937653839613430323730666561663638", contractAddress: "", cumulativeGasUsed: "3965876", gasUsed: "149077", confirmations: "3021034"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[22]}, {type: "uint256", name: "tokenCount", value: "1520000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d897597e89a40270feaf68`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[22], "1520000000000000000000", `2_auth0|58d897597e89a40270feaf68`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1512578931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x251402227bce7264aa6c3813ecd6f1e89946e232"}, {name: "tokenCount", type: "uint256", value: "1520000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x251402227bce7264aa6c3813ecd6f1e89946e232"}, {name: "tokenWithdrawn", type: "uint256", value: "1520000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[23], \"124000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686184", timeStamp: "1512578965", hash: "0xe7022f9e50ce973e1e0b4623d7d6b5d68d735b7b9e1a24041143d9a99b0f9517", nonce: "205", blockHash: "0x793af39ad1eb31bd57436e73d3b83806ff5e9a42dbaf5073470053fd0b7dd849", transactionIndex: "43", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000006e11c380ef72f920a8e8853ab88914b31263a650000000000000000000000000000000000000000000000433874f632cc60000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864386139356262326538373030323639353166393264", contractAddress: "", cumulativeGasUsed: "3249034", gasUsed: "149077", confirmations: "3021031"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[23]}, {type: "uint256", name: "tokenCount", value: "1240000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d8a95bb2e870026951f92d`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[23], "1240000000000000000000", `2_auth0|58d8a95bb2e870026951f92d`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1512578965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x06e11c380ef72f920a8e8853ab88914b31263a65"}, {name: "tokenCount", type: "uint256", value: "1240000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x06e11c380ef72f920a8e8853ab88914b31263a65"}, {name: "tokenWithdrawn", type: "uint256", value: "1240000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[24], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686188", timeStamp: "1512579002", hash: "0xd50a54414852cc320eb5b9bd1be78d7d6545341880b50e0bd6585226ccc90e04", nonce: "206", blockHash: "0x76a8a0b81da3c929331123255edf0930109da433610713e9b51276e93a67259e", transactionIndex: "83", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000fb8cd2aebe3daf33428a5bc4e950c3a8e400e00000000000000000000000000000000000000000000000043c33c19375648000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864386236613462326538373030323639353166396138", contractAddress: "", cumulativeGasUsed: "5845229", gasUsed: "149013", confirmations: "3021027"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[24]}, {type: "uint256", name: "tokenCount", value: "1250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d8b6a4b2e870026951f9a8`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[24], "1250000000000000000000", `2_auth0|58d8b6a4b2e870026951f9a8`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1512579002 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0fb8cd2aebe3daf33428a5bc4e950c3a8e400e00"}, {name: "tokenCount", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0fb8cd2aebe3daf33428a5bc4e950c3a8e400e00"}, {name: "tokenWithdrawn", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[25], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686196", timeStamp: "1512579157", hash: "0x457bc30676223f7f0c8c430ad1473fe719ca068d1d272c8fdacb38a88ea2b78a", nonce: "207", blockHash: "0xc64dbf29ac76e11ff3c31ea02505e8224c800cd0998f71cbe8b0c8718594a580", transactionIndex: "35", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000008e4b3fed3e8cc6a51e34cf22269ee15874d9051000000000000000000000000000000000000000000000043c33c19375648000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864393066626431616264663436383763366430363038", contractAddress: "", cumulativeGasUsed: "4277711", gasUsed: "149077", confirmations: "3021019"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[25]}, {type: "uint256", name: "tokenCount", value: "1250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d90fbd1abdf4687c6d0608`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[25], "1250000000000000000000", `2_auth0|58d90fbd1abdf4687c6d0608`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1512579157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x08e4b3fed3e8cc6a51e34cf22269ee15874d9051"}, {name: "tokenCount", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x08e4b3fed3e8cc6a51e34cf22269ee15874d9051"}, {name: "tokenWithdrawn", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[26], \"105000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686203", timeStamp: "1512579290", hash: "0x43a7aeb5eb4cc122607a8ebecb8a3e1cc9a493c080dbfdc7aebe8cc630077080", nonce: "208", blockHash: "0xbdf70281735315db0648ee883977d9131217831ecbe237df405e7a6e74fa1b76", transactionIndex: "32", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000077a1da04bddd9e05d3ddaf516a7b021a96ef14d000000000000000000000000000000000000000000000038ebad5cdc9028000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864393161316562326538373030323639353230333334", contractAddress: "", cumulativeGasUsed: "1486649", gasUsed: "149077", confirmations: "3021012"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[26]}, {type: "uint256", name: "tokenCount", value: "1050000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d91a1eb2e8700269520334`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[26], "1050000000000000000000", `2_auth0|58d91a1eb2e8700269520334`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1512579290 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x077a1da04bddd9e05d3ddaf516a7b021a96ef14d"}, {name: "tokenCount", type: "uint256", value: "1050000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x077a1da04bddd9e05d3ddaf516a7b021a96ef14d"}, {name: "tokenWithdrawn", type: "uint256", value: "1050000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[27], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686205", timeStamp: "1512579317", hash: "0xea928a9283473dca789e2d4107882cd358770cfe649a26b1f46d01a156f23bfc", nonce: "209", blockHash: "0xe1711bcac2faaf2ac246cd6f5abe68d4290506b3050f65e2447289be856a57df", transactionIndex: "97", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000026184d4cf83fe42d0f6e43dfeb649259200c8018000000000000000000000000000000000000000000000043c33c19375648000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864393434633537653839613430323730666563303461", contractAddress: "", cumulativeGasUsed: "4971195", gasUsed: "149077", confirmations: "3021010"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[27]}, {type: "uint256", name: "tokenCount", value: "1250000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58d944c57e89a40270fec04a`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[27], "1250000000000000000000", `2_auth0|58d944c57e89a40270fec04a`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1512579317 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x26184d4cf83fe42d0f6e43dfeb649259200c8018"}, {name: "tokenCount", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x26184d4cf83fe42d0f6e43dfeb649259200c8018"}, {name: "tokenWithdrawn", type: "uint256", value: "1250000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[28], \"124000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686213", timeStamp: "1512579434", hash: "0x8dafb8fb656036caeba774695762ca27826c447fd969ec8228689004cf53bea1", nonce: "210", blockHash: "0x36ce6755a78953b009b42161686f5d5cfcfc3dba1c920eb7eaabe27b5e03d4ad", transactionIndex: "21", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000214aa92ff9598173b746f901bb135d22450be910000000000000000000000000000000000000000000000433874f632cc60000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864613437616662326538373030323639353231326161", contractAddress: "", cumulativeGasUsed: "5533246", gasUsed: "149077", confirmations: "3021002"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[28]}, {type: "uint256", name: "tokenCount", value: "1240000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58da47afb2e87002695212aa`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[28], "1240000000000000000000", `2_auth0|58da47afb2e87002695212aa`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1512579434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0214aa92ff9598173b746f901bb135d22450be91"}, {name: "tokenCount", type: "uint256", value: "1240000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0214aa92ff9598173b746f901bb135d22450be91"}, {name: "tokenWithdrawn", type: "uint256", value: "1240000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[29], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686213", timeStamp: "1512579434", hash: "0xf99745c43811841c5428a4990111128cd63a530b15653748113772946dbdb6be", nonce: "211", blockHash: "0x36ce6755a78953b009b42161686f5d5cfcfc3dba1c920eb7eaabe27b5e03d4ad", transactionIndex: "22", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000001d20ecdcaad1875a796a136b59ba1ec59f37b6f300000000000000000000000000000000000000000000000ad78ebc5ac620000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353864613439663931616264663436383763366431373434", contractAddress: "", cumulativeGasUsed: "5682323", gasUsed: "149077", confirmations: "3021002"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[29]}, {type: "uint256", name: "tokenCount", value: "200000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58da49f91abdf4687c6d1744`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[29], "200000000000000000000", `2_auth0|58da49f91abdf4687c6d1744`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1512579434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x1d20ecdcaad1875a796a136b59ba1ec59f37b6f3"}, {name: "tokenCount", type: "uint256", value: "200000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x1d20ecdcaad1875a796a136b59ba1ec59f37b6f3"}, {name: "tokenWithdrawn", type: "uint256", value: "200000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[30], \"250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686213", timeStamp: "1512579434", hash: "0xb95caa6d30ddf6c3b4111642ab3d288f6b25d37377df49ac68b00f12498f250a", nonce: "212", blockHash: "0x36ce6755a78953b009b42161686f5d5cfcfc3dba1c920eb7eaabe27b5e03d4ad", transactionIndex: "23", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000276beadd2e70277a354fd69885bc940eae648e350000000000000000000000000000000000000000000000878678326eac90000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353866316638636133393664393033636265396538643833", contractAddress: "", cumulativeGasUsed: "5831400", gasUsed: "149077", confirmations: "3021002"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[30]}, {type: "uint256", name: "tokenCount", value: "2500000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58f1f8ca396d903cbe9e8d83`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[30], "2500000000000000000000", `2_auth0|58f1f8ca396d903cbe9e8d83`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1512579434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x276beadd2e70277a354fd69885bc940eae648e35"}, {name: "tokenCount", type: "uint256", value: "2500000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x276beadd2e70277a354fd69885bc940eae648e35"}, {name: "tokenWithdrawn", type: "uint256", value: "2500000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[31], \"102000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686215", timeStamp: "1512579466", hash: "0x5cc89e1eafc458ded19aa7606356f907455429a3416950f5991fb420ad4fab2b", nonce: "213", blockHash: "0xf8b94d1b4c5cf2c4831cdfc9814ada77a927d1464d833b1930aed0ccd223bcb6", transactionIndex: "80", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000168633e2333cbc1d74fb6c70aff7a5db1515ddf80000000000000000000000000000000000000000000000374b57f3cef270000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353866333562396464326364353332363261653066363232", contractAddress: "", cumulativeGasUsed: "3655280", gasUsed: "149077", confirmations: "3021000"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[31]}, {type: "uint256", name: "tokenCount", value: "1020000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58f35b9dd2cd53262ae0f622`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[31], "1020000000000000000000", `2_auth0|58f35b9dd2cd53262ae0f622`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1512579466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x168633e2333cbc1d74fb6c70aff7a5db1515ddf8"}, {name: "tokenCount", type: "uint256", value: "1020000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x168633e2333cbc1d74fb6c70aff7a5db1515ddf8"}, {name: "tokenWithdrawn", type: "uint256", value: "1020000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[32], \"100500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686218", timeStamp: "1512579511", hash: "0x5a61b22627392b015b529852b98ec845fcbed7d1befc33abef56ee85bf2d78f3", nonce: "214", blockHash: "0x30f4a2eb6cdabb1acf685e2c0ccd4d0bc35155eab77983cfb3e967232870f50e", transactionIndex: "61", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000001ec71522243214f1f50e26a9fb99545079a837b00000000000000000000000000000000000000000000000367b2d3f482394000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353866336365353564326364353332363261653066626563", contractAddress: "", cumulativeGasUsed: "3941014", gasUsed: "149077", confirmations: "3020997"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[32]}, {type: "uint256", name: "tokenCount", value: "1005000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58f3ce55d2cd53262ae0fbec`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[32], "1005000000000000000000", `2_auth0|58f3ce55d2cd53262ae0fbec`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1512579511 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x1ec71522243214f1f50e26a9fb99545079a837b0"}, {name: "tokenCount", type: "uint256", value: "1005000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x1ec71522243214f1f50e26a9fb99545079a837b0"}, {name: "tokenWithdrawn", type: "uint256", value: "1005000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[33], \"835000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686219", timeStamp: "1512579534", hash: "0x2adc23263a3f02044bb4084886d3109495c4a639b1b42eb08cffd237211c3c20", nonce: "215", blockHash: "0xd9bb11e18332dbe8370e1c4fd35e2a406a5f03e48f1f0b2a8904fff899e4f0bb", transactionIndex: "28", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000002a28573d76ed340799efa3dd5e9a9cc329e6b8700000000000000000000000000000000000000000000002d43f3ebfafb2c000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353866373933613937303434373031326339643661643337", contractAddress: "", cumulativeGasUsed: "4065829", gasUsed: "149077", confirmations: "3020996"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[33]}, {type: "uint256", name: "tokenCount", value: "835000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58f793a970447012c9d6ad37`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[33], "835000000000000000000", `2_auth0|58f793a970447012c9d6ad37`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1512579534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x02a28573d76ed340799efa3dd5e9a9cc329e6b87"}, {name: "tokenCount", type: "uint256", value: "835000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x02a28573d76ed340799efa3dd5e9a9cc329e6b87"}, {name: "tokenWithdrawn", type: "uint256", value: "835000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[34], \"580000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686226", timeStamp: "1512579716", hash: "0xf0af522fc6ee442b55064286abc3ec0a0468c281d5077c9f1743908eb5e91ded", nonce: "216", blockHash: "0x89f046b52d3756c954e865bbbe3b32c89d24b8682f282946d07b0ba9f6893b03", transactionIndex: "6", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000012d63d55f304e9d3a500e2d2cd5e4951ba5fa77000000000000000000000000000000000000000000000001f711def073e90000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353866636131323338353636376335663332336561616231", contractAddress: "", cumulativeGasUsed: "554939", gasUsed: "149013", confirmations: "3020989"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[34]}, {type: "uint256", name: "tokenCount", value: "580000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58fca12385667c5f323eaab1`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[34], "580000000000000000000", `2_auth0|58fca12385667c5f323eaab1`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1512579716 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x12d63d55f304e9d3a500e2d2cd5e4951ba5fa770"}, {name: "tokenCount", type: "uint256", value: "580000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x12d63d55f304e9d3a500e2d2cd5e4951ba5fa770"}, {name: "tokenWithdrawn", type: "uint256", value: "580000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[35], \"560000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686230", timeStamp: "1512579782", hash: "0xdc083984c202825f18493fe75e431027efa7694da635e701d19799ec68b09c0e", nonce: "217", blockHash: "0x194acafd7b366866991ad7be2198242df9fe2869e1393f983d6b53edc768050c", transactionIndex: "63", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000022314348624cbe6cec28b8f26f41cc56e04f153a00000000000000000000000000000000000000000000001e5b8fa8fe2ac0000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353866636633353739666238303937373738323731383635", contractAddress: "", cumulativeGasUsed: "4739542", gasUsed: "149077", confirmations: "3020985"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[35]}, {type: "uint256", name: "tokenCount", value: "560000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|58fcf3579fb8097778271865`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[35], "560000000000000000000", `2_auth0|58fcf3579fb8097778271865`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1512579782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x22314348624cbe6cec28b8f26f41cc56e04f153a"}, {name: "tokenCount", type: "uint256", value: "560000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x22314348624cbe6cec28b8f26f41cc56e04f153a"}, {name: "tokenWithdrawn", type: "uint256", value: "560000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[36], \"225000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686237", timeStamp: "1512579903", hash: "0xc3d3e3757e9c7965b65e80f581fd7472b732ac4416dfd4ba3894693b850f6379", nonce: "218", blockHash: "0xb4b293a3c0d7cb5f03437ff46c7e17386926801205ca95da315b791bb77a5358", transactionIndex: "33", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe1000000000000000000000000063a56d112e09d50f01f19da1128a84ec6f06d2400000000000000000000000000000000000000000000000c328093e61ee4000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930616634303936663530656634636132626362383331", contractAddress: "", cumulativeGasUsed: "1704493", gasUsed: "149077", confirmations: "3020978"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[36]}, {type: "uint256", name: "tokenCount", value: "225000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590af4096f50ef4ca2bcb831`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[36], "225000000000000000000", `2_auth0|590af4096f50ef4ca2bcb831`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1512579903 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x063a56d112e09d50f01f19da1128a84ec6f06d24"}, {name: "tokenCount", type: "uint256", value: "225000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x063a56d112e09d50f01f19da1128a84ec6f06d24"}, {name: "tokenWithdrawn", type: "uint256", value: "225000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[37], \"25000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x9c59c2d6fd2298ecc27d1c66eba317177d2388db65ee93beee8b1444a7c4f332", nonce: "219", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "74", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000013b50c69b351f4d51890b98accb745558b63f5dc0000000000000000000000000000000000000000000000015af1d78b58c4000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930646537383135303866636135323763633331333033", contractAddress: "", cumulativeGasUsed: "4709413", gasUsed: "149077", confirmations: "3020964"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[37]}, {type: "uint256", name: "tokenCount", value: "25000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590de781508fca527cc31303`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[37], "25000000000000000000", `2_auth0|590de781508fca527cc31303`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x13b50c69b351f4d51890b98accb745558b63f5dc"}, {name: "tokenCount", type: "uint256", value: "25000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x13b50c69b351f4d51890b98accb745558b63f5dc"}, {name: "tokenWithdrawn", type: "uint256", value: "25000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[38], \"390000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x9809acbf3e1134c6d3d56e4ce17205ed151e7c61a693ce3d778747c40d5594cd", nonce: "220", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "75", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000a23427feb1075439f17cc2a17777339ae16b440000000000000000000000000000000000000000000000015245655b10258000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930653436306335303866636135323763633331373235", contractAddress: "", cumulativeGasUsed: "4858490", gasUsed: "149077", confirmations: "3020964"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[38]}, {type: "uint256", name: "tokenCount", value: "390000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590e460c508fca527cc31725`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[38], "390000000000000000000", `2_auth0|590e460c508fca527cc31725`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0a23427feb1075439f17cc2a17777339ae16b440"}, {name: "tokenCount", type: "uint256", value: "390000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0a23427feb1075439f17cc2a17777339ae16b440"}, {name: "tokenWithdrawn", type: "uint256", value: "390000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[39], \"705000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x206fc39c68ee468223e613e73f4cbbbe58e3cb9299359414c5db622a18e62c19", nonce: "221", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "76", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000000d97d7f128d251cfd3bd638fe300abf3037c73600000000000000000000000000000000000000000000002637d724bffa64000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930653438303362633563636430363066333431306336", contractAddress: "", cumulativeGasUsed: "5007503", gasUsed: "149013", confirmations: "3020964"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[39]}, {type: "uint256", name: "tokenCount", value: "705000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590e4803bc5ccd060f3410c6`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[39], "705000000000000000000", `2_auth0|590e4803bc5ccd060f3410c6`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x00d97d7f128d251cfd3bd638fe300abf3037c736"}, {name: "tokenCount", type: "uint256", value: "705000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x00d97d7f128d251cfd3bd638fe300abf3037c736"}, {name: "tokenWithdrawn", type: "uint256", value: "705000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[40], \"310000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x2a46276f054b233dacee6d1e807c93da5bebfabfebe171749b1a724f3eb1035a", nonce: "222", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "77", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000c7a2eb5b17325de8a68cafbe123e8e89ff07a1e000000000000000000000000000000000000000000000010ce1d3d8cb318000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930656362303962633563636430363066333431336262", contractAddress: "", cumulativeGasUsed: "5156580", gasUsed: "149077", confirmations: "3020964"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[40]}, {type: "uint256", name: "tokenCount", value: "310000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590ecb09bc5ccd060f3413bb`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[40], "310000000000000000000", `2_auth0|590ecb09bc5ccd060f3413bb`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0c7a2eb5b17325de8a68cafbe123e8e89ff07a1e"}, {name: "tokenCount", type: "uint256", value: "310000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0c7a2eb5b17325de8a68cafbe123e8e89ff07a1e"}, {name: "tokenWithdrawn", type: "uint256", value: "310000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[41], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x9731bbbd8b5e8af1baa28d32890a1f5dbaa93cc695171691fb9c36fffe820f0d", nonce: "223", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "78", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000f36594825424b9bf71a6666836dfe717f2b3ce70000000000000000000000000000000000000000000000056bc75e2d6310000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930666437383935303866636135323763633332623333", contractAddress: "", cumulativeGasUsed: "5305657", gasUsed: "149077", confirmations: "3020964"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[41]}, {type: "uint256", name: "tokenCount", value: "100000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590fd789508fca527cc32b33`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[41], "100000000000000000000", `2_auth0|590fd789508fca527cc32b33`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0f36594825424b9bf71a6666836dfe717f2b3ce7"}, {name: "tokenCount", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0f36594825424b9bf71a6666836dfe717f2b3ce7"}, {name: "tokenWithdrawn", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[42], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x1b0d99b30bed5081b0d5438834322f77483f1c7a37648373b892ed16a485792b", nonce: "224", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "79", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000000236685a7500a752caac80fdfa6a33732aa884140000000000000000000000000000000000000000000000056bc75e2d6310000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930666462323935303866636135323763633332623365", contractAddress: "", cumulativeGasUsed: "5454670", gasUsed: "149013", confirmations: "3020964"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[42]}, {type: "uint256", name: "tokenCount", value: "100000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590fdb29508fca527cc32b3e`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[42], "100000000000000000000", `2_auth0|590fdb29508fca527cc32b3e`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x0236685a7500a752caac80fdfa6a33732aa88414"}, {name: "tokenCount", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x0236685a7500a752caac80fdfa6a33732aa88414"}, {name: "tokenWithdrawn", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[43], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x85f53187f98fa15127c5845db9f4a361e86974143f156da4e35e664d63a48389", nonce: "225", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "80", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000020bd862fe9e8a25d0ad5714d0a37cf4e2db6a2bf0000000000000000000000000000000000000000000000056bc75e2d6310000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930666536373762633563636430363066333432353733", contractAddress: "", cumulativeGasUsed: "5603747", gasUsed: "149077", confirmations: "3020964"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[43]}, {type: "uint256", name: "tokenCount", value: "100000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590fe677bc5ccd060f342573`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[43], "100000000000000000000", `2_auth0|590fe677bc5ccd060f342573`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x20bd862fe9e8a25d0ad5714d0a37cf4e2db6a2bf"}, {name: "tokenCount", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x20bd862fe9e8a25d0ad5714d0a37cf4e2db6a2bf"}, {name: "tokenWithdrawn", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[44], \"310000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686251", timeStamp: "1512580097", hash: "0x5ae52e6a1c4153aa1404fcfc6d133e72e4fc483bc1a051968c6b4fa48660c5ab", nonce: "226", blockHash: "0x0531d6408462420de4bf0bb88b254b2852b03515dd73fca7b5a993cbba6636ff", transactionIndex: "81", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe10000000000000000000000001ceddd7225737c3ab169946eb2368db1c38a4ae0000000000000000000000000000000000000000000000010ce1d3d8cb318000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353930666633353766653731386235666130346265343036", contractAddress: "", cumulativeGasUsed: "5752824", gasUsed: "149077", confirmations: "3020964"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[44]}, {type: "uint256", name: "tokenCount", value: "310000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|590ff357fe718b5fa04be406`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[44], "310000000000000000000", `2_auth0|590ff357fe718b5fa04be406`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1512580097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x1ceddd7225737c3ab169946eb2368db1c38a4ae0"}, {name: "tokenCount", type: "uint256", value: "310000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x1ceddd7225737c3ab169946eb2368db1c38a4ae0"}, {name: "tokenWithdrawn", type: "uint256", value: "310000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: deliverRewardedTokens( addressList[45], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4686253", timeStamp: "1512580110", hash: "0xd2fc05aa6206b4825f3b5a44d448c36cce52d3d79ee123a16940caf0c9e3b7f2", nonce: "227", blockHash: "0x7241c5d0393d6eb95a7da08be5e61f9af01898292917ea88214bcc98d4356453", transactionIndex: "4", from: "0xc00cc57df9f1fe1ebc9eb660e7b98a6e7cbcff21", to: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29", value: "0", gas: "1000000", gasPrice: "42000000000", isError: "0", txreceipt_status: "1", input: "0x572bcfe100000000000000000000000005d482fad972cf1b1aff560b38b712d94f00c40d0000000000000000000000000000000000000000000000056bc75e2d6310000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020325f61757468307c353931303765623966653731386235666130346266353061", contractAddress: "", cumulativeGasUsed: "621729", gasUsed: "149013", confirmations: "3020962"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "contributorAddress", value: addressList[45]}, {type: "uint256", name: "tokenCount", value: "100000000000000000000"}, {type: "string", name: "contributionId", value: `2_auth0|59107eb9fe718b5fa04bf50a`}], name: "deliverRewardedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deliverRewardedTokens(address,uint256,string)" ]( addressList[45], "100000000000000000000", `2_auth0|59107eb9fe718b5fa04bf50a`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1512580110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenCount", type: "uint256"}], name: "NewContributor", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewContributor", events: [{name: "contributorAddress", type: "address", value: "0x05d482fad972cf1b1aff560b38b712d94f00c40d"}, {name: "tokenCount", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "contributorAddress", type: "address"}, {indexed: false, name: "tokenWithdrawn", type: "uint256"}], name: "WithdrawContributorsToken", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawContributorsToken", events: [{name: "contributorAddress", type: "address", value: "0x05d482fad972cf1b1aff560b38b712d94f00c40d"}, {name: "tokenWithdrawn", type: "uint256", value: "100000000000000000000"}], address: "0xed9d813c4a82a9d76eba8ea666a7a0ab95f7bb29"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
