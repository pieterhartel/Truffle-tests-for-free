const SMSCoin = artifacts.require( "./SMSCoin.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SMSCoin" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x39013F961c378f02C2b82A6E1d31E9812786FD9D", "0x2eAfaD7C7EdfdF9Fc85Ae5AF291C629740e2ECA1", "0x788B8858d3e2fd4b536e28fDAA402938B11CE15f", "0x781b13d9b69315480c07b4DE4Fa4c47EA0235942", "0xF18c93a432b6C7297606f4884e3606b844A4668c", "0x3BAe3034Cda51F3709699733153C39319Fb61a76", "0xf8Ce1bfde31995F256f055AF6271c7ab5b8b7461", "0x1B23373CE78437AbEA9fAa4a7aa0b24Af725B6d6", "0xF292277639C62dC34def16a519Cc9Dbfa921f966", "0xF2145E751Ac61D53F7f2AA4EF02BB083029D0E5e", "0x3cb718d047fB9FFEE39D7Bf893A505E5F107BFc3", "0xcc177D7B2549bfCBEf809C236E51e8fD15bA3C0E", "0xFE5ca2566AAb4C8Ac40C90Be8616f4a92f4F3e6A", "0x325d85e5ec890051d021cd9BA589939F89Cc8c78", "0xEb8803f1901d363D6e7829eEdD63031872A040f1", "0xe69206060A32af15bD7f307bb0ce7Dc7C94cD7F3", "0xaF22C763a4560bb4E5eFddFE0Fc276e5eDd39bEB", "0xEC88fadC77e60639e73d5C47c972621cCd88BA00", "0xe41090ACbe9418D3A49701bCC1cb5dA18e0C4283", "0x0c9cfEB8aa3Bb750F2dA92947D651374A8B8531D", "0xcf68614eF6896EfdF5f21ADfc0cB695CAf6350F6", "0x43d4c3F5a651E18F1C61065E6db81445603c9B9D", "0x0953a71bcF36765f31794D735475957c9D351978", "0x6d9DB2295c9E4c61d0364b79d2B160728f1bdb1D", "0x841022AD9e41358aA7E5b55bA8297bD3509f5207", "0x209F573f0EBd2d2161Af6f26f9Bc85A58B871B65", "0x12192d986Bc92308E15242f5c4440C8d83777D46", "0x749bc1aB4A022A3ffBDc0cFE581B1f51eae00f51", "0x64b13EaD6811576e2b6936812dC63F4E9D9e7C98", "0x158250e239b0d1BE8f42948f609b7D5be3e57f75", "0x05ec7A45aF087Fba0410794AeC4749022EEA9593", "0x8E67B91dB5A7CC1211a2D92c8320C5223789f62b", "0x11b1EeC366d1e79923c15514f1B8C014CD780c8D", "0x389f67b39ACe752493A1856C8179b21F78225b4A", "0x9621B86E38C8f297FeFf1518BA6C7161dd0A8B78", "0x05345799C0Ec6392560E60b15E4A8Edd32D6CB57", "0x4Ff73182EF00eEb0f0C927156e59fC07c1eABE3B", "0xCF452Ec0d1b191fa174ddaCfe2E91d584C365001", "0x6c3a0182943588379dDbC35B257B9e269CFFCE89", "0x7059edE7D5058ad343B92A38D3D21936F393436E", "0xd5C0d45012a99ed297efEA5da0eE9244FE44C067", "0x51Be6FB6371FcE0c3c9B329D290F63088765cE82"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "checkAddress", outputs: [{name: "exist", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "saleCounterThisPhase", outputs: [{name: "_saleCounter", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "_totalSupply", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sentBonus", outputs: [{name: "_sentBonus", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "soldToken", outputs: [{name: "_soldToken", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "sender", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "checkMinBalance", outputs: [{name: "enough", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "UNIT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "i", type: "uint256"}], name: "getAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "limitedSale", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getAddressSize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "firstMembershipPurchase", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "e", type: "uint256"}], name: "Log", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "msg", type: "string"}], name: "Message", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "e", type: "string"}], name: "TOKEN", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Log(uint256)", "Message(string)", "TOKEN(string)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x909c57d5c6ac08245cf2a6de3900e2b868513fa59099b92b27d8db823d92df9c", "0x51a7f65c6325882f237d4aeb43228179cfad48b868511d508e24b4437a819137", "0xdf9aae0a39396a61774f40f071b7fb21a6d7ef4d55f48afaac7c290ac7bc47a7", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4531661 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4531969 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "SMSCoin", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "checkAddress", outputs: [{name: "exist", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "saleCounterThisPhase", outputs: [{name: "_saleCounter", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "saleCounterThisPhase()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "_totalSupply", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sentBonus", outputs: [{name: "_sentBonus", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sentBonus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "soldToken", outputs: [{name: "_soldToken", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "soldToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "checkMinBalance", outputs: [{name: "enough", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkMinBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "UNIT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "UNIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "i", value: random.range( maxRandom )}], name: "getAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAddress(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "limitedSale", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "limitedSale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getAddressSize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAddressSize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "firstMembershipPurchase", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "firstMembershipPurchase()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SMSCoin", function( accounts ) {

	it( "TEST: SMSCoin(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4531661", blockHash: "0xf4ab86fc5d04283f07a18ce5ccba92b85e5129224a9c915c6ccb1d84be23047c", timeStamp: "1510393562", hash: "0x4d91d63a230a5678a3c645d051121a0e199a52d2d6a8a1887393bedbbddf09d7", nonce: "148", transactionIndex: "38", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: 0, value: "0", gas: "4288731", gasPrice: "4000000000", input: "0xb0bed1e9", contractAddress: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", cumulativeGasUsed: "5696842", txreceipt_status: "1", gasUsed: "4288731", confirmations: "3207554", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "SMSCoin", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SMSCoin.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510393562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SMSCoin.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: start1BonusPeriod1(  )", async function( ) {
		const txOriginal = {blockNumber: "4531675", blockHash: "0x1d9c34f7817027873e282620cea68a73c15b44bf25aefcaad139c8ef21e8abbb", timeStamp: "1510393699", hash: "0x598d98d5e222bc10726c582551179863ef1e3cd8e570d2632bbe1378f7705206", nonce: "149", transactionIndex: "7", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "321897", gasPrice: "11000000000", input: "0xc2cdaf24", contractAddress: "", cumulativeGasUsed: "468897", txreceipt_status: "1", gasUsed: "321897", confirmations: "3207540", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "start1BonusPeriod1", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "start1BonusPeriod1()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510393699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "value", type: "uint256", value: "150000000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: start3BonusPeriod3(  )", async function( ) {
		const txOriginal = {blockNumber: "4531677", blockHash: "0x6069fb7191983df079fdcfbf77602ec1292e50aa73ed59c9c3127fe94f2899fe", timeStamp: "1510393773", hash: "0x4652610c78e02f400d12b166a05ce72bd776ccc65093fabab978368d4309ec13", nonce: "150", transactionIndex: "66", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "74832", gasPrice: "11000000000", input: "0xd4a34564", contractAddress: "", cumulativeGasUsed: "2916208", txreceipt_status: "1", gasUsed: "74832", confirmations: "3207538", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "start3BonusPeriod3", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "start3BonusPeriod3()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510393773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[4], \"37000\", \"1850\" )", async function( ) {
		const txOriginal = {blockNumber: "4531744", blockHash: "0xd487abcef0bd79000b3ba8348250b4e537a6169f1a635e11e961b818e61c2881", timeStamp: "1510394618", hash: "0x0a0079e23402058f574755fe2ffc9fd2bfe8a7fbd8e5daa93222f3c033eabe32", nonce: "151", transactionIndex: "8", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "6300000000", input: "0x93720b2f000000000000000000000000788b8858d3e2fd4b536e28fdaa402938b11ce15f0000000000000000000000000000000000000000000000000000000000009088000000000000000000000000000000000000000000000000000000000000073a", contractAddress: "", cumulativeGasUsed: "422637", txreceipt_status: "1", gasUsed: "218087", confirmations: "3207471", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_amount", value: "37000"}, {type: "uint256", name: "_bonus", value: "1850"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[4], "37000", "1850", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510394618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x788b8858d3e2fd4b536e28fdaa402938b11ce15f"}, {name: "value", type: "uint256", value: "37000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x788b8858d3e2fd4b536e28fdaa402938b11ce15f"}, {name: "value", type: "uint256", value: "1850"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[5], \"625\", \"31\" )", async function( ) {
		const txOriginal = {blockNumber: "4531746", blockHash: "0x2426720802c44e54e1ea77de29dcf4c909ff99773b213fb4b48b5a0d77103649", timeStamp: "1510394634", hash: "0xdedd0d8dad821f3c0a1f144d98977abdfdf5be2af6f5ebc14b608bac04cb35e0", nonce: "152", transactionIndex: "13", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000781b13d9b69315480c07b4de4fa4c47ea02359420000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000000000001f", contractAddress: "", cumulativeGasUsed: "886508", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207469", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_amount", value: "625"}, {type: "uint256", name: "_bonus", value: "31"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[5], "625", "31", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510394634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x781b13d9b69315480c07b4de4fa4c47ea0235942"}, {name: "value", type: "uint256", value: "625"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x781b13d9b69315480c07b4de4fa4c47ea0235942"}, {name: "value", type: "uint256", value: "31"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[6], \"10000\", \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "4531746", blockHash: "0x2426720802c44e54e1ea77de29dcf4c909ff99773b213fb4b48b5a0d77103649", timeStamp: "1510394634", hash: "0xe05c9fdf0b10e45986c15db187ed6ba698e6514843abc21d445c7f5957bc45ad", nonce: "153", transactionIndex: "14", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "8000000000", input: "0x93720b2f000000000000000000000000f18c93a432b6c7297606f4884e3606b844a4668c000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "1044595", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207469", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_amount", value: "10000"}, {type: "uint256", name: "_bonus", value: "1000"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[6], "10000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510394634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xf18c93a432b6c7297606f4884e3606b844a4668c"}, {name: "value", type: "uint256", value: "10000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xf18c93a432b6c7297606f4884e3606b844a4668c"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[7], \"2000\", \"100\" )", async function( ) {
		const txOriginal = {blockNumber: "4531747", blockHash: "0x5b0a099ae86081f1fd5a8faa1421e91a2841b34c01d2dbb05db8c2b8835726b4", timeStamp: "1510394638", hash: "0x23422c1b52c3e34c0451204fc7db576dfbf98eb27f6f9a744c95f9c98bd17996", nonce: "154", transactionIndex: "6", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f0000000000000000000000003bae3034cda51f3709699733153c39319fb61a7600000000000000000000000000000000000000000000000000000000000007d00000000000000000000000000000000000000000000000000000000000000064", contractAddress: "", cumulativeGasUsed: "373785", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207468", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_amount", value: "2000"}, {type: "uint256", name: "_bonus", value: "100"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[7], "2000", "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510394638 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x3bae3034cda51f3709699733153c39319fb61a76"}, {name: "value", type: "uint256", value: "2000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x3bae3034cda51f3709699733153c39319fb61a76"}, {name: "value", type: "uint256", value: "100"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[8], \"10000\", \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "4531748", blockHash: "0x3e418c680a3201b684f3da583da06cc59632e1364e0c715256a449d8444fa36f", timeStamp: "1510394645", hash: "0x6e7f3af511c4f02cc513d45031c74b44fd2f399e989529647a39ca03c95569f4", nonce: "155", transactionIndex: "12", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "5568750000", input: "0x93720b2f000000000000000000000000f8ce1bfde31995f256f055af6271c7ab5b8b7461000000000000000000000000000000000000000000000000000000000000271000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "501597", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207467", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_amount", value: "10000"}, {type: "uint256", name: "_bonus", value: "1000"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[8], "10000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510394645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xf8ce1bfde31995f256f055af6271c7ab5b8b7461"}, {name: "value", type: "uint256", value: "10000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xf8ce1bfde31995f256f055af6271c7ab5b8b7461"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[9], \"1250\", \"62\" )", async function( ) {
		const txOriginal = {blockNumber: "4531751", blockHash: "0xb1eca96c20186b7d3b3ee04561385ffe88fbe12bd1daf348cb2b62b4103195dd", timeStamp: "1510394795", hash: "0x954b64fee67e5a4f51d18cab1e636a1d65c02fb15d7dd9be6427d4a98bb149c9", nonce: "156", transactionIndex: "88", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "5568750000", input: "0x93720b2f0000000000000000000000001b23373ce78437abea9faa4a7aa0b24af725b6d600000000000000000000000000000000000000000000000000000000000004e2000000000000000000000000000000000000000000000000000000000000003e", contractAddress: "", cumulativeGasUsed: "3729647", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207464", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1250"}, {type: "uint256", name: "_bonus", value: "62"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[9], "1250", "62", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510394795 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x1b23373ce78437abea9faa4a7aa0b24af725b6d6"}, {name: "value", type: "uint256", value: "1250"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x1b23373ce78437abea9faa4a7aa0b24af725b6d6"}, {name: "value", type: "uint256", value: "62"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[10], \"20000\", \"2000\" )", async function( ) {
		const txOriginal = {blockNumber: "4531752", blockHash: "0xe4c44201dafa7863be056981b31dc32d85642d064a3a001462b9d0bc6840436b", timeStamp: "1510394814", hash: "0x74766d24c021484c301c3b1c19215a045418827181d1e35ad36130f267190b29", nonce: "157", transactionIndex: "94", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "15000000000", input: "0x93720b2f000000000000000000000000f292277639c62dc34def16a519cc9dbfa921f9660000000000000000000000000000000000000000000000000000000000004e2000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "2886696", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207463", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_amount", value: "20000"}, {type: "uint256", name: "_bonus", value: "2000"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[10], "20000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510394814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xf292277639c62dc34def16a519cc9dbfa921f966"}, {name: "value", type: "uint256", value: "20000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xf292277639c62dc34def16a519cc9dbfa921f966"}, {name: "value", type: "uint256", value: "2000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[11], \"12000\", \"1200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531752", blockHash: "0xe4c44201dafa7863be056981b31dc32d85642d064a3a001462b9d0bc6840436b", timeStamp: "1510394814", hash: "0x1d02fcff2dbe58bb1c90c441f3b20882d7e224fa9806d51643c57d8f668a5a33", nonce: "158", transactionIndex: "182", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "5280000000", input: "0x93720b2f000000000000000000000000f2145e751ac61d53f7f2aa4ef02bb083029d0e5e0000000000000000000000000000000000000000000000000000000000002ee000000000000000000000000000000000000000000000000000000000000004b0", contractAddress: "", cumulativeGasUsed: "6360487", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207463", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "12000"}, {type: "uint256", name: "_bonus", value: "1200"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[11], "12000", "1200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510394814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xf2145e751ac61d53f7f2aa4ef02bb083029d0e5e"}, {name: "value", type: "uint256", value: "12000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xf2145e751ac61d53f7f2aa4ef02bb083029d0e5e"}, {name: "value", type: "uint256", value: "1200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[12], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531752", blockHash: "0xe4c44201dafa7863be056981b31dc32d85642d064a3a001462b9d0bc6840436b", timeStamp: "1510394814", hash: "0x467bed1d5499f1778a62c155db45547b1f6c6d58f4922bdd9dfba6d7e53906e8", nonce: "159", transactionIndex: "183", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f0000000000000000000000003cb718d047fb9ffee39d7bf893a505e5f107bfc300000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "6518510", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207463", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[12], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510394814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x3cb718d047fb9ffee39d7bf893a505e5f107bfc3"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x3cb718d047fb9ffee39d7bf893a505e5f107bfc3"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[13], \"25000\", \"2500\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0xc814ac5dc545ff38ef2ee0429a478c107518b74aa6e02287bb5edd78abf93d3e", nonce: "160", transactionIndex: "60", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "5280000000", input: "0x93720b2f000000000000000000000000cc177d7b2549bfcbef809c236e51e8fd15ba3c0e00000000000000000000000000000000000000000000000000000000000061a800000000000000000000000000000000000000000000000000000000000009c4", contractAddress: "", cumulativeGasUsed: "2172405", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_amount", value: "25000"}, {type: "uint256", name: "_bonus", value: "2500"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[13], "25000", "2500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xcc177d7b2549bfcbef809c236e51e8fd15ba3c0e"}, {name: "value", type: "uint256", value: "25000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xcc177d7b2549bfcbef809c236e51e8fd15ba3c0e"}, {name: "value", type: "uint256", value: "2500"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[14], \"18899\", \"1861\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x98e75184915d8ef37bc7509f2f9821c20e5c801e9bf12fd39f72e8520f5e01d0", nonce: "161", transactionIndex: "61", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000fe5ca2566aab4c8ac40c90be8616f4a92f4f3e6a00000000000000000000000000000000000000000000000000000000000049d30000000000000000000000000000000000000000000000000000000000000745", contractAddress: "", cumulativeGasUsed: "2330492", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_amount", value: "18899"}, {type: "uint256", name: "_bonus", value: "1861"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[14], "18899", "1861", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xfe5ca2566aab4c8ac40c90be8616f4a92f4f3e6a"}, {name: "value", type: "uint256", value: "18899"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xfe5ca2566aab4c8ac40c90be8616f4a92f4f3e6a"}, {name: "value", type: "uint256", value: "1861"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[15], \"1000\", \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x5e383251341640db8a8f79f1fdf9629fe6d57df5321fb8f4cd0f7ad28e7a8958", nonce: "162", transactionIndex: "62", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "217959", gasPrice: "4400000000", input: "0x93720b2f000000000000000000000000325d85e5ec890051d021cd9ba589939f89cc8c7800000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "2488451", txreceipt_status: "1", gasUsed: "157959", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "30"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[15], "1000", "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x325d85e5ec890051d021cd9ba589939f89cc8c78"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x325d85e5ec890051d021cd9ba589939f89cc8c78"}, {name: "value", type: "uint256", value: "30"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[16], \"250\", \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x1766d30a1f5fb456c62b67e1b26cb6f54939d9f7045fd7e74f4c0f2a3e6480f9", nonce: "163", transactionIndex: "63", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "217959", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000eb8803f1901d363d6e7829eedd63031872a040f100000000000000000000000000000000000000000000000000000000000000fa000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "2646410", txreceipt_status: "1", gasUsed: "157959", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_amount", value: "250"}, {type: "uint256", name: "_bonus", value: "12"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[16], "250", "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xeb8803f1901d363d6e7829eedd63031872a040f1"}, {name: "value", type: "uint256", value: "250"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xeb8803f1901d363d6e7829eedd63031872a040f1"}, {name: "value", type: "uint256", value: "12"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[17], \"19750\", \"849\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x255655305ce24b4f3480d9200939d878578d30b3652403b32fcd0bf145a77cf4", nonce: "164", transactionIndex: "64", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "4400000000", input: "0x93720b2f000000000000000000000000e69206060a32af15bd7f307bb0ce7dc7c94cd7f30000000000000000000000000000000000000000000000000000000000004d260000000000000000000000000000000000000000000000000000000000000351", contractAddress: "", cumulativeGasUsed: "2804497", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_amount", value: "19750"}, {type: "uint256", name: "_bonus", value: "849"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[17], "19750", "849", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xe69206060a32af15bd7f307bb0ce7dc7c94cd7f3"}, {name: "value", type: "uint256", value: "19750"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xe69206060a32af15bd7f307bb0ce7dc7c94cd7f3"}, {name: "value", type: "uint256", value: "849"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[18], \"1000\", \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x85d2c1b2bbce13893a07a3398344c6b7a0bdd14969b4d6f35a460b1522a71011", nonce: "165", transactionIndex: "65", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "4400000000", input: "0x93720b2f000000000000000000000000af22c763a4560bb4e5efddfe0fc276e5edd39beb00000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "2962520", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "30"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[18], "1000", "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xaf22c763a4560bb4e5efddfe0fc276e5edd39beb"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xaf22c763a4560bb4e5efddfe0fc276e5edd39beb"}, {name: "value", type: "uint256", value: "30"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[19], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x106bf792edd5425efaa31c95e966866bf0314b81a541c9daa42d4845bb63a5bb", nonce: "166", transactionIndex: "66", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "217959", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000ec88fadc77e60639e73d5c47c972621ccd88ba0000000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3120479", txreceipt_status: "1", gasUsed: "157959", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[19], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xec88fadc77e60639e73d5c47c972621ccd88ba00"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xec88fadc77e60639e73d5c47c972621ccd88ba00"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[20], \"4312\", \"128\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x73b7f84c2f209cbf9066cb648ebaf43ceb81157269681018c15f381e3b51a525", nonce: "167", transactionIndex: "67", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "4400000000", input: "0x93720b2f000000000000000000000000e41090acbe9418d3a49701bcc1cb5da18e0c428300000000000000000000000000000000000000000000000000000000000010d80000000000000000000000000000000000000000000000000000000000000080", contractAddress: "", cumulativeGasUsed: "3278502", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_amount", value: "4312"}, {type: "uint256", name: "_bonus", value: "128"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[20], "4312", "128", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xe41090acbe9418d3a49701bcc1cb5da18e0c4283"}, {name: "value", type: "uint256", value: "4312"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xe41090acbe9418d3a49701bcc1cb5da18e0c4283"}, {name: "value", type: "uint256", value: "128"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[21], \"21250\", \"2125\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x0c04bcc4bac06dbd4cc442577571d9eb089865f70adf8cb59f0074907fcba887", nonce: "168", transactionIndex: "68", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "10000000000", input: "0x93720b2f0000000000000000000000000c9cfeb8aa3bb750f2da92947d651374a8b8531d0000000000000000000000000000000000000000000000000000000000005302000000000000000000000000000000000000000000000000000000000000084d", contractAddress: "", cumulativeGasUsed: "3436589", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_amount", value: "21250"}, {type: "uint256", name: "_bonus", value: "2125"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[21], "21250", "2125", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x0c9cfeb8aa3bb750f2da92947d651374a8b8531d"}, {name: "value", type: "uint256", value: "21250"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x0c9cfeb8aa3bb750f2da92947d651374a8b8531d"}, {name: "value", type: "uint256", value: "2125"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[22], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0xf6e39b0bcfdd34b8a49760245c84af94fe9237a9dd93e6d6ebda3dec1c629c6b", nonce: "169", transactionIndex: "69", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000cf68614ef6896efdf5f21adfc0cb695caf6350f600000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3594612", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[22], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xcf68614ef6896efdf5f21adfc0cb695caf6350f6"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xcf68614ef6896efdf5f21adfc0cb695caf6350f6"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[23], \"40000\", \"2000\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x7cf98570437f4d23a60489f5d701f04f3a894b38b78b2c34654006fcb1f4869b", nonce: "170", transactionIndex: "70", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218087", gasPrice: "6000000000", input: "0x93720b2f00000000000000000000000043d4c3f5a651e18f1c61065e6db81445603c9b9d0000000000000000000000000000000000000000000000000000000000009c4000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "3752699", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_amount", value: "40000"}, {type: "uint256", name: "_bonus", value: "2000"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[23], "40000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x43d4c3f5a651e18f1c61065e6db81445603c9b9d"}, {name: "value", type: "uint256", value: "40000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x43d4c3f5a651e18f1c61065e6db81445603c9b9d"}, {name: "value", type: "uint256", value: "2000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[24], \"1000\", \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x8465939621d02089e48c7bb246c18a273fb3477da17c6e4dc6179b87f77345ad", nonce: "171", transactionIndex: "71", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "6000000000", input: "0x93720b2f0000000000000000000000000953a71bcf36765f31794d735475957c9d35197800000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "3910722", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "30"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[24], "1000", "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x0953a71bcf36765f31794d735475957c9d351978"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x0953a71bcf36765f31794d735475957c9d351978"}, {name: "value", type: "uint256", value: "30"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[25], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x22e868e0070e022e72d63ad29cd0b7586517c170abb0f96e16b90f6810da1908", nonce: "172", transactionIndex: "72", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f0000000000000000000000006d9db2295c9e4c61d0364b79d2b160728f1bdb1d00000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4068745", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[25], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x6d9db2295c9e4c61d0364b79d2b160728f1bdb1d"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x6d9db2295c9e4c61d0364b79d2b160728f1bdb1d"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[26], \"3000\", \"150\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0xd44ca35587afb9e1628dde52b657d0e6d106fe3b253407c220c09c9d47b30d10", nonce: "173", transactionIndex: "73", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000841022ad9e41358aa7e5b55ba8297bd3509f52070000000000000000000000000000000000000000000000000000000000000bb80000000000000000000000000000000000000000000000000000000000000096", contractAddress: "", cumulativeGasUsed: "4226768", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_amount", value: "3000"}, {type: "uint256", name: "_bonus", value: "150"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[26], "3000", "150", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x841022ad9e41358aa7e5b55ba8297bd3509f5207"}, {name: "value", type: "uint256", value: "3000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x841022ad9e41358aa7e5b55ba8297bd3509f5207"}, {name: "value", type: "uint256", value: "150"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[27], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x37dc312d2ac01562d2e0bd329f0efeb8a6293dfa7dc24342ae94c8ce20944062", nonce: "174", transactionIndex: "74", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000209f573f0ebd2d2161af6f26f9bc85a58b871b6500000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4384791", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[27], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x209f573f0ebd2d2161af6f26f9bc85a58b871b65"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x209f573f0ebd2d2161af6f26f9bc85a58b871b65"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[28], \"1250\", \"62\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x69c691ee49d16cc417c4b0851e3ed2e2b3fd149725a37da0ca903f627047665a", nonce: "175", transactionIndex: "75", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f00000000000000000000000012192d986bc92308e15242f5c4440c8d83777d4600000000000000000000000000000000000000000000000000000000000004e2000000000000000000000000000000000000000000000000000000000000003e", contractAddress: "", cumulativeGasUsed: "4542814", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_amount", value: "1250"}, {type: "uint256", name: "_bonus", value: "62"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[28], "1250", "62", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x12192d986bc92308e15242f5c4440c8d83777d46"}, {name: "value", type: "uint256", value: "1250"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x12192d986bc92308e15242f5c4440c8d83777d46"}, {name: "value", type: "uint256", value: "62"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[29], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x2204563e34660e709976b65ce72271936e345320e1432f7c0189b53ce2fad4f3", nonce: "176", transactionIndex: "76", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f000000000000000000000000749bc1ab4a022a3ffbdc0cfe581b1f51eae00f5100000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4700837", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[29], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x749bc1ab4a022a3ffbdc0cfe581b1f51eae00f51"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x749bc1ab4a022a3ffbdc0cfe581b1f51eae00f51"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[30], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x9e0262b6212aee6482cbd00d691d1b42ff2bd9198da84b16b032e15cc91a120a", nonce: "177", transactionIndex: "77", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "10000000000", input: "0x93720b2f00000000000000000000000064b13ead6811576e2b6936812dc63f4e9d9e7c9800000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4858860", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[30], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x64b13ead6811576e2b6936812dc63f4e9d9e7c98"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x64b13ead6811576e2b6936812dc63f4e9d9e7c98"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[31], \"1000\", \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x1fcccf46b8cd767b7452a56a83baab62a4219ce4cd58080c5d531a91c7d4ca27", nonce: "178", transactionIndex: "78", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "6300000000", input: "0x93720b2f000000000000000000000000158250e239b0d1be8f42948f609b7d5be3e57f7500000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "5016883", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "30"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[31], "1000", "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x158250e239b0d1be8f42948f609b7d5be3e57f75"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x158250e239b0d1be8f42948f609b7d5be3e57f75"}, {name: "value", type: "uint256", value: "30"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[32], \"168\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x2098e4788225648afa31a4a7a94faeee9ffda288d2952b2763ab6d9648563d03", nonce: "179", transactionIndex: "79", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "217959", gasPrice: "6300000000", input: "0x93720b2f00000000000000000000000005ec7a45af087fba0410794aec4749022eea959300000000000000000000000000000000000000000000000000000000000000a80000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "5174842", txreceipt_status: "1", gasUsed: "157959", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_amount", value: "168"}, {type: "uint256", name: "_bonus", value: "5"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[32], "168", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x05ec7a45af087fba0410794aec4749022eea9593"}, {name: "value", type: "uint256", value: "168"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x05ec7a45af087fba0410794aec4749022eea9593"}, {name: "value", type: "uint256", value: "5"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[33], \"1000\", \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0x348e9427f02c7a5387ad5b494c03a2556a03a05ab7d6a8d25f8ac717d4491a63", nonce: "180", transactionIndex: "80", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "6300000000", input: "0x93720b2f0000000000000000000000008e67b91db5a7cc1211a2d92c8320c5223789f62b00000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "5332865", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "30"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[33], "1000", "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x8e67b91db5a7cc1211a2d92c8320c5223789f62b"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x8e67b91db5a7cc1211a2d92c8320c5223789f62b"}, {name: "value", type: "uint256", value: "30"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[34], \"1000\", \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4531753", blockHash: "0x85b90118f9477ab0f58673cafc50da2803a5acec80ab859f18899ba180d920d9", timeStamp: "1510394826", hash: "0xb04fbb46586fb2f88a44cd16baef642b196259fde81ef54b340659d2a0c48e68", nonce: "181", transactionIndex: "81", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "218023", gasPrice: "15000000000", input: "0x93720b2f00000000000000000000000011b1eec366d1e79923c15514f1b8c014cd780c8d00000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5490888", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207462", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "10"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[34], "1000", "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510394826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x11b1eec366d1e79923c15514f1b8c014cd780c8d"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x11b1eec366d1e79923c15514f1b8c014cd780c8d"}, {name: "value", type: "uint256", value: "10"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[35], \"62500\", \"12500\" )", async function( ) {
		const txOriginal = {blockNumber: "4531891", blockHash: "0x9a0e32d8a71dbd09f024e4aa32bb42b198e8ad38400c0610a7fc6d2bc3753ac6", timeStamp: "1510396890", hash: "0xbc9c665781ae8b919251a670c5414861e83ebd3ba33ea90dabad8bd41c143a94", nonce: "182", transactionIndex: "88", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158087", gasPrice: "8000000000", input: "0x93720b2f000000000000000000000000389f67b39ace752493a1856c8179b21f78225b4a000000000000000000000000000000000000000000000000000000000000f42400000000000000000000000000000000000000000000000000000000000030d4", contractAddress: "", cumulativeGasUsed: "4101417", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207324", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_amount", value: "62500"}, {type: "uint256", name: "_bonus", value: "12500"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[35], "62500", "12500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510396890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x389f67b39ace752493a1856c8179b21f78225b4a"}, {name: "value", type: "uint256", value: "62500"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x389f67b39ace752493a1856c8179b21f78225b4a"}, {name: "value", type: "uint256", value: "12500"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[36], \"12125\", \"606\" )", async function( ) {
		const txOriginal = {blockNumber: "4531892", blockHash: "0x0c640e49ce957a46562e13e9b47a66f09750891fdf9aad98ee351771cbfd9e50", timeStamp: "1510396899", hash: "0x67dd73f9125c28dade239e4ac2ba18cd88bea9f489708e7ef6666b081ce5cf83", nonce: "183", transactionIndex: "26", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158087", gasPrice: "8000000000", input: "0x93720b2f0000000000000000000000009621b86e38c8f297feff1518ba6c7161dd0a8b780000000000000000000000000000000000000000000000000000000000002f5d000000000000000000000000000000000000000000000000000000000000025e", contractAddress: "", cumulativeGasUsed: "1026233", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207323", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_amount", value: "12125"}, {type: "uint256", name: "_bonus", value: "606"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[36], "12125", "606", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510396899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x9621b86e38c8f297feff1518ba6c7161dd0a8b78"}, {name: "value", type: "uint256", value: "12125"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x9621b86e38c8f297feff1518ba6c7161dd0a8b78"}, {name: "value", type: "uint256", value: "606"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[37], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531892", blockHash: "0x0c640e49ce957a46562e13e9b47a66f09750891fdf9aad98ee351771cbfd9e50", timeStamp: "1510396899", hash: "0x1b5092eb1cf93b9ac78fb3ec39d9a684a6956edc019736bca935854dbe41e94a", nonce: "184", transactionIndex: "65", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158023", gasPrice: "8000000000", input: "0x93720b2f00000000000000000000000005345799c0ec6392560e60b15e4a8edd32d6cb5700000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3666196", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207323", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[37], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510396899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x05345799c0ec6392560e60b15e4a8edd32d6cb57"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x05345799c0ec6392560e60b15e4a8edd32d6cb57"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[38], \"1005\", \"49\" )", async function( ) {
		const txOriginal = {blockNumber: "4531892", blockHash: "0x0c640e49ce957a46562e13e9b47a66f09750891fdf9aad98ee351771cbfd9e50", timeStamp: "1510396899", hash: "0x2364764a67b8239f797a46f3980dcd4a8ea33cebd3f7440afb7102f44518a290", nonce: "185", transactionIndex: "75", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "157959", gasPrice: "8000000000", input: "0x93720b2f0000000000000000000000004ff73182ef00eeb0f0c927156e59fc07c1eabe3b00000000000000000000000000000000000000000000000000000000000003ed0000000000000000000000000000000000000000000000000000000000000031", contractAddress: "", cumulativeGasUsed: "4423225", txreceipt_status: "1", gasUsed: "157959", confirmations: "3207323", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_amount", value: "1005"}, {type: "uint256", name: "_bonus", value: "49"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[38], "1005", "49", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510396899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x4ff73182ef00eeb0f0c927156e59fc07c1eabe3b"}, {name: "value", type: "uint256", value: "1005"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x4ff73182ef00eeb0f0c927156e59fc07c1eabe3b"}, {name: "value", type: "uint256", value: "49"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[39], \"11000\", \"550\" )", async function( ) {
		const txOriginal = {blockNumber: "4531892", blockHash: "0x0c640e49ce957a46562e13e9b47a66f09750891fdf9aad98ee351771cbfd9e50", timeStamp: "1510396899", hash: "0x290858a44d46c97c663323bbbac9caab8522f0b74182779a7e18d07682653b57", nonce: "186", transactionIndex: "81", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158087", gasPrice: "8000000000", input: "0x93720b2f000000000000000000000000cf452ec0d1b191fa174ddacfe2e91d584c3650010000000000000000000000000000000000000000000000000000000000002af80000000000000000000000000000000000000000000000000000000000000226", contractAddress: "", cumulativeGasUsed: "4993651", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207323", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_amount", value: "11000"}, {type: "uint256", name: "_bonus", value: "550"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[39], "11000", "550", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510396899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xcf452ec0d1b191fa174ddacfe2e91d584c365001"}, {name: "value", type: "uint256", value: "11000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xcf452ec0d1b191fa174ddacfe2e91d584c365001"}, {name: "value", type: "uint256", value: "550"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[40], \"1000\", \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4531892", blockHash: "0x0c640e49ce957a46562e13e9b47a66f09750891fdf9aad98ee351771cbfd9e50", timeStamp: "1510396899", hash: "0x9a6e2fbb72d26e24eada12c3b95f4fbcb36419f8a6ed1560170fc7b93bbdfded", nonce: "187", transactionIndex: "86", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158023", gasPrice: "8000000000", input: "0x93720b2f0000000000000000000000006c3a0182943588379ddbc35b257b9e269cffce8900000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5296971", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207323", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "10"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[40], "1000", "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510396899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x6c3a0182943588379ddbc35b257b9e269cffce89"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x6c3a0182943588379ddbc35b257b9e269cffce89"}, {name: "value", type: "uint256", value: "10"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[41], \"50000\", \"10000\" )", async function( ) {
		const txOriginal = {blockNumber: "4531922", blockHash: "0x87445f7c95c787d997776911b3472db393b21e8d82856b9481f25dddb46fa671", timeStamp: "1510397249", hash: "0x2e47a4ae16c6145219c4a7c0a481fd9cb540d7ab61a3f7dcf6a86638edb92c82", nonce: "188", transactionIndex: "94", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158087", gasPrice: "8000000000", input: "0x93720b2f0000000000000000000000007059ede7d5058ad343b92a38d3d21936f393436e000000000000000000000000000000000000000000000000000000000000c3500000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "3947541", txreceipt_status: "1", gasUsed: "158087", confirmations: "3207293", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_amount", value: "50000"}, {type: "uint256", name: "_bonus", value: "10000"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[41], "50000", "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510397249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x7059ede7d5058ad343b92a38d3d21936f393436e"}, {name: "value", type: "uint256", value: "50000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x7059ede7d5058ad343b92a38d3d21936f393436e"}, {name: "value", type: "uint256", value: "10000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[42], \"5000\", \"250\" )", async function( ) {
		const txOriginal = {blockNumber: "4531924", blockHash: "0x6cf9ca0b0f1890e2c6cd000de0cce1adb1417d3734caf67e02227cc7a0135d13", timeStamp: "1510397358", hash: "0x629e399c8d9078f3eddf1f498e737be54fd841c6669c573c34ffc0e9a4d34b97", nonce: "189", transactionIndex: "48", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158023", gasPrice: "8000000000", input: "0x93720b2f000000000000000000000000d5c0d45012a99ed297efea5da0ee9244fe44c067000000000000000000000000000000000000000000000000000000000000138800000000000000000000000000000000000000000000000000000000000000fa", contractAddress: "", cumulativeGasUsed: "2968238", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207291", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_amount", value: "5000"}, {type: "uint256", name: "_bonus", value: "250"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[42], "5000", "250", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510397358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0xd5c0d45012a99ed297efea5da0ee9244fe44c067"}, {name: "value", type: "uint256", value: "5000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0xd5c0d45012a99ed297efea5da0ee9244fe44c067"}, {name: "value", type: "uint256", value: "250"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: giveAways( addressList[43], \"1000\", \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "4531927", blockHash: "0xb2e7751100e57921c128c5a04b2ce9fc124087a1739cc9f016351572f5191b66", timeStamp: "1510397436", hash: "0xe58ac138e67505c178d4c9cba46c41ec1e44a1826d0eaf680a7b97c7673da909", nonce: "190", transactionIndex: "110", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "158023", gasPrice: "8000000000", input: "0x93720b2f00000000000000000000000051be6fb6371fce0c3c9b329d290f63088765ce8200000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3613618", txreceipt_status: "1", gasUsed: "158023", confirmations: "3207288", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_amount", value: "1000"}, {type: "uint256", name: "_bonus", value: "50"}], name: "giveAways", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveAways(address,uint256,uint256)" ]( addressList[43], "1000", "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510397436 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "to", type: "address", value: "0x51be6fb6371fce0c3c9b329d290f63088765ce82"}, {name: "value", type: "uint256", value: "1000"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x51be6fb6371fce0c3c9b329d290f63088765ce82"}, {name: "value", type: "uint256", value: "50"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[41], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531960", blockHash: "0x163a814bfe8f9f735b86dedf740f668c74788a8c8967e8dedc28a801401d2e4d", timeStamp: "1510397787", hash: "0xbe1f01e65306f59a5d2e0cd50c190fbecce2fb45bd098573afea7371db0e61c2", nonce: "191", transactionIndex: "24", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb0000000000000000000000007059ede7d5058ad343b92a38d3d21936f393436e00000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "792599", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207255", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[41], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510397787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x7059ede7d5058ad343b92a38d3d21936f393436e"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531961", blockHash: "0x8c41550e9b5f573a626aaa60dd3901d8e3144a2aef4b6c96010471c8ec3e813e", timeStamp: "1510397829", hash: "0xc9ed31fc6d9d9d94b6b11a1d43e1cc30715938f4f9ccbf1a3cae9e44488492a4", nonce: "192", transactionIndex: "129", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb000000000000000000000000841022ad9e41358aa7e5b55ba8297bd3509f520700000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "3541097", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207254", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510397829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x841022ad9e41358aa7e5b55ba8297bd3509f5207"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531961", blockHash: "0x8c41550e9b5f573a626aaa60dd3901d8e3144a2aef4b6c96010471c8ec3e813e", timeStamp: "1510397829", hash: "0x38f2f618b4e10ae60aee466411df1feedfb959a95d4472b421b729791d8587b3", nonce: "193", transactionIndex: "130", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb000000000000000000000000209f573f0ebd2d2161af6f26f9bc85a58b871b6500000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "3578865", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207254", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510397829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x209f573f0ebd2d2161af6f26f9bc85a58b871b65"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531965", blockHash: "0xb17470b89b3f2bb503a9b0b98ccf156dabb4fa8d049a31e0a563226a3c0442fd", timeStamp: "1510397857", hash: "0x45e998392c8f1e8702393bb468532f6dadbb1664b3075dbaa01caa5863580566", nonce: "194", transactionIndex: "5", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb00000000000000000000000012192d986bc92308e15242f5c4440c8d83777d4600000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "152749", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207250", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510397857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x12192d986bc92308e15242f5c4440c8d83777d46"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531967", blockHash: "0x6cd8eb6673d7d332ce95f92ceb77d2aa23afc1d642ee242aca965fd06fdfb698", timeStamp: "1510397878", hash: "0x5bda8b620d069883070d502cd58857b7c75a0b73209bbfa24a76cbd861b98530", nonce: "195", transactionIndex: "4", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb000000000000000000000000749bc1ab4a022a3ffbdc0cfe581b1f51eae00f5100000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "121858", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207248", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510397878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x749bc1ab4a022a3ffbdc0cfe581b1f51eae00f51"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531969", blockHash: "0x5d68a651bd04eeebb40b928ead7a4981f84de9a7817c2b7822a4693ccbf25ce9", timeStamp: "1510397927", hash: "0x32721fe25c63114eef4c2293363e8faa3dd2138f4beaa0791e697ddef17df111", nonce: "196", transactionIndex: "65", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb00000000000000000000000064b13ead6811576e2b6936812dc63f4e9d9e7c9800000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "2395719", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207246", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510397927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x64b13ead6811576e2b6936812dc63f4e9d9e7c98"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"200\" )", async function( ) {
		const txOriginal = {blockNumber: "4531969", blockHash: "0x5d68a651bd04eeebb40b928ead7a4981f84de9a7817c2b7822a4693ccbf25ce9", timeStamp: "1510397927", hash: "0xcae11530bb09f5742f30aa54cf074df4b1ee122b91e78e12cb916413c0bd1980", nonce: "197", transactionIndex: "120", from: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1", to: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d", value: "0", gas: "37768", gasPrice: "8000000000", input: "0xa9059cbb0000000000000000000000006d9db2295c9e4c61d0364b79d2b160728f1bdb1d00000000000000000000000000000000000000000000000000000000000000c8", contractAddress: "", cumulativeGasUsed: "4820578", txreceipt_status: "1", gasUsed: "37768", confirmations: "3207246", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_amount", value: "200"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510397927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x2eafad7c7edfdf9fc85ae5af291c629740e2eca1"}, {name: "to", type: "address", value: "0x6d9db2295c9e4c61d0364b79d2b160728f1bdb1d"}, {name: "value", type: "uint256", value: "200"}], address: "0x39013f961c378f02c2b82a6e1d31e9812786fd9d"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
