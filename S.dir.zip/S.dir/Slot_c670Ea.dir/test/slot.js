const Slot = artifacts.require( "./Slot.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Slot" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x17D0582dEe50A5401BB8F65ac29ec2da50c670Ea", "0x717Ba90414Bd948F9a160fAc79902f7211006A36", "0xE23f252F04AF5AF69Ae111C5a457E05a2e41eDEC", "0x434646c111104e5c981a704676473224E262dB04", "0x7F13568424A6ac702FefE1dF6908405CA10Cf093", "0x32373645359c9cCf1Bd2d63AfD153ff65D41A404", "0xf3c2F29bD3199C33d26cBc31d440F66d2065c4b3", "0xa6908713eFEB8AC130a16ED0DE1b93cd76cEA184"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "minipotTimes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "rolls", outputs: [{name: "bet", type: "uint256"}, {name: "lines", type: "uint8"}, {name: "rollCount", type: "uint8"}, {name: "blocknum", type: "uint256"}, {name: "next", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rollTail", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minipotPool", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rollHead", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "jackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minipot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getBonus", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pendingBetAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rollTimes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "jackpotPool", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getPartnersCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "partners", outputs: [{name: "from", type: "address"}, {name: "share", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}], name: "rollBlockNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "p1", type: "uint256"}, {name: "p2", type: "uint256"}, {name: "p3", type: "uint256"}], name: "calcPayout", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}, {name: "blocknum", type: "uint256"}, {name: "seed", type: "uint256"}], name: "calcRoll", outputs: [{name: "stops", type: "uint256[3]"}, {name: "winValue", type: "uint256"}, {name: "entropy", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RollBegin(address,uint256,uint8,uint256)", "RollEnd(address,uint256,uint8,uint32,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xffd22a95524610c1ca5b21061961a53f1601cce3018ab547f79e2880164c99d0", "0x105e6b7a8285a4edd8d566d8adc786d6d68c8b850357cd40449ab4347f07863e"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6787874 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6860026 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Slot", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "minipotTimes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minipotTimes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "rolls", outputs: [{name: "bet", type: "uint256"}, {name: "lines", type: "uint8"}, {name: "rollCount", type: "uint8"}, {name: "blocknum", type: "uint256"}, {name: "next", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rolls(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rollTail", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rollTail()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minipotPool", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minipotPool()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rollHead", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rollHead()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "jackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "jackpot()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minipot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minipot()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBonus", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBonus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pendingBetAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingBetAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rollTimes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rollTimes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "jackpotPool", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "jackpotPool()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPartnersCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPartnersCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "partners", outputs: [{name: "from", type: "address"}, {name: "share", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "partners(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "rollBlockNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rollBlockNumber(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "p1", value: random.range( maxRandom )}, {type: "uint256", name: "p2", value: random.range( maxRandom )}, {type: "uint256", name: "p3", value: random.range( maxRandom )}], name: "calcPayout", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcPayout(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "blocknum", value: random.range( maxRandom )}, {type: "uint256", name: "seed", value: random.range( maxRandom )}], name: "calcRoll", outputs: [{name: "stops", type: "uint256[3]"}, {name: "winValue", type: "uint256"}, {name: "entropy", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcRoll(address,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Slot", function( accounts ) {

	it( "TEST: Slot(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6787874", timeStamp: "1543404010", hash: "0x60e8473b27a44976ab90154c4f390f58d4bcfde4293969f7bf48eb55160777e1", nonce: "0", blockHash: "0xcfce2350e53c762db91f16f3beb9dd18eb58fce5e36bbf94a7e19029e7b6e3f7", transactionIndex: "118", from: "0x717ba90414bd948f9a160fac79902f7211006a36", to: 0, value: "0", gas: "3366875", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x5485a863", contractAddress: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", cumulativeGasUsed: "7529206", gasUsed: "3266875", confirmations: "914782"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Slot", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Slot.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543404010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Slot.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "76957750000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6796178", timeStamp: "1543521740", hash: "0xe4f6fa9b49b47cd718ddf45eaf3409bf89e02e6a46d0c7a6055c6204fec4aa92", nonce: "20", blockHash: "0x7af3c2e5feab5a25fc41b147e2c3a860c10eb486dcd41d21c3664812290a823c", transactionIndex: "52", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "212295", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5100528", gasUsed: "212295", confirmations: "906478"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543521740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6796180", timeStamp: "1543521759", hash: "0xafc8e0232f7fd4040462ee7086560a9011bc752c3abde010b6fd6790712fb81d", nonce: "22", blockHash: "0x5f378af2004d6392dab9a15fca755e1daa2bf302cb04bc4401adf9330ab1b714", transactionIndex: "18", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "212295", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1468359", gasUsed: "22595", confirmations: "906476"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543521759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6796181", timeStamp: "1543521760", hash: "0xf1006330f687bc443653cb209104e8e5ceaf186b7d6fa15e37eb2239f7e082c6", nonce: "23", blockHash: "0x9ac1878b95ecce609af377e77450d832201402b478ad1ec5829d1afd5f1ab530", transactionIndex: "20", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "212295", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1380389", gasUsed: "22595", confirmations: "906475"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543521760 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6797933", timeStamp: "1543546827", hash: "0x9327783b4ecf294c00833d880244bf7447bdd94b713b0cbd024385451eec9629", nonce: "0", blockHash: "0xfee03457eff40957d0e2eb10c16cef8607475564d15dbb21a063bdb27ab39498", transactionIndex: "87", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "256286", gasPrice: "6500330000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7163575", gasUsed: "64072", confirmations: "904723"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543546827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6798996", timeStamp: "1543562161", hash: "0xc79e8ff2ae0cfc8fe3e396f7b7a814ef697ebee43010be5d539445ea9a7eb191", nonce: "24", blockHash: "0xdea3867597283f232d1c44a01d00564eb5b9aa38f4592afe39ffb2b037d51508", transactionIndex: "25", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1093751", gasUsed: "182295", confirmations: "903660"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543562161 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6799028", timeStamp: "1543562671", hash: "0x9d30e3e95718fe2e37bdabb0987dbff0220caba954b1d918df833f3059938a7a", nonce: "1", blockHash: "0xd6bbbcac786d15bbd939ea5880b11d21864e25fcb1f347d5402beedfbd96d9f9", transactionIndex: "20", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "237286", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "940134", gasUsed: "59322", confirmations: "903628"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543562671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327941]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6799217", timeStamp: "1543565312", hash: "0x06c4526c474480f919ed653999c072ed0bd3705bd62e5aed34c70ee5726877fd", nonce: "25", blockHash: "0x8065b5c2bc76a1c4e336a30af756b6d6b1179aeddb6f055b6c7b5cc2c51a2e99", transactionIndex: "105", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5746617", gasUsed: "182295", confirmations: "903439"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543565312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6799217", timeStamp: "1543565312", hash: "0x7fb862639f72f29b122e227c4200a82be024942adbd2c8017db9837bf1eb2091", nonce: "26", blockHash: "0x8065b5c2bc76a1c4e336a30af756b6d6b1179aeddb6f055b6c7b5cc2c51a2e99", transactionIndex: "106", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5769212", gasUsed: "22595", confirmations: "903439"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543565312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800185", timeStamp: "1543578456", hash: "0xa282f489bc8f898911ced97b156cd06da49aa3f4441e9185cccc84ebd69d29cb", nonce: "2", blockHash: "0x33754fa82e456acd0aa68b145b547cc47d2f1bb07ae03fcaa865b2360124d64f", transactionIndex: "166", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "302938", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6906612", gasUsed: "37435", confirmations: "902471"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543578456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800356", timeStamp: "1543581041", hash: "0x2eaac7fe8a9b0aba114e12d34d5298ac96d40b1eea27b97539950fbbef511a45", nonce: "27", blockHash: "0xaeba6263c92a807fdeda6e8f41aeb663e529109c4effe25c8fc9577e07a4cfe6", transactionIndex: "97", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3624813", gasUsed: "182295", confirmations: "902300"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543581041 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800359", timeStamp: "1543581066", hash: "0x05159fb6ac7bc39433e08db6c72bdbf8a7b91453d0b1f30957a4a4a1bbb1f793", nonce: "3", blockHash: "0x42e120ce516d6821e532108b7367f387e5cd1e6cf1300178892243c2302added", transactionIndex: "75", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "172420", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4699339", gasUsed: "51822", confirmations: "902297"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543581066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262402]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800379", timeStamp: "1543581297", hash: "0xb70da6949f54ee0018bc7d37c462c9a302a1b37baee5dd5bc5e60fd4c7f8b921", nonce: "28", blockHash: "0xbadda15c9ff5e892150b5b1a49cb550d46a9773b0099d297e6eaaa90f9c91c68", transactionIndex: "40", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2515747", gasUsed: "182295", confirmations: "902277"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543581297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800381", timeStamp: "1543581346", hash: "0x943c7d696fe8f075d1592d408a1241183587f5135c79b65d36b22e6dfd3a2762", nonce: "4", blockHash: "0xde35f445a510b70050da27ceaf9157b3da9211aee666c0aabd54d65c06761c7d", transactionIndex: "21", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "172420", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1087452", gasUsed: "51822", confirmations: "902275"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543581346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131843]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800417", timeStamp: "1543581831", hash: "0xff970c8dc0b9ffce2ae3112edaaccabac438469ee94f3b0fcea55a12f5995e60", nonce: "29", blockHash: "0xa3175843c35fcb5d2a36b2dca0671fa98dea5d9befa2e8fb617d821bad43150c", transactionIndex: "33", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4177303", gasUsed: "182295", confirmations: "902239"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543581831 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800420", timeStamp: "1543581846", hash: "0x76178f742f7c1d83afc5839601cb6ad23a84245cc3832a13908659c63c9cce1d", nonce: "5", blockHash: "0xb6869d8b3bd13022be304d72b9efa47d8808c2784be34576aa775767e328b8d1", transactionIndex: "20", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "207286", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1263488", gasUsed: "51822", confirmations: "902236"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543581846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [132099]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800526", timeStamp: "1543583192", hash: "0xdb108562a84ebd02dabf77f31ef812bb957bc4480b0a7a557831721d7cf4bf57", nonce: "30", blockHash: "0x20468145dcd6ee54ea66c486785ed805a4a03e8a7ccab8c5cb8f78e5c498c151", transactionIndex: "40", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2065339", gasUsed: "182295", confirmations: "902130"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543583192 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800538", timeStamp: "1543583297", hash: "0x98fab2582e07220238470338da3c6c99c848b2b1e2bfd0393f272ed417aecaa6", nonce: "6", blockHash: "0x1490d5cfaecdd309be5ab4962dd325ebac20eb5d336b01cf77eb2e2ffd7f3d2a", transactionIndex: "187", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "207286", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5310351", gasUsed: "51822", confirmations: "902118"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543583297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131332]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800598", timeStamp: "1543584203", hash: "0xfc6918dbca03fb575562f59801609d5b97c16edab707f659ea663a16af6cf7c1", nonce: "31", blockHash: "0x66a8be624afc3740dc0ceed3bd10f2f45ce33345b966e6589f69a217e9fd3818", transactionIndex: "37", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1967892", gasUsed: "182295", confirmations: "902058"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543584203 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800600", timeStamp: "1543584215", hash: "0x2a00b88532ccc5a8effe212af8caaaac5f4ba6c5bf09a6f855219ac073a673c8", nonce: "7", blockHash: "0xf2969f77dc40f9e8297f2706537183d6384e69add41f52606a7746003f19371e", transactionIndex: "31", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "172420", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "758625", gasUsed: "56214", confirmations: "902056"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543584215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65795]}}, {name: "win", type: "uint256", value: "20000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800604", timeStamp: "1543584226", hash: "0x0a01bfac468d917694cbcb8ffec42c4b4b8322c2c3044d401f31f8d45c76e42e", nonce: "8", blockHash: "0x8e9c45b63c8ca5550da756bcce6934568be5f942268d10d3e8473dde91958255", transactionIndex: "11", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "44348", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "501611", gasUsed: "22174", confirmations: "902052"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543584226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800614", timeStamp: "1543584403", hash: "0x75fd41420a99dbfd4573e2a069013fd6d80ddeb7df18fc9738f3c8c3a51eebb1", nonce: "32", blockHash: "0xe6a7095c9818da5da73e5fb22566796312132a88e1540900fb23b80ed7378707", transactionIndex: "46", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7846200", gasUsed: "182295", confirmations: "902042"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543584403 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800619", timeStamp: "1543584457", hash: "0xb6c4684053c7bf4302b7f801faf19b6e1e634806d2c3d63dbda30886c1b90415", nonce: "9", blockHash: "0x924f49292bbdee78011e93c2bd9d4fc0ffbdcf0388ffcacda44435d69fdbd0be", transactionIndex: "85", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "45734", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7891126", gasUsed: "45734", confirmations: "902037"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6800622", timeStamp: "1543584485", hash: "0x9bc3cd1e01416736846bdfbc90f3ff063bc38a1c36db29fae92fd39f493cec69", nonce: "10", blockHash: "0x53788c384a451fd4a623bf8a0374c819c1fafd488ac070567031bf3553a81bb1", transactionIndex: "34", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "207286", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2032945", gasUsed: "51822", confirmations: "902034"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543584485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [66309]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6842785", timeStamp: "1544188662", hash: "0x572f386f083626a6b524d92d62f7c1610ebdee56343ad5e4ed469c53244bb734", nonce: "34", blockHash: "0x72db65b8d59efdd6e31d7229c33b2b6b70c1961acef5f0813e0b953260cc1a8c", transactionIndex: "54", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "50000000000000000", gas: "182295", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "3103714", gasUsed: "182295", confirmations: "859871"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "5"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544188662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "5"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6842807", timeStamp: "1544188977", hash: "0x0150517a7845589cdebea053284bf35dce999564784a0c6cd67f72285c7efd3a", nonce: "11", blockHash: "0xd8967992f3777b829fef845c6574406069d99aac96f0faad4796be10d6256a0e", transactionIndex: "13", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "862100", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "781575", gasUsed: "156008", confirmations: "859849"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544188977 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [67077]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196867]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65797]}}, {name: "win", type: "uint256", value: "40000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196870]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327940]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6842990", timeStamp: "1544191493", hash: "0x0016224136f53785fc48e70cd72feb5ec3c610a34810a4ac321d02ec1b3667e0", nonce: "35", blockHash: "0x1d5e11dbc85c446ec95713db8573b40f2688c7a03f31b6394a02bd91cb904226", transactionIndex: "94", from: "0xe23f252f04af5af69ae111c5a457e05a2e41edec", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6974530", gasUsed: "182295", confirmations: "859666"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544191493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "87036774318859741" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6842993", timeStamp: "1544191549", hash: "0x8f9a4fe411d526273376664f785e6037e61f73ccfb022f325740149b276cdde6", nonce: "12", blockHash: "0xa4efdd6a795673938d697cfa915b5e344097604a330830a60ec04856a358d610", transactionIndex: "63", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "207286", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2847650", gasUsed: "51822", confirmations: "859663"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544191549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xe23f252f04af5af69ae111c5a457e05a2e41edec"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327941]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6845340", timeStamp: "1544225091", hash: "0xb950d8e2f5387dff3d421a38df112e8e0a968b7cb631530683c876b325d6708d", nonce: "1078", blockHash: "0x6aed67dbb24a06e60dc1795f07f9635c551db62d4bde3bda8539041756020477", transactionIndex: "55", from: "0x7f13568424a6ac702fefe1df6908405ca10cf093", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "6300000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3615924", gasUsed: "182295", confirmations: "857316"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544225091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "115301300000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6845341", timeStamp: "1544225110", hash: "0x0b0a3391610426a6e020248e3dc26ccd9e5cd3306ed7fa32d7d95090cfa5777c", nonce: "13", blockHash: "0x2add926a56a8ba88d6a20d5f2818d71eb4a9053018162e48ec0d853e2ce4c0a2", transactionIndex: "25", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "172420", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2318629", gasUsed: "56603", confirmations: "857315"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544225110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65797]}}, {name: "win", type: "uint256", value: "40000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6845729", timeStamp: "1544230802", hash: "0x13a901d83d8036a1206019eb44e872ac33c3ac4e2e2e761ac5eb22116a569121", nonce: "1092", blockHash: "0xcf1729f991039171e123bfe5256e79eaaaae9dd781d30b74ada956cbba25e22a", transactionIndex: "93", from: "0x7f13568424a6ac702fefe1df6908405ca10cf093", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7398555", gasUsed: "182295", confirmations: "856927"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544230802 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "115301300000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6845732", timeStamp: "1544230895", hash: "0xa71c539cbdb947b4cbfc91f93662793c188f0f2d7d57788d16007d01c91a4bf4", nonce: "14", blockHash: "0xb5f68f773cd6bb880692d27bdc9812360ad8aec75e7ccb80b535f737b4744ade", transactionIndex: "23", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "207286", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1210319", gasUsed: "51822", confirmations: "856924"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544230895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [329222]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6845737", timeStamp: "1544230991", hash: "0xa0f243742653e88d5d9dbf96aee053c471a4dd20698847c3d04f32f58a791904", nonce: "1093", blockHash: "0xb2cca0fd9e85310ec04d7a7be0cf5cbede5a037ed86ca9d8320918141df44c4a", transactionIndex: "82", from: "0x7f13568424a6ac702fefe1df6908405ca10cf093", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6586017", gasUsed: "182295", confirmations: "856919"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544230991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "173608448000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6845739", timeStamp: "1544231065", hash: "0xdad4c323c617977c5a14f5dcdda1ea1a7b9df97c911fa50e04314f253b9b8e64", nonce: "15", blockHash: "0x54ae603d19e1da8f405d97c373c4f9d9e40eb7b83d61ce4309335879f23a598f", transactionIndex: "21", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "172420", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1388726", gasUsed: "51822", confirmations: "856917"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544231065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262405]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6848172", timeStamp: "1544265768", hash: "0x708ff2704d013c90513c0ffcb3cb3e699b45e37dacddb030f184a1d16363a554", nonce: "1104", blockHash: "0x01479b2a36568bdb885012bf6faa5b346e665dda159d7a73b7a6aee0b25a7d6f", transactionIndex: "49", from: "0x7f13568424a6ac702fefe1df6908405ca10cf093", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "20000000000000000", gas: "182295", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7916849", gasUsed: "182295", confirmations: "854484"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "2"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544265768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "2"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "113115596000000001" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6848174", timeStamp: "1544265804", hash: "0x506c58c700b999e83f9800e433794a845157e45b27e39e3f0d27406daeb27d14", nonce: "16", blockHash: "0xb68de82c31343376066ec2c6ae0662c39d6a6d503e14f15ae9e8c70373d0670d", transactionIndex: "13", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "45734", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "455189", gasUsed: "45734", confirmations: "854482"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6848177", timeStamp: "1544265879", hash: "0x4a0078ae58a9eed91f513ba23bbf1a3881bfb7e60e16399574c20e545e9a9bd1", nonce: "17", blockHash: "0x0ae064fcdae9014fcfd55d41657f1c7846327a50cfee27d803745f97cf572bae", transactionIndex: "40", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "344840", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2222614", gasUsed: "70297", confirmations: "854479"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544265879 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [67076]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x7f13568424a6ac702fefe1df6908405ca10cf093"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196867]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6852271", timeStamp: "1544324296", hash: "0x2aacfbdba6283adcce429aa4d1e2acfd1bfebbc990b3936ff0b104277834d690", nonce: "341", blockHash: "0x43f877efd5e03f08d7ab019613bb530450fa542349367dbab28c47621c3b99df", transactionIndex: "78", from: "0x32373645359c9ccf1bd2d63afd153ff65d41a404", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "200000000000000000", gas: "182295", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "6267021", gasUsed: "182295", confirmations: "850385"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "20"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544324296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "20"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "740463865209652656" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6852274", timeStamp: "1544324329", hash: "0xec0b7d61913505712a338bfac50afa7cc6ec1f2aaa8df2182e8a76202c8177c7", nonce: "18", blockHash: "0x29fe1ca46b1dcc429ee4203da7012fa79d370a6496fdba80471cb297d3cc36cc", transactionIndex: "4", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "3448400", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1038149", gasUsed: "710349", confirmations: "850382"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544324329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196869]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131334]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [328195]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262406]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [197380]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [198149]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196868]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [197126]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262659]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393988]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327941]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [66307]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196869]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393988]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393475]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65798]}}, {name: "win", type: "uint256", value: "40000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262404]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393477]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327940]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131844]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6852276", timeStamp: "1544324402", hash: "0x6bee83f477c1599b23b80c336d58ecdefac8525ba711baea889bba75646fd62d", nonce: "19", blockHash: "0x311c6cc7bf7f204a3e8de405097059d984a14e1602a2694140c24f835eac5d21", transactionIndex: "9", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "44348", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "396466", gasUsed: "22174", confirmations: "850380"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544324402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6852285", timeStamp: "1544324498", hash: "0x275260f9307663018b0e023f30d980fb23fc661a23ef41c23f27950758df14ca", nonce: "342", blockHash: "0x54b666c2e7b64d9a207f947820633569b6c4195b3b9d64c8708fad81456eba38", transactionIndex: "34", from: "0x32373645359c9ccf1bd2d63afd153ff65d41a404", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "200000000000000000", gas: "182295", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "5265059", gasUsed: "182295", confirmations: "850371"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "20"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544324498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "20"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "740463865209652656" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6852286", timeStamp: "1544324544", hash: "0x1dc7e886d14c2d8fdde56dec77cb033fa62fdddbde28b2286e5a38bbc39e3a39", nonce: "20", blockHash: "0xdcef33965360fc369e71480a916c053fbe231ca8d8ead1a508a9ea8a3d674a9c", transactionIndex: "36", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "3448400", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2120748", gasUsed: "736578", confirmations: "850370"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544324544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327940]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [66308]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327942]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262916]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131330]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [263685]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [67076]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327941]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [328452]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [197635]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65797]}}, {name: "win", type: "uint256", value: "40000000000000000"}, {name: "minipot", type: "uint256", value: "30000000000000000"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327939]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65796]}}, {name: "win", type: "uint256", value: "20000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131843]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [66307]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262404]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262918]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [197380]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393477]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196870]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6852319", timeStamp: "1544325001", hash: "0x2683bedc087ff48bef1f086802b285616d7b6053bc1faaccdff384df81f62725", nonce: "344", blockHash: "0xb94620f69686230e5c56989ed4fc6896f2b29e4085e4bbcd1c2194574faac235", transactionIndex: "124", from: "0x32373645359c9ccf1bd2d63afd153ff65d41a404", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "200000000000000000", gas: "182295", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "5376402", gasUsed: "182295", confirmations: "850337"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "20"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544325001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "20"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "740463865209652656" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6852321", timeStamp: "1544325061", hash: "0xcec7cbc1d6904d202cd3a3694de47cb8a2a7ac37cc5ba0ab6cd587646fd42a1a", nonce: "21", blockHash: "0xd2c53972b5ad849f1878417f1c92599cc6db514a7de5f871dfb371c142ed0210", transactionIndex: "41", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "3448400", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2664126", gasUsed: "750944", confirmations: "850335"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544325061 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327940]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262916]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [328451]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327940]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [198147]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [197637]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327941]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [198149]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [66051]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [327939]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [394758]}}, {name: "win", type: "uint256", value: "1000000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131333]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65797]}}, {name: "win", type: "uint256", value: "40000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393989]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196868]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [329221]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [196866]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [65797]}}, {name: "win", type: "uint256", value: "40000000000000000"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [262915]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0x32373645359c9ccf1bd2d63afd153ff65d41a404"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [393477]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6854956", timeStamp: "1544362729", hash: "0x106ffa96a3b58d37affba42fc8efbcc6cdab2d935924b64fee60bdd3f9f5c63d", nonce: "1996", blockHash: "0x0ced9de139e6e652ef52f4c1e29f0a1aa2e84c6a6873c98b46f745d4414fe201", transactionIndex: "32", from: "0xf3c2f29bd3199c33d26cbc31d440f66d2065c4b3", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "30000000000000000", gas: "182295", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7557812", gasUsed: "182295", confirmations: "847700"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "3"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544362729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xf3c2f29bd3199c33d26cbc31d440f66d2065c4b3"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "3"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "7384906099838666302" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6854958", timeStamp: "1544362767", hash: "0x34404a05aa6b01d9f0f0f1367858efa92ac57a278bd18c4a8498942dc0150b29", nonce: "22", blockHash: "0xbabdca5c036291a92c216a9281c4c566eb31d31768a55f5c7adc8059dcc949f0", transactionIndex: "42", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "517260", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1351861", gasUsed: "88771", confirmations: "847698"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544362767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xf3c2f29bd3199c33d26cbc31d440f66d2065c4b3"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [394757]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0xf3c2f29bd3199c33d26cbc31d440f66d2065c4b3"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [263684]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}, {name: "RollEnd", events: [{name: "from", type: "address", value: "0xf3c2f29bd3199c33d26cbc31d440f66d2065c4b3"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 4, c: [66052]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6854959", timeStamp: "1544362774", hash: "0xfeeb1c1d4118cb8ac4c1bb380fca112a7892abda54076d5f7fe845b36ad4afa2", nonce: "23", blockHash: "0xed68f21e89c71c3b2367497fc71e70de009dc393b088d838b71292caf07305a4", transactionIndex: "37", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "517260", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1307940", gasUsed: "22174", confirmations: "847697"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544362774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: roll( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6860021", timeStamp: "1544433515", hash: "0x45c63cd899399dc772eb7a02caf7ef8bb1f6c3e1923d098eef6e8a52e897c867", nonce: "154", blockHash: "0x86302182c79fe7a684ca2cec56058e8578e9243f3e5830a22a47a1c2e7725ea8", transactionIndex: "38", from: "0xa6908713efeb8ac130a16ed0de1b93cd76cea184", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "10000000000000000", gas: "182295", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcd230dcb00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4906489", gasUsed: "182295", confirmations: "842635"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "lines", value: "1"}, {type: "uint8", name: "count", value: "1"}], name: "roll", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "roll(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544433515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "count", type: "uint256"}], name: "RollBegin", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RollBegin", events: [{name: "from", type: "address", value: "0xa6908713efeb8ac130a16ed0de1b93cd76cea184"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "count", type: "uint256", value: "1"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "10402021682935675" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6860023", timeStamp: "1544433566", hash: "0x0732b68549c9e68beba99a3445fad9fa77d984bfead6353c951fb41bc7b46d0c", nonce: "24", blockHash: "0x7fd3b14dad7e9308c3ed78fe8c9155af6ed3be7477af2190013fffe79f0bea48", transactionIndex: "52", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "45734", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1819416", gasUsed: "45734", confirmations: "842633"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: check( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6860026", timeStamp: "1544433633", hash: "0xff731b8801e35b8ae310866f7c93eb774e5ecf8c8d2093d88663f062d5f7b98b", nonce: "25", blockHash: "0xf47d60e02fb6ed07b7513090cceb286d6033259362762fd7b05732007c91423a", transactionIndex: "25", from: "0x434646c111104e5c981a704676473224e262db04", to: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea", value: "0", gas: "207286", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x5f72f4500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2246539", gasUsed: "51822", confirmations: "842630"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxCount", value: "1"}], name: "check", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "check(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544433633 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "bet", type: "uint256"}, {indexed: false, name: "lines", type: "uint8"}, {indexed: false, name: "wheel", type: "uint32"}, {indexed: false, name: "win", type: "uint256"}, {indexed: false, name: "minipot", type: "uint256"}], name: "RollEnd", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RollEnd", events: [{name: "from", type: "address", value: "0xa6908713efeb8ac130a16ed0de1b93cd76cea184"}, {name: "bet", type: "uint256", value: "10000000000000000"}, {name: "lines", type: "uint8", value: "1"}, {name: "wheel", type: "uint32", value: {s: 1, e: 5, c: [131334]}}, {name: "win", type: "uint256", value: "0"}, {name: "minipot", type: "uint256", value: "0"}], address: "0x17d0582dee50a5401bb8f65ac29ec2da50c670ea"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "601471706056240000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1030000000000002297" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
