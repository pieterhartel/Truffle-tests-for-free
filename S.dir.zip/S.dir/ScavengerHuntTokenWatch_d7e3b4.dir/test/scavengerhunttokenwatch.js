const ScavengerHuntTokenWatch = artifacts.require( "./ScavengerHuntTokenWatch.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ScavengerHuntTokenWatch" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x77f07B4831113143C24dd651a682c001D9d7E3b4", "0x264b05c80b8EB151d5ad5946d2B0bC0959047042", "0xD538a43dB3c319356a7561C0F23F0A850D225F21", "0x83D811269FB405a2c91Fab2054DfaA39EE02E173"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "x", type: "bytes32"}], name: "getKeyAsString", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "tokensDistributed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "crowdsaleDeadline", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}, {name: "", type: "bytes32"}], name: "GPSActivityAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "scavengerHuntTokenSymbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalHunters", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "ScavengerHuntTokenOwner", type: "address"}], name: "getPercentageComplete", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "dailyRewardCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxDailyRewards", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "registeredNames", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}, {name: "", type: "bytes32"}], name: "GPSDigs", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getToday", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "frozenAccount", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "key", type: "string"}], name: "getStringAsKey", outputs: [{name: "ret", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "scavengerHuntTokenName", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "target", type: "address"}], name: "getBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "backer", type: "address"}, {indexed: false, name: "amountEhter", type: "uint256"}, {indexed: false, name: "amountScavengerHuntTokens", type: "uint256"}, {indexed: false, name: "isContribution", type: "bool"}], name: "FundTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "ShareLocation", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "recipient", type: "address"}, {indexed: false, name: "Message", type: "string"}, {indexed: false, name: "TokenName", type: "string"}], name: "ShareMessage", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "totalTokensDistributed", type: "uint256"}, {indexed: false, name: "totalHunters", type: "uint256"}], name: "SaleEnded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "Sender", type: "address"}, {indexed: false, name: "MyPersonalMessage", type: "string"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "SharePersonalMessage", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "Name", type: "string"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "NameClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}, {indexed: false, name: "frozen", type: "bool"}], name: "FrozenFunds", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Burn", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["FundTransfer(address,uint256,uint256,bool)", "ShareLocation(address,uint256,uint256,bytes32,bytes32)", "ShareMessage(address,string,string)", "SaleEnded(address,uint256,uint256)", "SharePersonalMessage(address,string,bytes32,bytes32)", "NameClaimed(address,string,bytes32,bytes32)", "HunterRewarded(address,uint256,uint256,bytes32,bytes32)", "FrozenFunds(address,bool)", "Transfer(address,address,uint256)", "Burn(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8026fe2448be156ffb855f15d0f3dd2dd9f894e691b4cc72bce178af3393c3b5", "0x67f3b292a2a9969609a74f1554be02dc80c63eea2f9e412cba441d08ef76bba7", "0xf30bb22888434f4aa3caabec12635210a572f0326e3776000dfd07df166f84e8", "0xf763a771d96757391a5336bd1c92609108208aeb3cfc50c8e12561f156f9f878", "0xcb3595811d147ae189bddf894f6f690feffd0302d7611f50f12a86f1022e0434", "0xf5ba39e02b6623d9199fb584db1d18659ccd7c5160102b14d238148f7b4dccd9", "0x499125a449bbbdab7ea02a2d18015c7aca5b9b3ad3f04660c224b6d84a269699", "0x48335238b4855f35377ed80f164e8c6f3c366e54ac00b96a6402d4a9814a03a5", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0xcc16f5dbb4873280815c1ee09dbd06736cffcc184412cf7a71a0fdb75d397ca5"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4966540 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4977822 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "ifSuccessfulSendTo", value: 3}, {type: "uint256", name: "durationInMinutes", value: "227520"}, {type: "uint256", name: "weiCostOfEachToken", value: "10000000000000"}, {type: "uint256", name: "initialSupply", value: "10000"}, {type: "string", name: "tokenName", value: "ScavengerHuntToken1"}, {type: "string", name: "tokenSymbol", value: "SHT1"}, {type: "uint256", name: "adigHashBase", value: "9234732894794023423694044543535887643456432432572356329024934572347"}, {type: "uint256", name: "aMaxDailyRewards", value: "100"}], name: "ScavengerHuntTokenWatch", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "x", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getKeyAsString", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getKeyAsString(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensDistributed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensDistributed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "crowdsaleDeadline", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "crowdsaleDeadline()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "GPSActivityAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GPSActivityAddress(bytes32,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "scavengerHuntTokenSymbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "scavengerHuntTokenSymbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalHunters", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalHunters()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sellPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "ScavengerHuntTokenOwner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPercentageComplete", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPercentageComplete(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "dailyRewardCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dailyRewardCount(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxDailyRewards", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxDailyRewards()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "registeredNames", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "registeredNames(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "GPSDigs", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GPSDigs(bytes32,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getToday", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getToday()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "frozenAccount", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "frozenAccount(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "key", value: random.string( maxRandom )}], name: "getStringAsKey", outputs: [{name: "ret", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStringAsKey(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "scavengerHuntTokenName", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "scavengerHuntTokenName()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "target", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ScavengerHuntTokenWatch", function( accounts ) {

	it( "TEST: ScavengerHuntTokenWatch( addressList[3], \"227520\", \"1000000000... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4966540", timeStamp: "1516833118", hash: "0x1f26f9304a63c4f75e0906f7b5cf2b3b52a610a6785f0bdf733b0b3a98bfa1aa", nonce: "0", blockHash: "0x747e5c1edfd67eb709e38937734a7ae02fcb202e1d79d5443eb7837df3d4c38e", transactionIndex: "23", from: "0x264b05c80b8eb151d5ad5946d2b0bc0959047042", to: 0, value: "0", gas: "2808671", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x1a9383ca000000000000000000000000264b05c80b8eb151d5ad5946d2b0bc095904704200000000000000000000000000000000000000000000000000000000000378c0000000000000000000000000000000000000000000000000000009184e72a0000000000000000000000000000000000000000000000000000000000000002710000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001400000000057b064639dd3d2b1228fd4df8c1416ee26e8db4d686d7b1f9bd2f13b0000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000001353636176656e67657248756e74546f6b656e310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000045348543100000000000000000000000000000000000000000000000000000000", contractAddress: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", cumulativeGasUsed: "4328842", gasUsed: "2708671", confirmations: "2756380"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "ifSuccessfulSendTo", value: addressList[3]}, {type: "uint256", name: "durationInMinutes", value: "227520"}, {type: "uint256", name: "weiCostOfEachToken", value: "10000000000000"}, {type: "uint256", name: "initialSupply", value: "10000"}, {type: "string", name: "tokenName", value: `ScavengerHuntToken1`}, {type: "string", name: "tokenSymbol", value: `SHT1`}, {type: "uint256", name: "adigHashBase", value: "9234732894794023423694044543535887643456432432572356329024934572347"}, {type: "uint256", name: "aMaxDailyRewards", value: "100"}], name: "ScavengerHuntTokenWatch", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ScavengerHuntTokenWatch.new( addressList[3], "227520", "10000000000000", "10000", `ScavengerHuntToken1`, `SHT1`, "9234732894794023423694044543535887643456432432572356329024934572347", "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1516833118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ScavengerHuntTokenWatch.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "backer", type: "address"}, {indexed: false, name: "amountEhter", type: "uint256"}, {indexed: false, name: "amountScavengerHuntTokens", type: "uint256"}, {indexed: false, name: "isContribution", type: "bool"}], name: "FundTransfer", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "FundTransfer", events: [{name: "backer", type: "address", value: "0x264b05c80b8eb151d5ad5946d2b0bc0959047042"}, {name: "amountEhter", type: "uint256", value: "0"}, {name: "amountScavengerHuntTokens", type: "uint256", value: "10000"}, {name: "isContribution", type: "bool", value: true}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1324602001720000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buyScavengerHuntTokenWithLocationSharing( \"0x35322e303736393539323637343439373400... )", async function( ) {
		const txOriginal = {blockNumber: "4966604", timeStamp: "1516834083", hash: "0x9a61c6b4ec6491b1d30649fc63c47ccd246928346f0c461d2c2ac19d9ba3b8e0", nonce: "0", blockHash: "0xd286385807536ba6893e0b6e6922717ff55b765f8aec8eadcdc13ab9bff11b53", transactionIndex: "103", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "70000000000000000", gas: "800000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x669edcdc35322e3037363935393236373434393734000000000000000000000000000000352e303837383832353232343636353734000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3479032", gasUsed: "68760", confirmations: "2756316"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "70000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037363935393236373434393734000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303837383832353232343636353734000000000000000000000000000000"}], name: "buyScavengerHuntTokenWithLocationSharing", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyScavengerHuntTokenWithLocationSharing(bytes32,bytes32)" ]( "0x35322e3037363935393236373434393734000000000000000000000000000000", "0x352e303837383832353232343636353734000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1516834083 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "backer", type: "address"}, {indexed: false, name: "amountEhter", type: "uint256"}, {indexed: false, name: "amountScavengerHuntTokens", type: "uint256"}, {indexed: false, name: "isContribution", type: "bool"}], name: "FundTransfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "FundTransfer", events: [{name: "backer", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "amountEhter", type: "uint256", value: "70000000000000000"}, {name: "amountScavengerHuntTokens", type: "uint256", value: "7000"}, {name: "isContribution", type: "bool", value: true}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "ShareLocation", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ShareLocation", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "7000"}, {name: "PercentageOfTotal", type: "uint256", value: "41176"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037363935393236373434393734000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303837383832353232343636353734000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}, {name: "to", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "value", type: "uint256", value: "7000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[1,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303832000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966766", timeStamp: "1516836351", hash: "0x2a37e448b721412e45fbaf1aab37a3da41bc8bb0d1281c7ddb9dcc4e5ee4b960", nonce: "3", blockHash: "0x4c697f5aca3b88739f700b4ae973bb08314919ac9c32240b10b5e645048d2f3b", transactionIndex: "72", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3038320000000000000000000000000000000000000000000000000000352e303937000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3667271", gasUsed: "88849", confirmations: "2756154"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3038320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303937000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3038320000000000000000000000000000000000000000000000000000", "0x352e303937000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1516836351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[2,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41173"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3038320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303937000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[2,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303737000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966797", timeStamp: "1516836758", hash: "0xddfb433b7fc6444bcfadd62831785bbf7e7aaf3007666426bdcf4c7adc492a76", nonce: "4", blockHash: "0x8fffa326712f1480f643fda29ba50006e552b788a3994680dee7bb33e81e3dd4", transactionIndex: "35", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2530000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037370000000000000000000000000000000000000000000000000000352e303838000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6069426", gasUsed: "88849", confirmations: "2756123"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303838000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037370000000000000000000000000000000000000000000000000000", "0x352e303838000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1516836758 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[3,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41169"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303838000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[3,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303736000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966805", timeStamp: "1516836838", hash: "0xfe3fad65adaa8ad94e4666c1941662c03ca7324f4aa5b4659c58c48542f396f2", nonce: "5", blockHash: "0xc4c032525c81b8428d514304c6f2aa73c7c2dab1ca9bb45c26eff3e10384320c", transactionIndex: "64", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2530000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037360000000000000000000000000000000000000000000000000000352e303838000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4538559", gasUsed: "88849", confirmations: "2756115"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303838000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037360000000000000000000000000000000000000000000000000000", "0x352e303838000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1516836838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[4,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41166"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303838000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[4,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303736000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966815", timeStamp: "1516837015", hash: "0xca5dcb78fdc887381fd61c90aa339b5f1fb17b4ab6ae6bfb12946507cb12f31f", nonce: "6", blockHash: "0x906b75849090b32485815f5038ab6d66d89e520c20bf6180c2bb1aa7510e59d7", transactionIndex: "22", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2400000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037360000000000000000000000000000000000000000000000000000352e303839000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5603566", gasUsed: "88849", confirmations: "2756105"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037360000000000000000000000000000000000000000000000000000", "0x352e303839000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1516837015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[5,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41162"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[5,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303737000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966815", timeStamp: "1516837015", hash: "0x13f8404a29956fa406cac962d235dbe50d440c2e4c6d48f141da5b9911d9e0a3", nonce: "7", blockHash: "0x906b75849090b32485815f5038ab6d66d89e520c20bf6180c2bb1aa7510e59d7", transactionIndex: "23", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2400000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037370000000000000000000000000000000000000000000000000000352e303839000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5692415", gasUsed: "88849", confirmations: "2756105"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037370000000000000000000000000000000000000000000000000000", "0x352e303839000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1516837015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[6,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41159"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[6,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303737000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966817", timeStamp: "1516837055", hash: "0xa9709e75afe6a6b442845a2857b212a01b9677249fc3f58192edb03bfe45bff8", nonce: "8", blockHash: "0xd067c6af087ca7c83a866182dff57270d3ba821ae259634af3a0919e18f51969", transactionIndex: "127", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2400000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037370000000000000000000000000000000000000000000000000000352e303900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5121126", gasUsed: "88785", confirmations: "2756103"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303900000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037370000000000000000000000000000000000000000000000000000", "0x352e303900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1516837055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[7,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41155"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303900000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[7,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303736000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966817", timeStamp: "1516837055", hash: "0xa19a6027d2cd5b2a829ffc81761ab5d4df03029d44e866846c00fe2d613e4ddb", nonce: "9", blockHash: "0xd067c6af087ca7c83a866182dff57270d3ba821ae259634af3a0919e18f51969", transactionIndex: "128", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2400000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037360000000000000000000000000000000000000000000000000000352e303931000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5209975", gasUsed: "88849", confirmations: "2756103"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303931000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037360000000000000000000000000000000000000000000000000000", "0x352e303931000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1516837055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[8,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41152"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303931000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[8,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303735000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966817", timeStamp: "1516837055", hash: "0x3b39d51d2f064663cae1d94b7592789af1b5903c9d35d1c933a66f83c99d0a64", nonce: "10", blockHash: "0xd067c6af087ca7c83a866182dff57270d3ba821ae259634af3a0919e18f51969", transactionIndex: "129", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2400000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037350000000000000000000000000000000000000000000000000000352e303931000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5298824", gasUsed: "88849", confirmations: "2756103"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037350000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303931000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037350000000000000000000000000000000000000000000000000000", "0x352e303931000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1516837055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[9,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41148"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037350000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303931000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[9,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303736000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966839", timeStamp: "1516837487", hash: "0xfd1447b53c8298807a3bf74c0f70466e64493a17095c09515961cdd9bc26d337", nonce: "11", blockHash: "0xd94270164fe70ba84334aacf2f7164ae32c2a7311ee9c9649a09938fe661e22a", transactionIndex: "72", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037360000000000000000000000000000000000000000000000000000352e303900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2669557", gasUsed: "88785", confirmations: "2756081"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303900000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037360000000000000000000000000000000000000000000000000000", "0x352e303900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1516837487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[10,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41145"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037360000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303900000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[10,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4966957", timeStamp: "1516839091", hash: "0x1a2f26eb64431f4c90d42a0940356bb697a48c3a669093bfc15bba6f41030d2d", nonce: "25", blockHash: "0x58e576750c1942c59ed79ca95e4d61f4b4d8115ecd4adc37454bb47173872d59", transactionIndex: "65", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303835000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2868900", gasUsed: "89156", confirmations: "2755963"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303835000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303835000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1516839091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[11,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "41141"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303835000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[11,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: claimName( `Julien`, \"0x35322e30373733333030363530... )", async function( ) {
		const txOriginal = {blockNumber: "4970105", timeStamp: "1516885210", hash: "0x9921505763a6dcd8e1a53e9c113fd9c017bf2960b12fa037a66659baeb6d7332", nonce: "29", blockHash: "0x04a54b7e8288a9deddc1fa3e99b823f5200b7d11a25a67e4c429e49e863e16f1", transactionIndex: "116", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x0e3d2122000000000000000000000000000000000000000000000000000000000000006035322e3037373333303036353038383835000000000000000000000000000000352e30383933373335383835363230313200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000064a756c69656e0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5804733", gasUsed: "59668", confirmations: "2752815"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "MyName", value: `Julien`}, {type: "bytes32", name: "GPSLatitude", value: "0x35322e3037373333303036353038383835000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303839333733353838353632303132000000000000000000000000000000"}], name: "claimName", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimName(string,bytes32,bytes32)" ]( `Julien`, "0x35322e3037373333303036353038383835000000000000000000000000000000", "0x352e303839333733353838353632303132000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1516885210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "Name", type: "string"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "NameClaimed", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NameClaimed", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "Name", type: "string", value: "Julien"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037373333303036353038383835000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303839333733353838353632303132000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyScavengerHuntTokenWithLocationSharing( \"0x35322e303736393735380000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4971368", timeStamp: "1516904002", hash: "0xc945b57da2c916d9925f8e2d22698bfe3f74f8ee14944eac587a0963d059d02f", nonce: "0", blockHash: "0xa899da3e0f345f4a699442efa442eb07b5c01deee97025afd60d5fcd3a09500d", transactionIndex: "78", from: "0x83d811269fb405a2c91fab2054dfaa39ee02e173", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "100000000000000000", gas: "800000", gasPrice: "5800000000", isError: "0", txreceipt_status: "1", input: "0x669edcdc35322e3037363937353800000000000000000000000000000000000000000000342e383730313431340000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5737271", gasUsed: "67800", confirmations: "2751552"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037363937353800000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x342e383730313431340000000000000000000000000000000000000000000000"}], name: "buyScavengerHuntTokenWithLocationSharing", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyScavengerHuntTokenWithLocationSharing(bytes32,bytes32)" ]( "0x35322e3037363937353800000000000000000000000000000000000000000000", "0x342e383730313431340000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1516904002 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "backer", type: "address"}, {indexed: false, name: "amountEhter", type: "uint256"}, {indexed: false, name: "amountScavengerHuntTokens", type: "uint256"}, {indexed: false, name: "isContribution", type: "bool"}], name: "FundTransfer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "FundTransfer", events: [{name: "backer", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "amountEhter", type: "uint256", value: "100000000000000000"}, {name: "amountScavengerHuntTokens", type: "uint256", value: "10000"}, {name: "isContribution", type: "bool", value: true}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "ShareLocation", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ShareLocation", events: [{name: "owner", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "10000"}, {name: "PercentageOfTotal", type: "uint256", value: "37064"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037363937353800000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x342e383730313431340000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}, {name: "to", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "value", type: "uint256", value: "10000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[13,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2019929800000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303737000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4971389", timeStamp: "1516904347", hash: "0xd5d8b635b24d8914783888b552703081a33c496545463ca3a1a96dda22d2f11a", nonce: "1", blockHash: "0xd01193e9610bd0e66ddeb5f063273724833af3b6935ae6df98d3016b3e83e77d", transactionIndex: "65", from: "0x83d811269fb405a2c91fab2054dfaa39ee02e173", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2900000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3037370000000000000000000000000000000000000000000000000000342e383700000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2565456", gasUsed: "89092", confirmations: "2751531"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x342e383700000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3037370000000000000000000000000000000000000000000000000000", "0x342e383700000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1516904347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[14,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "37062"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037370000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x342e383700000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[14,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2019929800000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4971572", timeStamp: "1516907101", hash: "0x1bdafcf640c16b8ac924efcefe07e58ef35c783c6d6a644866618c55565943f0", nonce: "32", blockHash: "0xf55b0ab00761f7a3786f28f33287cb9ebf018598e5e709c377838dbaae87d76c", transactionIndex: "41", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2600000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e313136000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1974996", gasUsed: "89156", confirmations: "2751348"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e313136000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e313136000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1516907101 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25869"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e313136000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4971575", timeStamp: "1516907152", hash: "0xbe05957ed47f4bdbba77292265ff6a71a80d583c239af84d62230cb502cb292a", nonce: "33", blockHash: "0xdf51a86e7df1e7cdca7ac01bc286e41d8e11457ac114bebe96d00246c3a47ee7", transactionIndex: "109", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2600000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e313132000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4826257", gasUsed: "136379", confirmations: "2751345"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e313132000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e313132000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1516907152 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[16,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "3"}, {name: "PercentageOfTotal", type: "uint256", value: "25874"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e313132000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[16,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}, {name: "to", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "value", type: "uint256", value: "3"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[16,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4971610", timeStamp: "1516907726", hash: "0x1b6037af5343fe56569ade2d3bf06286f1d8ffe2853fc5b44a558d2c0c87c105", nonce: "34", blockHash: "0x2341f2d54c6b3a6c5b3e7dc4caac8dd1bb5313e5fbdd1c41d50f68787f92a79a", transactionIndex: "95", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2600000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e313133000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7109720", gasUsed: "89156", confirmations: "2751310"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e313133000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e313133000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1516907726 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[17,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25871"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e313133000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[17,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: shareScavengerHuntTokenLocation( \"0x35322e303735393938380000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4971685", timeStamp: "1516908799", hash: "0x16fb52598ee49e9be5decd78547227a6ff521ed176494e51861711b6a1bd46c5", nonce: "4", blockHash: "0xff383257ba7a5a0354e2c6297e43211acbad76da159e2ac293b3a328edb83208", transactionIndex: "33", from: "0x83d811269fb405a2c91fab2054dfaa39ee02e173", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2600000000", isError: "0", txreceipt_status: "1", input: "0x1da9a6b235322e3037353939383800000000000000000000000000000000000000000000342e383731313239360000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1131462", gasUsed: "26637", confirmations: "2751235"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3037353939383800000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x342e383731313239360000000000000000000000000000000000000000000000"}], name: "shareScavengerHuntTokenLocation", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "shareScavengerHuntTokenLocation(bytes32,bytes32)" ]( "0x35322e3037353939383800000000000000000000000000000000000000000000", "0x342e383731313239360000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1516908799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "ShareLocation", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ShareLocation", events: [{name: "owner", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "9999"}, {name: "PercentageOfTotal", type: "uint256", value: "37062"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3037353939383800000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x342e383731313239360000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2019929800000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303934000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4972370", timeStamp: "1516918857", hash: "0xfdb13a040b88417af6a65ca5c3986156e7c638bc3bc4d9c9227fe7afe04f5031", nonce: "35", blockHash: "0xfc9941a0b69f5ac765632004651e776105dec5607c3cc334489e04f9db3eda92", transactionIndex: "106", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2200000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039340000000000000000000000000000000000000000000000000000352e303836000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7125359", gasUsed: "89156", confirmations: "2750550"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039340000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303836000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039340000000000000000000000000000000000000000000000000000", "0x352e303836000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1516918857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[19,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25869"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039340000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303836000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[19,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e313235000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4975704", timeStamp: "1516966694", hash: "0x65619bcf268009a82b8419ad2f961885764964aeb2f17dfb01fc4ca2fd51e4b8", nonce: "36", blockHash: "0x20791cf509d909d43aa537868776e25cec158181329c9c1e09ca13e9dac8a2d7", transactionIndex: "98", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3132350000000000000000000000000000000000000000000000000000352e303337000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4843768", gasUsed: "136993", confirmations: "2747216"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3132350000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303337000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3132350000000000000000000000000000000000000000000000000000", "0x352e303337000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1516966694 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[20,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "3"}, {name: "PercentageOfTotal", type: "uint256", value: "25874"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3132350000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303337000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[20,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}, {name: "to", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "value", type: "uint256", value: "3"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[20,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e313831000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977167", timeStamp: "1516987994", hash: "0x577744930c9e9e437cedc89f5960680482e0b415587bb95c526da7ccb32685a8", nonce: "5", blockHash: "0xc8c735369f53665449b4feff59482dc4ddbe55ba286b139d6d4847dcab3df58d", transactionIndex: "95", from: "0x83d811269fb405a2c91fab2054dfaa39ee02e173", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3138310000000000000000000000000000000000000000000000000000342e343735000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7209719", gasUsed: "89463", confirmations: "2745753"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3138310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x342e343735000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3138310000000000000000000000000000000000000000000000000000", "0x342e343735000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1516987994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[21,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "37058"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3138310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x342e343735000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[21,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2019929800000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977365", timeStamp: "1516991153", hash: "0xb03428108335b6c9d875277d8a5a3e5e37b4c8f7143bf1596ed9499a9b565fe6", nonce: "48", blockHash: "0x29ec6b133c34536272af164c357713224c008c69f38c2cf693e0e1916f13f466", transactionIndex: "84", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e303834000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2129474", gasUsed: "89463", confirmations: "2745555"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303834000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e303834000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1516991153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[22,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25872"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303834000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[22,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977375", timeStamp: "1516991305", hash: "0x2dbfdaafcf8de82f3ddd40799c690ff7c8e86cf349ddca6a965835d005603e64", nonce: "49", blockHash: "0x66665ec2a2c632d9cb813bd317588381b4a07ec48ef58961309f6e9db934812f", transactionIndex: "142", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e303833000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4139725", gasUsed: "89463", confirmations: "2745545"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303833000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e303833000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1516991305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[23,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25870"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303833000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[23,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977375", timeStamp: "1516991305", hash: "0xac1f4054f8a9c32c0ecef65a43ab34019d72fabbdbca1615021313752f5a5a58", nonce: "50", blockHash: "0x66665ec2a2c632d9cb813bd317588381b4a07ec48ef58961309f6e9db934812f", transactionIndex: "151", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303833000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4761442", gasUsed: "89463", confirmations: "2745545"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303833000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303833000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1516991305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[24,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25867"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303833000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[24,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977419", timeStamp: "1516991947", hash: "0xc9be8ea9fedf5d75218ebd9b8ecb609b58ac6309cce0c12d8241fe34e4238153", nonce: "51", blockHash: "0x1bf487145b9733ad67dff60fd67e3d88c59a8b62aacd9e48d03d6e10a5d4ec72", transactionIndex: "25", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3333287", gasUsed: "89463", confirmations: "2745501"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1516991947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[25,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25864"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[25,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977423", timeStamp: "1516992008", hash: "0x60a13a47f63cca8717c6af420c84ebbfee98ff449833e341912bd3744f900bee", nonce: "52", blockHash: "0x50dc94e0e2805dafbdc3f8c7a946e25edc211f5663c2d1ad6e274b9c58574453", transactionIndex: "38", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3632341", gasUsed: "23371", confirmations: "2745497"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1516992008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977429", timeStamp: "1516992066", hash: "0x104ab8417a5e052c9b824e36b81b3d31d9313e34861dbf402a685e7d43037fcc", nonce: "53", blockHash: "0x61192ff9af7a5c4e30fbe1289686b8a2c1a09831a9a50cc6132839b11d29944c", transactionIndex: "68", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4318749", gasUsed: "23371", confirmations: "2745491"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1516992066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977432", timeStamp: "1516992091", hash: "0x4be00a6493f9cf3240ede52151d4437aa2dd071c4444db7512d3857fc5b8e95a", nonce: "54", blockHash: "0x71e80d348e68fc05326dcfbc76a62962c9d5fb45ef2c64a18763f7b1c07d837d", transactionIndex: "133", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6133984", gasUsed: "23371", confirmations: "2745488"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1516992091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977432", timeStamp: "1516992091", hash: "0x369a7c169f7c8585088f6303ff74452fecc0db5fa3a0adb7102e9a6843f849b6", nonce: "55", blockHash: "0x71e80d348e68fc05326dcfbc76a62962c9d5fb45ef2c64a18763f7b1c07d837d", transactionIndex: "134", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6157355", gasUsed: "23371", confirmations: "2745488"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1516992091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977432", timeStamp: "1516992091", hash: "0xec8398b4b3a5bc0fcdaff32e47eb9cb0da9aa3c2d726ea0c33503827e3a049f9", nonce: "56", blockHash: "0x71e80d348e68fc05326dcfbc76a62962c9d5fb45ef2c64a18763f7b1c07d837d", transactionIndex: "135", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6180726", gasUsed: "23371", confirmations: "2745488"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1516992091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977432", timeStamp: "1516992091", hash: "0xaff9e56f8d9ee489a0f657ca86c9b89c550af9e4e41111cf9d8528868347fc61", nonce: "57", blockHash: "0x71e80d348e68fc05326dcfbc76a62962c9d5fb45ef2c64a18763f7b1c07d837d", transactionIndex: "136", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6204097", gasUsed: "23371", confirmations: "2745488"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1516992091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977432", timeStamp: "1516992091", hash: "0x1354b347d07761b2f614202dab822b485763f33e0b318bdaac9db8165d6b6757", nonce: "58", blockHash: "0x71e80d348e68fc05326dcfbc76a62962c9d5fb45ef2c64a18763f7b1c07d837d", transactionIndex: "137", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303832000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6227468", gasUsed: "23371", confirmations: "2745488"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303832000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303832000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1516992091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303836000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977481", timeStamp: "1516992868", hash: "0xc7cb9dee5f8552be494883db879997aaca716adeafa7998ea773b3cb3107bf5e", nonce: "6", blockHash: "0x63a44418363e887a14403e5e61c5488223bef6bb254039b2f91a30551b6f12f3", transactionIndex: "78", from: "0x83d811269fb405a2c91fab2054dfaa39ee02e173", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3038360000000000000000000000000000000000000000000000000000342e383733000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7277048", gasUsed: "89463", confirmations: "2745439"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3038360000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x342e383733000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3038360000000000000000000000000000000000000000000000000000", "0x342e383733000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1516992868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0x83d811269fb405a2c91fab2054dfaa39ee02e173"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "37061"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3038360000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x342e383733000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2019929800000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977516", timeStamp: "1516993384", hash: "0xbbf802cd7e7049464cd395635e630df7126c1a0ba495670f60f7e73421d19960", nonce: "59", blockHash: "0xb72df5fbd45b3b1a02c6f59c20f2af830bc4ac23a8ec390fffc87e1340f4514f", transactionIndex: "28", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303836000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6850853", gasUsed: "89463", confirmations: "2745404"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303836000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303836000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1516993384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25862"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303836000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977520", timeStamp: "1516993440", hash: "0x33512ff5480cbec92424fa612991529fcbc7b8956fb9a773a8229252e1c79da0", nonce: "60", blockHash: "0x099fa1251b2e42f6cb8866a5d82dba4271f2d177d47235a790abdb54359d2d89", transactionIndex: "41", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303835000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3760601", gasUsed: "89463", confirmations: "2745400"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303835000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303835000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1516993440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[35,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25860"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303835000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[35,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977523", timeStamp: "1516993503", hash: "0x5b3cd93f63f9f53816d018709598a4d8ea94e063420753da5e52c7a5c23ef594", nonce: "61", blockHash: "0x2d69e503762eb74b86b2110035329e4004690c68a55e9dbe5a1c6d303a89e596", transactionIndex: "0", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303834000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "89463", gasUsed: "89463", confirmations: "2745397"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303834000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303834000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1516993503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[36,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25857"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303834000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[36,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977525", timeStamp: "1516993526", hash: "0xbc2e19be9e194a8300172f4f5433d44b7120b6b6e4132fb99db7ed1cca5f13b1", nonce: "62", blockHash: "0x1c64a650c350fdcb56036bb1c29b7863287158585913aaedbd219fec30d1076f", transactionIndex: "74", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303834000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6605955", gasUsed: "89463", confirmations: "2745395"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303834000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303834000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1516993526 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[37,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25854"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303834000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[37,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303933000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977528", timeStamp: "1516993567", hash: "0x023bc1f1681d3d5a42928af923be99c1067a4882cd401a4b70985b438272e3e8", nonce: "63", blockHash: "0x7297aa5208a09f3f5fd305e2db131c5d194caf68d53114ba463f8b59ebcc00ce", transactionIndex: "60", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039330000000000000000000000000000000000000000000000000000352e303836000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1951214", gasUsed: "121993", confirmations: "2745392"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303836000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039330000000000000000000000000000000000000000000000000000", "0x352e303836000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1516993567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[38,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "3"}, {name: "PercentageOfTotal", type: "uint256", value: "25860"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039330000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303836000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[38,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}, {name: "to", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "value", type: "uint256", value: "3"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[38,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977528", timeStamp: "1516993567", hash: "0xa3554dc9f4ea9e42dd2d296909d02f2dac1d452a4de80fcde832dcfed7e03c64", nonce: "64", blockHash: "0x7297aa5208a09f3f5fd305e2db131c5d194caf68d53114ba463f8b59ebcc00ce", transactionIndex: "121", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e303837000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5032595", gasUsed: "89463", confirmations: "2745392"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303837000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e303837000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1516993567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[39,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25857"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303837000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[39,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977552", timeStamp: "1516994106", hash: "0x1c1f7d6786d068531bc34286fe58c537a2dfc68471af03a4f8f2d9b174ef2993", nonce: "65", blockHash: "0xcde444e2f1d78d9458a8dfda8bc8e863e8515dda92dbc25d12fe510f4336fe40", transactionIndex: "19", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e303838000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1015751", gasUsed: "121844", confirmations: "2745368"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303838000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e303838000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1516994106 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[40,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "50"}, {name: "PercentageOfTotal", type: "uint256", value: "25991"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303838000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[40,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}, {name: "to", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "value", type: "uint256", value: "50"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[40,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977554", timeStamp: "1516994142", hash: "0x6471cd1050de74dc6cc843dcc85c37e11dbf0afe51a78933101985039be5e934", nonce: "66", blockHash: "0x8b901de646eef7ee079890d9b5a4c32c14b36ab38afe82b65199440fa27cf555", transactionIndex: "122", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303839000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6997454", gasUsed: "89463", confirmations: "2745366"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303839000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1516994142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25989"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977558", timeStamp: "1516994208", hash: "0x96e2219d147e8be7d544ea9123f2d9f93dbff57b2c9501947c4670656cc78e9e", nonce: "67", blockHash: "0xb1a58674cc6c1809a3cdbcbc0f9213aec3930420e13dc2119fb45f363b8f3444", transactionIndex: "103", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e303839000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5539023", gasUsed: "89463", confirmations: "2745362"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e303839000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1516994208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25986"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303839000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303932000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977558", timeStamp: "1516994208", hash: "0xd3c1620bba19d4e9f0ba9e90c9f7e6a6bd10ad18d03b69cfaeb4ff7e7db36245", nonce: "68", blockHash: "0xb1a58674cc6c1809a3cdbcbc0f9213aec3930420e13dc2119fb45f363b8f3444", transactionIndex: "130", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039320000000000000000000000000000000000000000000000000000352e303900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7057967", gasUsed: "89399", confirmations: "2745362"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303900000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039320000000000000000000000000000000000000000000000000000", "0x352e303900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1516994208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[43,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25983"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039320000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303900000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[43,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977809", timeStamp: "1516997691", hash: "0xaffc0c55dde748b52e413042612c7e20130aab7f3fd8f35a7cc31de209b1f0ef", nonce: "69", blockHash: "0x187e314524a243bc8996302bf866c66ab13f84a21b3f0e9e05ffcd9c2cbd8b2b", transactionIndex: "63", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303931000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5729865", gasUsed: "89463", confirmations: "2745111"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303931000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303931000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1516997691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[44,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25980"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303931000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[44,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977810", timeStamp: "1516997699", hash: "0xfc3fdb94cfad9f8322536cda0a56c500b1f8f257551380ed19e871c66a5e1c9e", nonce: "70", blockHash: "0x06c7293acf07a42f1fe6d1abbb08e79668b0751cdc52316f8708c5fd50704427", transactionIndex: "98", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303932000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7173622", gasUsed: "89463", confirmations: "2745110"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303932000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303932000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1516997699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[45,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25978"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303932000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[45,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977810", timeStamp: "1516997699", hash: "0xe695497c5e823014d7f5577f7c2eda2f1c4d9bf5b14467e226c725d452d3345e", nonce: "71", blockHash: "0x06c7293acf07a42f1fe6d1abbb08e79668b0751cdc52316f8708c5fd50704427", transactionIndex: "99", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303933000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7263085", gasUsed: "89463", confirmations: "2745110"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303933000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303933000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1516997699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[46,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25975"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303933000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[46,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977812", timeStamp: "1516997729", hash: "0x51bdc2fa81873696629265d3780fcb65121bdce75f3d2ac062f025dfee500bbd", nonce: "72", blockHash: "0x4aec2c5da55011896e6f3a1fd951a0a4b4dbdfbb3f1c3fafd5605ebcf1f70d2e", transactionIndex: "153", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303934000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5188839", gasUsed: "89463", confirmations: "2745108"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303934000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303934000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1516997729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[47,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25972"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303934000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[47,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977821", timeStamp: "1516997822", hash: "0xf67c5719f2a8955d88b91213afdc6cb343005c381fbf54f038a496c56fc66ad8", nonce: "73", blockHash: "0x4dca2659521a308d9986427b6e102993ff44f3cc142970663085da41ca681f67", transactionIndex: "85", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303935000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5252253", gasUsed: "89463", confirmations: "2745099"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303935000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303935000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1516997822 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[48,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25969"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303935000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[48,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: digForTokens( \"0x35322e303931000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4977822", timeStamp: "1516997829", hash: "0x47a6d19ca80b72489eb7fb27ce7e8ff7ddac160c7b25693feda378ae993ddd35", nonce: "74", blockHash: "0x298b520e9cff7943b26a7dc814363ad1fb3943cdf09eaccdaed88dab2aa20dfd", transactionIndex: "122", from: "0xd538a43db3c319356a7561c0f23f0a850d225f21", to: "0x77f07b4831113143c24dd651a682c001d9d7e3b4", value: "0", gas: "800000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3b81e31735322e3039310000000000000000000000000000000000000000000000000000352e303936000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6058618", gasUsed: "89463", confirmations: "2745098"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "GPSLatitude", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "GPSLongitude", value: "0x352e303936000000000000000000000000000000000000000000000000000000"}], name: "digForTokens", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "digForTokens(bytes32,bytes32)" ]( "0x35322e3039310000000000000000000000000000000000000000000000000000", "0x352e303936000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1516997829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ScavengerHuntTokenAmount", type: "uint256"}, {indexed: false, name: "PercentageOfTotal", type: "uint256"}, {indexed: false, name: "GPSLatitude", type: "bytes32"}, {indexed: false, name: "GPSLongitude", type: "bytes32"}], name: "HunterRewarded", type: "event"} ;
		console.error( "eventCallOriginal[49,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "HunterRewarded", events: [{name: "owner", type: "address", value: "0xd538a43db3c319356a7561c0f23f0a850d225f21"}, {name: "ScavengerHuntTokenAmount", type: "uint256", value: "0"}, {name: "PercentageOfTotal", type: "uint256", value: "25967"}, {name: "GPSLatitude", type: "bytes32", value: "0x35322e3039310000000000000000000000000000000000000000000000000000"}, {name: "GPSLongitude", type: "bytes32", value: "0x352e303936000000000000000000000000000000000000000000000000000000"}], address: "0x77f07b4831113143c24dd651a682c001d9d7e3b4"}] ;
		console.error( "eventResultOriginal[49,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "202290504030112102" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "500000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
