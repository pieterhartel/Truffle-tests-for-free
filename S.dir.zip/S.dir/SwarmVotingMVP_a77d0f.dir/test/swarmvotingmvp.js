const SwarmVotingMVP = artifacts.require( "./SwarmVotingMVP.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SwarmVotingMVP" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x2Bb10945E9f0C9483022dc473aB4951BC2a77d0f", "0x8Bf7b2D536D286B9c5Ad9d99F608e9E214DE63f0", "0xE8193Bc3D5F3F482406706F843A5f161563F37Bf", "0x0Db4DC6E5A9039b2b8fCA026963655B04596E903", "0x113Fc47d954420f2e314d260e3f21dab4B548373", "0x06d46AD71509f5db7421C026E1Ba9A974F983Ee1", "0x0778358B4b865cA2c037b27e4584E4178157d6eD", "0x1b47c1d219Ad5033D6a86B83c9D3FA6D589c9797", "0x642A2AEB15d4e1D4657199aF8315199BCD5a4B88", "0xb8EA5cbFE4961A9D5674eeda678271344c03a13e", "0xbc1bcD39952ba9BaA32b7A77a4020590d3a551c5", "0x18cC1BB9853e1348eA8aD4C7868C82beEbFF06d6", "0x4a43f21628558B5e5f3D4e365b44cfBD3F994218", "0x236DDCBEC59DB65e1641c11adAB444bF159Ae3b5", "0xBC081c23b3B8C6CF1464E98EB108c13c6f8cBA1C", "0x1a77fC33279aFF72Ef58E59B83ecF362495E92E6", "0x960b93A57D77BAeFd8188e627394ad314ED0d53f", "0xC6fa742F5A58Cf2Ccf8234a7C13Cf9dCB8515221", "0xA3f59EbC3bf8Fa664Ce12e2f841Fe6556289F053", "0x002B007FF84A726c6D44f036Aaf75B13c0011501", "0x2693da6aB053310f13E248850b44D6840d7Bc94d", "0x44aaAf628363deb4cE340dC5Be0ad68Eee694a28", "0xD2f334CBf3AD1669FB272f17Bc1EB5B89Cc5D878", "0xeFD27BE83fAEBcE3C2A21ee944D0d1271FB24F5f", "0x652146673583C156140674cdfC4f1c873951F808", "0xDE4D5886da98C3A1140260aaF536a2f1262E2948", "0x4feA8B65cCa9C868A40e5b8D48eaB9F3e24F798D", "0x7dF470fACc6Dd63ab28637b476baA6d5a991cbf5", "0xE48F9537f93FeE711537E477619a94ad490DE051", "0x97370C0EB09A6380353ECe0885d23a552E684D52", "0x00208F5e88146CcD9a439e20Af621ea958fF7c1b", "0xc356909ac6DcA18F748c6C9524c0Ccfe520015C4", "0x9b59B887AB5016566Ea0F6DA83f47C5892a758a5", "0x7d69464bC6398D1977A03A9cba8ef76dC653650A", "0x98afc5D79aB11fC822eaf44C4173331482E23c77", "0x739066Ed2D1718FD100CEC4d9F347382Ec6440DC", "0x22105dF9c86d07947fe602bb97968069838127eB", "0x692ca7329615e7d6a3c31371769c897F8bdc223b", "0xEAd71beb50e36e45547B248246365917Cf91fC6A", "0xA72fc2c380f13d4a1Fb7C2F2a876359DC8bbEb9C", "0x382932DF1eD58Cd95e570e530e2DeC5Bd87b6E4B", "0xcAB61B858A344AD4c878c60DE62B2019D3E00Aed", "0x550D286E78DbF0A74B99eA52bFE1703d86f98e1E", "0x9950280174c69BD239f07A03c40bBA9139C3907f", "0x6a7f63709422A986A953904c64F10D945c8AfBA1", "0x364B503B0e86b20B7aC1484c247DE50f10DfD8cf", "0x887dbaCD9a0e58B46065F93cc1f82a52DEfDb979", "0xF66fE29Ad1E87104A8816AD1A8427976d83CB033", "0xe223771699665bCB0AAf7930277C35d3deC573aF", "0xB6dc48E8583C8C6e320DaF918CAdef65f2d85B46", "0xF02d417c8c6736Dbc7Eb089DC6738b950c2F444e"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "nVotesCast", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getBallotOptions", outputs: [{name: "", type: "uint8[2][4]"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "ballotEncryptionPubkey", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ballotEncryptionSeckey", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getEncSeckey", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "voterToBallotID", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getBallotOptNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "bannedAddresses", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "associatedAddresses", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "swarmFundAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getEncPubkey", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "encryptedBallots", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "associatedPubkeys", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "testMode", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "creator", type: "address"}, {indexed: false, name: "start", type: "uint256"}, {indexed: false, name: "end", type: "uint256"}, {indexed: false, name: "encPubkey", type: "bytes32"}], name: "CreatedBallot", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "reason", type: "string"}], name: "FailedVote", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "secretKey", type: "bytes32"}], name: "SeckeyRevealed", type: "event"}, {anonymous: false, inputs: [], name: "TestingEnabled", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "error", type: "string"}], name: "Error", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["CreatedBallot(address,uint256,uint256,bytes32)", "FailedVote(address,string)", "SuccessfulVote(address,bytes32,bytes32)", "SeckeyRevealed(bytes32)", "TestingEnabled()", "Error(string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x39ff8ff9a53b98e7d6173261b48daa7aa8a08963a434c53f78dd7385fda9734c", "0x845381c0eeca7af110d1ca209fa77a339bfa041b54f0ae0659aff6137c952c17", "0x1d69ccdccc669e38a717d9fff71b324d95835c150aa4e2d8900cebd134efff6c", "0xa69839328d982396193483f2260936b1d1f2109fdde204b27c7ac3c1cfd18db0", "0x641e6b9d2f3c463bec5b5cffe3f5017d9a49ad5543d2962eb746c6a7afa223c5", "0x08c379a0afcc32b1a39302f7cb8073359698411ab5fd6e3edb2c02c0b5fba8aa"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4448771 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4485091 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "_startTime", value: "1509372000"}, {type: "uint256", name: "_endTime", value: "1510009200"}, {type: "bytes32", name: "_encPK", value: "0x14108a8f844f506d91daedfd3542425bd5b4e2b1b3e7d959a2344907689dea7e"}, {type: "bool", name: "enableTesting", value: false}], name: "SwarmVotingMVP", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "nVotesCast", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nVotesCast()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBallotOptions", outputs: [{name: "", type: "uint8[2][4]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBallotOptions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ballotEncryptionPubkey", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ballotEncryptionPubkey()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ballotEncryptionSeckey", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ballotEncryptionSeckey()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getEncSeckey", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getEncSeckey()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "voterToBallotID", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "voterToBallotID(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBallotOptNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBallotOptNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "bannedAddresses", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bannedAddresses(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "associatedAddresses", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "associatedAddresses(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "swarmFundAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "swarmFundAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getEncPubkey", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getEncPubkey()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "encryptedBallots", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "encryptedBallots(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "associatedPubkeys", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "associatedPubkeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "testMode", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "testMode()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SwarmVotingMVP", function( accounts ) {

	it( "TEST: SwarmVotingMVP( \"1509372000\", \"1510009200\", \"0x1410... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4448771", timeStamp: "1509239301", hash: "0xe85fad1202ca6ee0e0345e4a260202b5b39f9735750f3d29a9c0a21233182935", nonce: "1", blockHash: "0x90c3052e2317e398aeca32150543f09aee112efc0d721c552b99f202f4600026", transactionIndex: "97", from: "0xe8193bc3d5f3f482406706f843a5f161563f37bf", to: 0, value: "0", gas: "1042166", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x32380db70000000000000000000000000000000000000000000000000000000059f73060000000000000000000000000000000000000000000000000000000005a00e97014108a8f844f506d91daedfd3542425bd5b4e2b1b3e7d959a2344907689dea7e0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", cumulativeGasUsed: "4663021", gasUsed: "842166", confirmations: "3276376"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_startTime", value: "1509372000"}, {type: "uint256", name: "_endTime", value: "1510009200"}, {type: "bytes32", name: "_encPK", value: "0x14108a8f844f506d91daedfd3542425bd5b4e2b1b3e7d959a2344907689dea7e"}, {type: "bool", name: "enableTesting", value: false}], name: "SwarmVotingMVP", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SwarmVotingMVP.new( "1509372000", "1510009200", "0x14108a8f844f506d91daedfd3542425bd5b4e2b1b3e7d959a2344907689dea7e", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509239301 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SwarmVotingMVP.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "815830874962200146" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x0000000000000000496e76616c6964206261... )", async function( ) {
		const txOriginal = {blockNumber: "4454541", timeStamp: "1509320090", hash: "0x5979daecffc44ae38a231d755ff37de5ade5f4f72af2b6bd512287dfe20679e0", nonce: "42", blockHash: "0xcde4d793d26ceead3b4da9dc911cc33ee03d7852c0ef8c6aee23e3d6370cd9f5", transactionIndex: "146", from: "0x0db4dc6e5a9039b2b8fca026963655b04596e903", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "27067", gasPrice: "1500000000", isError: "0", txreceipt_status: "1", input: "0x13c047690000000000000000496e76616c69642062616c6c6f742e2054657374696e672e0000000000000000496e76616c69642062616c6c6f742e2054657374696e672e", contractAddress: "", cumulativeGasUsed: "6633289", gasUsed: "27067", confirmations: "3270606"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x0000000000000000496e76616c69642062616c6c6f742e2054657374696e672e"}, {type: "bytes32", name: "senderPubkey", value: "0x0000000000000000496e76616c69642062616c6c6f742e2054657374696e672e"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x0000000000000000496e76616c69642062616c6c6f742e2054657374696e672e", "0x0000000000000000496e76616c69642062616c6c6f742e2054657374696e672e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509320090 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "error", type: "string"}], name: "Error", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Error", events: [{name: "error", type: "string", value: "Ballot not open"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "690556913028300000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xf39bd476aa51bd8a75ec0054a7b09bb90ffc... )", async function( ) {
		const txOriginal = {blockNumber: "4458998", timeStamp: "1509383359", hash: "0x988f8ef37a4555aeb66deac3233b08eda7881a05c07efe5f396285f1237b0787", nonce: "0", blockHash: "0x5bbeabf5b0e00ee00e9a42bcb7f6b27176a9b7972f130ac989335c9535cb6905", transactionIndex: "27", from: "0x113fc47d954420f2e314d260e3f21dab4b548373", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "171438", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769f39bd476aa51bd8a75ec0054a7b09bb90ffcdfdaadef77b2c43bb2ca573aafdb0d0033282424a5b192971de3b1eead088e27c65f9b96342eabd9e0873dd23651", contractAddress: "", cumulativeGasUsed: "771833", gasUsed: "114292", confirmations: "3266149"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xf39bd476aa51bd8a75ec0054a7b09bb90ffcdfdaadef77b2c43bb2ca573aafdb"}, {type: "bytes32", name: "senderPubkey", value: "0x0d0033282424a5b192971de3b1eead088e27c65f9b96342eabd9e0873dd23651"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xf39bd476aa51bd8a75ec0054a7b09bb90ffcdfdaadef77b2c43bb2ca573aafdb", "0x0d0033282424a5b192971de3b1eead088e27c65f9b96342eabd9e0873dd23651", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509383359 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x113fc47d954420f2e314d260e3f21dab4b548373"}, {name: "ballot", type: "bytes32", value: "0xf39bd476aa51bd8a75ec0054a7b09bb90ffcdfdaadef77b2c43bb2ca573aafdb"}, {name: "pubkey", type: "bytes32", value: "0x0d0033282424a5b192971de3b1eead088e27c65f9b96342eabd9e0873dd23651"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "185975820700000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x90dd787f12ef4655ba5410cbb23d8672d8b0... )", async function( ) {
		const txOriginal = {blockNumber: "4459232", timeStamp: "1509386568", hash: "0x8317ea37533018a8d5427c2def8847ced0ac19ad4ea619750b70521df4527024", nonce: "15", blockHash: "0x69b8a63867f869356e584eefde08e80d502762e070b5c95f1d4e96d49d89d3cb", transactionIndex: "38", from: "0x06d46ad71509f5db7421c026e1ba9a974f983ee1", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476990dd787f12ef4655ba5410cbb23d8672d8b0163ac2cf6550750c0284df0f544385464823886fb2ce8eca0dc75e88f6736c116e2ed1f7ca0ee745512b931a782c", contractAddress: "", cumulativeGasUsed: "1434383", gasUsed: "114420", confirmations: "3265915"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x90dd787f12ef4655ba5410cbb23d8672d8b0163ac2cf6550750c0284df0f5443"}, {type: "bytes32", name: "senderPubkey", value: "0x85464823886fb2ce8eca0dc75e88f6736c116e2ed1f7ca0ee745512b931a782c"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x90dd787f12ef4655ba5410cbb23d8672d8b0163ac2cf6550750c0284df0f5443", "0x85464823886fb2ce8eca0dc75e88f6736c116e2ed1f7ca0ee745512b931a782c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509386568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x06d46ad71509f5db7421c026e1ba9a974f983ee1"}, {name: "ballot", type: "bytes32", value: "0x90dd787f12ef4655ba5410cbb23d8672d8b0163ac2cf6550750c0284df0f5443"}, {name: "pubkey", type: "bytes32", value: "0x85464823886fb2ce8eca0dc75e88f6736c116e2ed1f7ca0ee745512b931a782c"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1644492000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x40782e1ab6ed40bfb52cb23f14cbb79441e7... )", async function( ) {
		const txOriginal = {blockNumber: "4459237", timeStamp: "1509386677", hash: "0xdc55f8d57c91e151dff09142eee0e50f42750491709a67542c9dd3e4570e742a", nonce: "16", blockHash: "0xf56a0e69e2f1be75b85597544e0c49ed50e032c10bf4bade803fa477acfc39b2", transactionIndex: "52", from: "0x0778358b4b865ca2c037b27e4584e4178157d6ed", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "171630", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476940782e1ab6ed40bfb52cb23f14cbb79441e780d1101cb89ed92205fc1183f3df5c5731ad44767d84bcc64e635c62f05d18b94dc5e5e9e8df8c9b92459c949a7d", contractAddress: "", cumulativeGasUsed: "1944331", gasUsed: "114420", confirmations: "3265910"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x40782e1ab6ed40bfb52cb23f14cbb79441e780d1101cb89ed92205fc1183f3df"}, {type: "bytes32", name: "senderPubkey", value: "0x5c5731ad44767d84bcc64e635c62f05d18b94dc5e5e9e8df8c9b92459c949a7d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x40782e1ab6ed40bfb52cb23f14cbb79441e780d1101cb89ed92205fc1183f3df", "0x5c5731ad44767d84bcc64e635c62f05d18b94dc5e5e9e8df8c9b92459c949a7d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509386677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x0778358b4b865ca2c037b27e4584e4178157d6ed"}, {name: "ballot", type: "bytes32", value: "0x40782e1ab6ed40bfb52cb23f14cbb79441e780d1101cb89ed92205fc1183f3df"}, {name: "pubkey", type: "bytes32", value: "0x5c5731ad44767d84bcc64e635c62f05d18b94dc5e5e9e8df8c9b92459c949a7d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "341132050869345339" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x0fd24ab9e27719ed0e2794c8b164fcd9819f... )", async function( ) {
		const txOriginal = {blockNumber: "4459405", timeStamp: "1509388813", hash: "0xb37adec452a4706c81ef7655786a825a27e52e6ccd2fcb66f69538cf31e56c41", nonce: "1", blockHash: "0x40324eb280e519da53c25aad211521eab5c01d69d4db691de41dc5595f6e8882", transactionIndex: "107", from: "0x1b47c1d219ad5033d6a86b83c9d3fa6d589c9797", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "175000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047690fd24ab9e27719ed0e2794c8b164fcd9819f83abaa2fe56d9b7c8cbd12a42a9b37760ad88dba8a3e1017a03efb0275e30e4628ed5b9d8cfb041775c49d12eb1d", contractAddress: "", cumulativeGasUsed: "2999370", gasUsed: "114420", confirmations: "3265742"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x0fd24ab9e27719ed0e2794c8b164fcd9819f83abaa2fe56d9b7c8cbd12a42a9b"}, {type: "bytes32", name: "senderPubkey", value: "0x37760ad88dba8a3e1017a03efb0275e30e4628ed5b9d8cfb041775c49d12eb1d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x0fd24ab9e27719ed0e2794c8b164fcd9819f83abaa2fe56d9b7c8cbd12a42a9b", "0x37760ad88dba8a3e1017a03efb0275e30e4628ed5b9d8cfb041775c49d12eb1d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509388813 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x1b47c1d219ad5033d6a86b83c9d3fa6d589c9797"}, {name: "ballot", type: "bytes32", value: "0x0fd24ab9e27719ed0e2794c8b164fcd9819f83abaa2fe56d9b7c8cbd12a42a9b"}, {name: "pubkey", type: "bytes32", value: "0x37760ad88dba8a3e1017a03efb0275e30e4628ed5b9d8cfb041775c49d12eb1d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "95559392000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x125b8b7c3b9047055e4e30dfa3dd8a817b85... )", async function( ) {
		const txOriginal = {blockNumber: "4459513", timeStamp: "1509390261", hash: "0xc5e64aa9afc83bc231b2b43b848707dd1ce74d9576d4f23bb93c5b847930a48e", nonce: "7", blockHash: "0x6beef46e9d02670cf7dd38105c5d54df4b82d02beaa28cf8a053578de433bcd7", transactionIndex: "38", from: "0x642a2aeb15d4e1d4657199af8315199bcd5a4b88", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cdabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778", contractAddress: "", cumulativeGasUsed: "1426720", gasUsed: "114420", confirmations: "3265634"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cd"}, {type: "bytes32", name: "senderPubkey", value: "0xabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cd", "0xabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509390261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x642a2aeb15d4e1d4657199af8315199bcd5a4b88"}, {name: "ballot", type: "bytes32", value: "0x125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cd"}, {name: "pubkey", type: "bytes32", value: "0xabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "4876702000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x125b8b7c3b9047055e4e30dfa3dd8a817b85... )", async function( ) {
		const txOriginal = {blockNumber: "4459541", timeStamp: "1509390693", hash: "0xa8e61dc83ecf6704fe793776b6cca72c47e2a3b253844c4df6cde438543ed94c", nonce: "2", blockHash: "0x50b24b91fee170932e25cae94081f5127952a8ae95653091cb56ebbac5474455", transactionIndex: "40", from: "0xb8ea5cbfe4961a9d5674eeda678271344c03a13e", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cdabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778", contractAddress: "", cumulativeGasUsed: "1021675", gasUsed: "114420", confirmations: "3265606"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cd"}, {type: "bytes32", name: "senderPubkey", value: "0xabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cd", "0xabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509390693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xb8ea5cbfe4961a9d5674eeda678271344c03a13e"}, {name: "ballot", type: "bytes32", value: "0x125b8b7c3b9047055e4e30dfa3dd8a817b858ff1d10907b2972cc9b1279ae8cd"}, {name: "pubkey", type: "bytes32", value: "0xabd8e4ca35c079f783f35904aa495a253275b3a6524a89af5f88acbea713c778"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "28093418000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xa1e31f959e2814878c3bcc83ed7aa79384fb... )", async function( ) {
		const txOriginal = {blockNumber: "4459571", timeStamp: "1509391039", hash: "0x43f1fa5305075ec53e7883827c2b5a3e766dfba0215989380253f8b994ab874b", nonce: "88", blockHash: "0x2ce05fc9a0de81af02160945d707fc9e0a547f6435aa8862d5942f6b0b6ee279", transactionIndex: "11", from: "0xbc1bcd39952ba9baa32b7a77a4020590d3a551c5", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769a1e31f959e2814878c3bcc83ed7aa79384fb73d9d8886e766326a80d19cda5ccdbcecc3014aad6e53885a10a9d3a637ae1f86a6771bfd6909b120b64ffe29043", contractAddress: "", cumulativeGasUsed: "654274", gasUsed: "114420", confirmations: "3265576"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xa1e31f959e2814878c3bcc83ed7aa79384fb73d9d8886e766326a80d19cda5cc"}, {type: "bytes32", name: "senderPubkey", value: "0xdbcecc3014aad6e53885a10a9d3a637ae1f86a6771bfd6909b120b64ffe29043"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xa1e31f959e2814878c3bcc83ed7aa79384fb73d9d8886e766326a80d19cda5cc", "0xdbcecc3014aad6e53885a10a9d3a637ae1f86a6771bfd6909b120b64ffe29043", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509391039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xbc1bcd39952ba9baa32b7a77a4020590d3a551c5"}, {name: "ballot", type: "bytes32", value: "0xa1e31f959e2814878c3bcc83ed7aa79384fb73d9d8886e766326a80d19cda5cc"}, {name: "pubkey", type: "bytes32", value: "0xdbcecc3014aad6e53885a10a9d3a637ae1f86a6771bfd6909b120b64ffe29043"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "95295998000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x19041274c46c790fb630a644c45d3483668d... )", async function( ) {
		const txOriginal = {blockNumber: "4459670", timeStamp: "1509392498", hash: "0x6535a019373b29d9a4c28b4c0f816b9e2e22fe576b562f6a7e0ff3d2ddf70cf3", nonce: "44", blockHash: "0xce62191757eb3db037896a9716e3edd45bc064a3c1bb15d6d72a72ba91b3bf84", transactionIndex: "74", from: "0x18cc1bb9853e1348ea8ad4c7868c82beebff06d6", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476919041274c46c790fb630a644c45d3483668dd5997eaedff5175baa47b816df88efafbdea0e1ebba50277fc0a748cd2d42807a1769c95b78350e2f4a4868c8457", contractAddress: "", cumulativeGasUsed: "2438142", gasUsed: "114420", confirmations: "3265477"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x19041274c46c790fb630a644c45d3483668dd5997eaedff5175baa47b816df88"}, {type: "bytes32", name: "senderPubkey", value: "0xefafbdea0e1ebba50277fc0a748cd2d42807a1769c95b78350e2f4a4868c8457"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x19041274c46c790fb630a644c45d3483668dd5997eaedff5175baa47b816df88", "0xefafbdea0e1ebba50277fc0a748cd2d42807a1769c95b78350e2f4a4868c8457", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509392498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x18cc1bb9853e1348ea8ad4c7868c82beebff06d6"}, {name: "ballot", type: "bytes32", value: "0x19041274c46c790fb630a644c45d3483668dd5997eaedff5175baa47b816df88"}, {name: "pubkey", type: "bytes32", value: "0xefafbdea0e1ebba50277fc0a748cd2d42807a1769c95b78350e2f4a4868c8457"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "226049105264586600" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x6af69def6a392e9bf2b85fc08469beee7b74... )", async function( ) {
		const txOriginal = {blockNumber: "4459769", timeStamp: "1509393798", hash: "0x937b5cdd026acd6f12b40cec621a4ab252a834d97e97ccc131fcdb6356301a02", nonce: "4", blockHash: "0xf82a25b319f117cfaa8e12b4f8eb0ae5fa73eadc65939efc99324f43dd37bc39", transactionIndex: "24", from: "0x4a43f21628558b5e5f3d4e365b44cfbd3f994218", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047696af69def6a392e9bf2b85fc08469beee7b74e7b315e27e47e336a84bcbbb6f76fea4a0118a9ee902724013d8594d76430a4d9bf1157b19d1b205f4489437360b", contractAddress: "", cumulativeGasUsed: "1038932", gasUsed: "114420", confirmations: "3265378"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x6af69def6a392e9bf2b85fc08469beee7b74e7b315e27e47e336a84bcbbb6f76"}, {type: "bytes32", name: "senderPubkey", value: "0xfea4a0118a9ee902724013d8594d76430a4d9bf1157b19d1b205f4489437360b"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x6af69def6a392e9bf2b85fc08469beee7b74e7b315e27e47e336a84bcbbb6f76", "0xfea4a0118a9ee902724013d8594d76430a4d9bf1157b19d1b205f4489437360b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509393798 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x4a43f21628558b5e5f3d4e365b44cfbd3f994218"}, {name: "ballot", type: "bytes32", value: "0x6af69def6a392e9bf2b85fc08469beee7b74e7b315e27e47e336a84bcbbb6f76"}, {name: "pubkey", type: "bytes32", value: "0xfea4a0118a9ee902724013d8594d76430a4d9bf1157b19d1b205f4489437360b"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "21413688000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xfc938602789d9c9c064092d53c78e965f570... )", async function( ) {
		const txOriginal = {blockNumber: "4459961", timeStamp: "1509396433", hash: "0x7ab4c41e0518dd2a89a1708740c84309195feec847148483825e4fe5ba4d68c1", nonce: "25", blockHash: "0x94da4dad2ffb65e8f4528d0c34ca582abccf876532140416619d66f37325af1d", transactionIndex: "0", from: "0x236ddcbec59db65e1641c11adab444bf159ae3b5", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769fc938602789d9c9c064092d53c78e965f570a4fdffde0c3804d83853ccc4fd39e437c6a87435265ba8ff98c6f54d59e3f1969655dc6f18def32c1c7786f64155", contractAddress: "", cumulativeGasUsed: "114420", gasUsed: "114420", confirmations: "3265186"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xfc938602789d9c9c064092d53c78e965f570a4fdffde0c3804d83853ccc4fd39"}, {type: "bytes32", name: "senderPubkey", value: "0xe437c6a87435265ba8ff98c6f54d59e3f1969655dc6f18def32c1c7786f64155"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xfc938602789d9c9c064092d53c78e965f570a4fdffde0c3804d83853ccc4fd39", "0xe437c6a87435265ba8ff98c6f54d59e3f1969655dc6f18def32c1c7786f64155", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509396433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x236ddcbec59db65e1641c11adab444bf159ae3b5"}, {name: "ballot", type: "bytes32", value: "0xfc938602789d9c9c064092d53c78e965f570a4fdffde0c3804d83853ccc4fd39"}, {name: "pubkey", type: "bytes32", value: "0xe437c6a87435265ba8ff98c6f54d59e3f1969655dc6f18def32c1c7786f64155"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "2204703559131484" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x98d954c6df43edc5ea6d432d47c2add7ff60... )", async function( ) {
		const txOriginal = {blockNumber: "4459977", timeStamp: "1509396655", hash: "0x0e655acc5baf85f8952663aca288eeee1ca9ac217396975202baa236de86bd3a", nonce: "295", blockHash: "0xad8c8ab6330579c9d2c3cd1d5e245ef3fd5b6c9523afb1dcef5841b9b758c1f8", transactionIndex: "77", from: "0xbc081c23b3b8c6cf1464e98eb108c13c6f8cba1c", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "171630", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476998d954c6df43edc5ea6d432d47c2add7ff6051482845cd22fe6d977a723b2db724433fae1eb37d639dbe2c071667092dfb496aac8afbb83d2baa9ebee55d1066", contractAddress: "", cumulativeGasUsed: "3023177", gasUsed: "114420", confirmations: "3265170"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x98d954c6df43edc5ea6d432d47c2add7ff6051482845cd22fe6d977a723b2db7"}, {type: "bytes32", name: "senderPubkey", value: "0x24433fae1eb37d639dbe2c071667092dfb496aac8afbb83d2baa9ebee55d1066"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x98d954c6df43edc5ea6d432d47c2add7ff6051482845cd22fe6d977a723b2db7", "0x24433fae1eb37d639dbe2c071667092dfb496aac8afbb83d2baa9ebee55d1066", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509396655 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xbc081c23b3b8c6cf1464e98eb108c13c6f8cba1c"}, {name: "ballot", type: "bytes32", value: "0x98d954c6df43edc5ea6d432d47c2add7ff6051482845cd22fe6d977a723b2db7"}, {name: "pubkey", type: "bytes32", value: "0x24433fae1eb37d639dbe2c071667092dfb496aac8afbb83d2baa9ebee55d1066"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "44085589192185882" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xda7bdd432e4218b9d4c1f936b657281ead28... )", async function( ) {
		const txOriginal = {blockNumber: "4460084", timeStamp: "1509398222", hash: "0xe142254f378ba54b39a723c902d8088896026b8acdffe33e4f53c966e1797882", nonce: "0", blockHash: "0x285ae820ecb219b4d2e27437cb026914fced9198f6e6bfb1d0ea8ad8776cf516", transactionIndex: "99", from: "0x1a77fc33279aff72ef58e59b83ecf362495e92e6", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "8000000001", isError: "0", txreceipt_status: "1", input: "0x13c04769da7bdd432e4218b9d4c1f936b657281ead282ea858d9b420efa370dd1d433afc03d4d54d7bd5cefd3ed18d06dd0e41adb13a39e4c3baf466b0f03c5b5da5cb6a", contractAddress: "", cumulativeGasUsed: "2929255", gasUsed: "114420", confirmations: "3265063"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xda7bdd432e4218b9d4c1f936b657281ead282ea858d9b420efa370dd1d433afc"}, {type: "bytes32", name: "senderPubkey", value: "0x03d4d54d7bd5cefd3ed18d06dd0e41adb13a39e4c3baf466b0f03c5b5da5cb6a"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xda7bdd432e4218b9d4c1f936b657281ead282ea858d9b420efa370dd1d433afc", "0x03d4d54d7bd5cefd3ed18d06dd0e41adb13a39e4c3baf466b0f03c5b5da5cb6a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509398222 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x1a77fc33279aff72ef58e59b83ecf362495e92e6"}, {name: "ballot", type: "bytes32", value: "0xda7bdd432e4218b9d4c1f936b657281ead282ea858d9b420efa370dd1d433afc"}, {name: "pubkey", type: "bytes32", value: "0x03d4d54d7bd5cefd3ed18d06dd0e41adb13a39e4c3baf466b0f03c5b5da5cb6a"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "12725987310777663357" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x66edbaa0f628bc3f20ac64ff40b88e5e7cb4... )", async function( ) {
		const txOriginal = {blockNumber: "4460265", timeStamp: "1509400862", hash: "0x2424a2b459281e31b75af089631c6d48be3936c52b378665a93e222e389b3ee9", nonce: "12", blockHash: "0xe0a166b996bd5d44fd0242d6eb1c483658ba941e9220c46705ca6ed886b34eb7", transactionIndex: "3", from: "0x960b93a57d77baefd8188e627394ad314ed0d53f", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "180000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476966edbaa0f628bc3f20ac64ff40b88e5e7cb4b1616316d50f35137787b44186a153b2f49d61c8507c5590bc3f91a5ce8d2b040ea43051c4868771b925102f7320", contractAddress: "", cumulativeGasUsed: "667336", gasUsed: "114420", confirmations: "3264882"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x66edbaa0f628bc3f20ac64ff40b88e5e7cb4b1616316d50f35137787b44186a1"}, {type: "bytes32", name: "senderPubkey", value: "0x53b2f49d61c8507c5590bc3f91a5ce8d2b040ea43051c4868771b925102f7320"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x66edbaa0f628bc3f20ac64ff40b88e5e7cb4b1616316d50f35137787b44186a1", "0x53b2f49d61c8507c5590bc3f91a5ce8d2b040ea43051c4868771b925102f7320", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509400862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x960b93a57d77baefd8188e627394ad314ed0d53f"}, {name: "ballot", type: "bytes32", value: "0x66edbaa0f628bc3f20ac64ff40b88e5e7cb4b1616316d50f35137787b44186a1"}, {name: "pubkey", type: "bytes32", value: "0x53b2f49d61c8507c5590bc3f91a5ce8d2b040ea43051c4868771b925102f7320"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "81547454612318449" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x0d3004ab956b2bb86c09c9a3e32977cd09a1... )", async function( ) {
		const txOriginal = {blockNumber: "4460407", timeStamp: "1509402947", hash: "0x64f3af059d5554b8e8feef77278c7205a70ee31cff89f7f384d8b2e709595ef8", nonce: "23", blockHash: "0x39e23a090cde7d8ca8c22a9c983756f3548a5b86f44e13394fc01a6dae957f6e", transactionIndex: "17", from: "0xc6fa742f5a58cf2ccf8234a7c13cf9dcb8515221", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "115000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047690d3004ab956b2bb86c09c9a3e32977cd09a124d1d7312bc63e1dd6b51f96b89290ee24ea3e734807db283da494966745fc21c4b9427113a61a5c96aa2f253c17", contractAddress: "", cumulativeGasUsed: "999624", gasUsed: "114420", confirmations: "3264740"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x0d3004ab956b2bb86c09c9a3e32977cd09a124d1d7312bc63e1dd6b51f96b892"}, {type: "bytes32", name: "senderPubkey", value: "0x90ee24ea3e734807db283da494966745fc21c4b9427113a61a5c96aa2f253c17"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x0d3004ab956b2bb86c09c9a3e32977cd09a124d1d7312bc63e1dd6b51f96b892", "0x90ee24ea3e734807db283da494966745fc21c4b9427113a61a5c96aa2f253c17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509402947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xc6fa742f5a58cf2ccf8234a7c13cf9dcb8515221"}, {name: "ballot", type: "bytes32", value: "0x0d3004ab956b2bb86c09c9a3e32977cd09a124d1d7312bc63e1dd6b51f96b892"}, {name: "pubkey", type: "bytes32", value: "0x90ee24ea3e734807db283da494966745fc21c4b9427113a61a5c96aa2f253c17"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "3737731146972030276" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x0856b741fde2eeb4ed636a004c29fb6517a3... )", async function( ) {
		const txOriginal = {blockNumber: "4460932", timeStamp: "1509410760", hash: "0x071f05c29ad5bfc9127cc6e9ec807bd1e098600c777c075411e655247616136a", nonce: "358", blockHash: "0xd4a7d14ce74f7110e1052e2765451b9eb25f725be0553182e240e0337b9564d5", transactionIndex: "110", from: "0xa3f59ebc3bf8fa664ce12e2f841fe6556289f053", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "137227", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x13c047690856b741fde2eeb4ed636a004c29fb6517a30459b5e260e4821a63ff1ce379035e12a0f941aa0cc03e46a57ae79debecedf2ab353cf0f0ee275a254eeb5dea66", contractAddress: "", cumulativeGasUsed: "6088938", gasUsed: "114356", confirmations: "3264215"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x0856b741fde2eeb4ed636a004c29fb6517a30459b5e260e4821a63ff1ce37903"}, {type: "bytes32", name: "senderPubkey", value: "0x5e12a0f941aa0cc03e46a57ae79debecedf2ab353cf0f0ee275a254eeb5dea66"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x0856b741fde2eeb4ed636a004c29fb6517a30459b5e260e4821a63ff1ce37903", "0x5e12a0f941aa0cc03e46a57ae79debecedf2ab353cf0f0ee275a254eeb5dea66", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509410760 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xa3f59ebc3bf8fa664ce12e2f841fe6556289f053"}, {name: "ballot", type: "bytes32", value: "0x0856b741fde2eeb4ed636a004c29fb6517a30459b5e260e4821a63ff1ce37903"}, {name: "pubkey", type: "bytes32", value: "0x5e12a0f941aa0cc03e46a57ae79debecedf2ab353cf0f0ee275a254eeb5dea66"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "9849790000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x86ec61a6cc4c91820fd1992dfc3319d16880... )", async function( ) {
		const txOriginal = {blockNumber: "4461055", timeStamp: "1509412321", hash: "0xc9646b840539b121acb03354fe5378702d316434a4e6ecff8dc51e6a6ff68a80", nonce: "35", blockHash: "0x979ca906c02675bcd9d02f5f68aa35fea6abed0bece13a676da44ccb6de8c347", transactionIndex: "82", from: "0x002b007ff84a726c6d44f036aaf75b13c0011501", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "137304", gasPrice: "1", isError: "0", txreceipt_status: "1", input: "0x13c0476986ec61a6cc4c91820fd1992dfc3319d1688043a5f4c10805e7a864d4371c99b6c2d0affe8192a57bfa7a42dc50e4a03d634a4db3063a2d51290945eb5d6be14d", contractAddress: "", cumulativeGasUsed: "6065040", gasUsed: "114420", confirmations: "3264092"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x86ec61a6cc4c91820fd1992dfc3319d1688043a5f4c10805e7a864d4371c99b6"}, {type: "bytes32", name: "senderPubkey", value: "0xc2d0affe8192a57bfa7a42dc50e4a03d634a4db3063a2d51290945eb5d6be14d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x86ec61a6cc4c91820fd1992dfc3319d1688043a5f4c10805e7a864d4371c99b6", "0xc2d0affe8192a57bfa7a42dc50e4a03d634a4db3063a2d51290945eb5d6be14d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509412321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x002b007ff84a726c6d44f036aaf75b13c0011501"}, {name: "ballot", type: "bytes32", value: "0x86ec61a6cc4c91820fd1992dfc3319d1688043a5f4c10805e7a864d4371c99b6"}, {name: "pubkey", type: "bytes32", value: "0xc2d0affe8192a57bfa7a42dc50e4a03d634a4db3063a2d51290945eb5d6be14d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x6e284f24044df6f61ce2e07fef196d89c9f1... )", async function( ) {
		const txOriginal = {blockNumber: "4461331", timeStamp: "1509416218", hash: "0x7ab9a47f4c0ae4663d0ab56500c8e7b20c3ecac8ad5756b499a2990e3fbffbdf", nonce: "0", blockHash: "0x10bae9e9537c94f5da2bc9d29668b86748c42bcf282431ecd215143a774771ac", transactionIndex: "52", from: "0x2693da6ab053310f13e248850b44d6840d7bc94d", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047696e284f24044df6f61ce2e07fef196d89c9f1c547461d050da38a3504500fa4f9e6edbcb32aa241f7e2a711818e218d529f2f0dcbe11f0595b58c65fadcab854c", contractAddress: "", cumulativeGasUsed: "2012030", gasUsed: "114420", confirmations: "3263816"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x6e284f24044df6f61ce2e07fef196d89c9f1c547461d050da38a3504500fa4f9"}, {type: "bytes32", name: "senderPubkey", value: "0xe6edbcb32aa241f7e2a711818e218d529f2f0dcbe11f0595b58c65fadcab854c"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x6e284f24044df6f61ce2e07fef196d89c9f1c547461d050da38a3504500fa4f9", "0xe6edbcb32aa241f7e2a711818e218d529f2f0dcbe11f0595b58c65fadcab854c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509416218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x2693da6ab053310f13e248850b44d6840d7bc94d"}, {name: "ballot", type: "bytes32", value: "0x6e284f24044df6f61ce2e07fef196d89c9f1c547461d050da38a3504500fa4f9"}, {name: "pubkey", type: "bytes32", value: "0xe6edbcb32aa241f7e2a711818e218d529f2f0dcbe11f0595b58c65fadcab854c"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "7757180000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xa722f4fba207ab2c820f71943369d090ce73... )", async function( ) {
		const txOriginal = {blockNumber: "4462195", timeStamp: "1509428350", hash: "0x101d98f935ef96753e8f76eaec1df86a0c6e7d45885f11a4ced943f062b6bc55", nonce: "1", blockHash: "0x4bc6e1ee6952ea20aadd43af7c1ca470379597482468468b963ea79e8e30ea9c", transactionIndex: "3", from: "0x44aaaf628363deb4ce340dc5be0ad68eee694a28", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769a722f4fba207ab2c820f71943369d090ce73f9a2c93cff200868dedb1510fedf3c98cced03570aa4d9a64b2a66872206aca5552bfe8e08b924ba547c7b80fe6f", contractAddress: "", cumulativeGasUsed: "177788", gasUsed: "114420", confirmations: "3262952"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xa722f4fba207ab2c820f71943369d090ce73f9a2c93cff200868dedb1510fedf"}, {type: "bytes32", name: "senderPubkey", value: "0x3c98cced03570aa4d9a64b2a66872206aca5552bfe8e08b924ba547c7b80fe6f"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xa722f4fba207ab2c820f71943369d090ce73f9a2c93cff200868dedb1510fedf", "0x3c98cced03570aa4d9a64b2a66872206aca5552bfe8e08b924ba547c7b80fe6f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509428350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x44aaaf628363deb4ce340dc5be0ad68eee694a28"}, {name: "ballot", type: "bytes32", value: "0xa722f4fba207ab2c820f71943369d090ce73f9a2c93cff200868dedb1510fedf"}, {name: "pubkey", type: "bytes32", value: "0x3c98cced03570aa4d9a64b2a66872206aca5552bfe8e08b924ba547c7b80fe6f"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "1286724000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x1513fb27eff9a5905f2905f353db731312be... )", async function( ) {
		const txOriginal = {blockNumber: "4463011", timeStamp: "1509439426", hash: "0xbcf6bc8c9d2d9f585925519593cee1d772df53ef1ef5aca53ebf6a036e11b745", nonce: "0", blockHash: "0xcf6cf5665edf88433f48953c3336f04a6adea76e807be702dc9d4bb6aa7df21e", transactionIndex: "15", from: "0xd2f334cbf3ad1669fb272f17bc1eb5b89cc5d878", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047691513fb27eff9a5905f2905f353db731312be0d56ba89fdf69ddada47dc02fd9a3016ade6b6df110cdf65a68ab1015973a63be217b77d205442c8d022f583845a", contractAddress: "", cumulativeGasUsed: "617000", gasUsed: "114420", confirmations: "3262136"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x1513fb27eff9a5905f2905f353db731312be0d56ba89fdf69ddada47dc02fd9a"}, {type: "bytes32", name: "senderPubkey", value: "0x3016ade6b6df110cdf65a68ab1015973a63be217b77d205442c8d022f583845a"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x1513fb27eff9a5905f2905f353db731312be0d56ba89fdf69ddada47dc02fd9a", "0x3016ade6b6df110cdf65a68ab1015973a63be217b77d205442c8d022f583845a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509439426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xd2f334cbf3ad1669fb272f17bc1eb5b89cc5d878"}, {name: "ballot", type: "bytes32", value: "0x1513fb27eff9a5905f2905f353db731312be0d56ba89fdf69ddada47dc02fd9a"}, {name: "pubkey", type: "bytes32", value: "0x3016ade6b6df110cdf65a68ab1015973a63be217b77d205442c8d022f583845a"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "897597180000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xe53061dada66d42479a5d0de1f4695263148... )", async function( ) {
		const txOriginal = {blockNumber: "4463216", timeStamp: "1509442386", hash: "0xbb45ee60607167ef001f22fe8e2226938a068c47b1eeb800dbc9cac142357c7c", nonce: "2", blockHash: "0x3b24a298a87f3ba76113bcc54bd649d2d5d46908aa68331fbf8a61ab7e7017c9", transactionIndex: "41", from: "0xefd27be83faebce3c2a21ee944d0d1271fb24f5f", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769e53061dada66d42479a5d0de1f4695263148893187b26a2c2b7d7c1c6eef48f4cba45abbcb2fd451d2279f80168fe1570c749b5ae290a7b41bb75023985ceb04", contractAddress: "", cumulativeGasUsed: "1710403", gasUsed: "114420", confirmations: "3261931"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xe53061dada66d42479a5d0de1f4695263148893187b26a2c2b7d7c1c6eef48f4"}, {type: "bytes32", name: "senderPubkey", value: "0xcba45abbcb2fd451d2279f80168fe1570c749b5ae290a7b41bb75023985ceb04"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xe53061dada66d42479a5d0de1f4695263148893187b26a2c2b7d7c1c6eef48f4", "0xcba45abbcb2fd451d2279f80168fe1570c749b5ae290a7b41bb75023985ceb04", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509442386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xefd27be83faebce3c2a21ee944d0d1271fb24f5f"}, {name: "ballot", type: "bytes32", value: "0xe53061dada66d42479a5d0de1f4695263148893187b26a2c2b7d7c1c6eef48f4"}, {name: "pubkey", type: "bytes32", value: "0xcba45abbcb2fd451d2279f80168fe1570c749b5ae290a7b41bb75023985ceb04"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "112606520648680734423" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x1fa69bcd1e7b3eba1c2b3c90fcae4f153b4e... )", async function( ) {
		const txOriginal = {blockNumber: "4463423", timeStamp: "1509445225", hash: "0x6fea9673f0363d507e5decb9711d4ab19c74e0549710b04add979f4e909e626c", nonce: "22", blockHash: "0xf87c3b7c294430108261a27c7f29543c6806aa041adcee3aa1593645a8fd5122", transactionIndex: "42", from: "0x652146673583c156140674cdfc4f1c873951f808", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "9700000000", isError: "0", txreceipt_status: "1", input: "0x13c047691fa69bcd1e7b3eba1c2b3c90fcae4f153b4ed59464cb296033eefcca4c83ca4d086a580505cce9163ffbfd6fc6f12ef9f57463990a370e4226f8f43c30e5424d", contractAddress: "", cumulativeGasUsed: "1686327", gasUsed: "114420", confirmations: "3261724"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x1fa69bcd1e7b3eba1c2b3c90fcae4f153b4ed59464cb296033eefcca4c83ca4d"}, {type: "bytes32", name: "senderPubkey", value: "0x086a580505cce9163ffbfd6fc6f12ef9f57463990a370e4226f8f43c30e5424d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x1fa69bcd1e7b3eba1c2b3c90fcae4f153b4ed59464cb296033eefcca4c83ca4d", "0x086a580505cce9163ffbfd6fc6f12ef9f57463990a370e4226f8f43c30e5424d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509445225 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x652146673583c156140674cdfc4f1c873951f808"}, {name: "ballot", type: "bytes32", value: "0x1fa69bcd1e7b3eba1c2b3c90fcae4f153b4ed59464cb296033eefcca4c83ca4d"}, {name: "pubkey", type: "bytes32", value: "0x086a580505cce9163ffbfd6fc6f12ef9f57463990a370e4226f8f43c30e5424d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "3874128504000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xb3e41bdd17c3eae724e56aa8a6d5c23fcf39... )", async function( ) {
		const txOriginal = {blockNumber: "4468062", timeStamp: "1509509147", hash: "0x71235426d567d6f4a7c9611e56b70628c5ff20f9b1a526c68c9f163928aebe19", nonce: "381", blockHash: "0x107ddcc3fb89343de3ddaf9912509bcd66d692a33ed63541fbed26105da9009b", transactionIndex: "117", from: "0xde4d5886da98c3a1140260aaf536a2f1262e2948", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114356", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769b3e41bdd17c3eae724e56aa8a6d5c23fcf397145f8ad242ce1ef2f46973e781553f71010004cacac0bca42b47825191cd4ce50120831543f4382f6203d8d1644", contractAddress: "", cumulativeGasUsed: "5201089", gasUsed: "114356", confirmations: "3257085"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xb3e41bdd17c3eae724e56aa8a6d5c23fcf397145f8ad242ce1ef2f46973e7815"}, {type: "bytes32", name: "senderPubkey", value: "0x53f71010004cacac0bca42b47825191cd4ce50120831543f4382f6203d8d1644"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xb3e41bdd17c3eae724e56aa8a6d5c23fcf397145f8ad242ce1ef2f46973e7815", "0x53f71010004cacac0bca42b47825191cd4ce50120831543f4382f6203d8d1644", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509509147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xde4d5886da98c3a1140260aaf536a2f1262e2948"}, {name: "ballot", type: "bytes32", value: "0xb3e41bdd17c3eae724e56aa8a6d5c23fcf397145f8ad242ce1ef2f46973e7815"}, {name: "pubkey", type: "bytes32", value: "0x53f71010004cacac0bca42b47825191cd4ce50120831543f4382f6203d8d1644"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "27130728000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xe77a8dfc608c6985ee5a6b85727f67b2f9de... )", async function( ) {
		const txOriginal = {blockNumber: "4469352", timeStamp: "1509526976", hash: "0x035524fdf7c4ab4e27f63a3431375a21e6429f9ba4d30c916a819cedc2b71fb6", nonce: "4", blockHash: "0x2a974175423f95ecdccbd5221f3e226a3f10c627d15f1fb9ab0c0fb6ce651240", transactionIndex: "37", from: "0x4fea8b65cca9c868a40e5b8d48eab9f3e24f798d", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "115000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769e77a8dfc608c6985ee5a6b85727f67b2f9de99481ed274260588302de506aa8e5f176840ba678764cfadaacfa6b823017f975ef45a703c5f43b0987d89837123", contractAddress: "", cumulativeGasUsed: "1652551", gasUsed: "114420", confirmations: "3255795"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xe77a8dfc608c6985ee5a6b85727f67b2f9de99481ed274260588302de506aa8e"}, {type: "bytes32", name: "senderPubkey", value: "0x5f176840ba678764cfadaacfa6b823017f975ef45a703c5f43b0987d89837123"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xe77a8dfc608c6985ee5a6b85727f67b2f9de99481ed274260588302de506aa8e", "0x5f176840ba678764cfadaacfa6b823017f975ef45a703c5f43b0987d89837123", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509526976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x4fea8b65cca9c868a40e5b8d48eab9f3e24f798d"}, {name: "ballot", type: "bytes32", value: "0xe77a8dfc608c6985ee5a6b85727f67b2f9de99481ed274260588302de506aa8e"}, {name: "pubkey", type: "bytes32", value: "0x5f176840ba678764cfadaacfa6b823017f975ef45a703c5f43b0987d89837123"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "22271100747070689699" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x0f553bde91837933babfaf5e31019ffd2d13... )", async function( ) {
		const txOriginal = {blockNumber: "4470357", timeStamp: "1509541187", hash: "0x4fe4a44e5453f0f99694ce5a741628de4f99b9434c6d96c4836c00fb742d0152", nonce: "8", blockHash: "0x858d04d993e9a0ea6ec9885569356a3df495f12886151687774bb6ad8d703bde", transactionIndex: "9", from: "0x7df470facc6dd63ab28637b476baa6d5a991cbf5", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114356", gasPrice: "26000000000", isError: "0", txreceipt_status: "1", input: "0x13c047690f553bde91837933babfaf5e31019ffd2d136f1c1ca3f8cc906d41cb4657b359086c2f5014bfb3761060000395a647182978b09f473a91b6b4c124fc742a815d", contractAddress: "", cumulativeGasUsed: "649303", gasUsed: "114356", confirmations: "3254790"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x0f553bde91837933babfaf5e31019ffd2d136f1c1ca3f8cc906d41cb4657b359"}, {type: "bytes32", name: "senderPubkey", value: "0x086c2f5014bfb3761060000395a647182978b09f473a91b6b4c124fc742a815d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x0f553bde91837933babfaf5e31019ffd2d136f1c1ca3f8cc906d41cb4657b359", "0x086c2f5014bfb3761060000395a647182978b09f473a91b6b4c124fc742a815d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509541187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x7df470facc6dd63ab28637b476baa6d5a991cbf5"}, {name: "ballot", type: "bytes32", value: "0x0f553bde91837933babfaf5e31019ffd2d136f1c1ca3f8cc906d41cb4657b359"}, {name: "pubkey", type: "bytes32", value: "0x086c2f5014bfb3761060000395a647182978b09f473a91b6b4c124fc742a815d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "37496328000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x1a5eb3dff8addb187a9bf60283b126c8aec7... )", async function( ) {
		const txOriginal = {blockNumber: "4470491", timeStamp: "1509542969", hash: "0x3f5ce664f802c8c311ca14e32c1e6e58cd4bf44027df93e19c8875247df98b9f", nonce: "0", blockHash: "0xdfa85ccfc81226b4da84eaba41a0da05b931bb4d53e0e2cc742806501c9252ab", transactionIndex: "20", from: "0xe48f9537f93fee711537e477619a94ad490de051", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047691a5eb3dff8addb187a9bf60283b126c8aec7a90edf6eded87b1040a5d3cdf472adbe8157d1a0dda535b85c009e44d99f5516ba656df5575d339d97a9b4c7e179", contractAddress: "", cumulativeGasUsed: "793065", gasUsed: "114356", confirmations: "3254656"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x1a5eb3dff8addb187a9bf60283b126c8aec7a90edf6eded87b1040a5d3cdf472"}, {type: "bytes32", name: "senderPubkey", value: "0xadbe8157d1a0dda535b85c009e44d99f5516ba656df5575d339d97a9b4c7e179"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x1a5eb3dff8addb187a9bf60283b126c8aec7a90edf6eded87b1040a5d3cdf472", "0xadbe8157d1a0dda535b85c009e44d99f5516ba656df5575d339d97a9b4c7e179", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509542969 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xe48f9537f93fee711537e477619a94ad490de051"}, {name: "ballot", type: "bytes32", value: "0x1a5eb3dff8addb187a9bf60283b126c8aec7a90edf6eded87b1040a5d3cdf472"}, {name: "pubkey", type: "bytes32", value: "0xadbe8157d1a0dda535b85c009e44d99f5516ba656df5575d339d97a9b4c7e179"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "15650434014726501854" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xd469b193e534ca097fa13159c0db3a3e3a2c... )", async function( ) {
		const txOriginal = {blockNumber: "4470820", timeStamp: "1509547767", hash: "0x2c4e1da9ea6e43507bf8bbd4e14d7352cb66f64138e47ab73ff1ad6dff142162", nonce: "4", blockHash: "0x96a34859bdfa53f0d96b20343d6abb7f7f3f9ebcb93a3225d6f71e721adeb415", transactionIndex: "54", from: "0x97370c0eb09a6380353ece0885d23a552e684d52", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "125624", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769d469b193e534ca097fa13159c0db3a3e3a2c7d2d8be2e6765d080f9aac322123c5c494ab50f45491c7fe5e20cad24326384c5430e59982e9f3294c346c90f37b", contractAddress: "", cumulativeGasUsed: "1883780", gasUsed: "114420", confirmations: "3254327"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xd469b193e534ca097fa13159c0db3a3e3a2c7d2d8be2e6765d080f9aac322123"}, {type: "bytes32", name: "senderPubkey", value: "0xc5c494ab50f45491c7fe5e20cad24326384c5430e59982e9f3294c346c90f37b"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xd469b193e534ca097fa13159c0db3a3e3a2c7d2d8be2e6765d080f9aac322123", "0xc5c494ab50f45491c7fe5e20cad24326384c5430e59982e9f3294c346c90f37b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509547767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x97370c0eb09a6380353ece0885d23a552e684d52"}, {name: "ballot", type: "bytes32", value: "0xd469b193e534ca097fa13159c0db3a3e3a2c7d2d8be2e6765d080f9aac322123"}, {name: "pubkey", type: "bytes32", value: "0xc5c494ab50f45491c7fe5e20cad24326384c5430e59982e9f3294c346c90f37b"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "4991064560000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xf313629c87764c6a5a070ed062a6244d8e75... )", async function( ) {
		const txOriginal = {blockNumber: "4471045", timeStamp: "1509550943", hash: "0x7ea63346ad20ff8186fa4f0ac2944a3cb6306c1ae5aa1c6277d9770d85eadc9b", nonce: "0", blockHash: "0xf0015e7d29af5d6cb388a8e930d7fa576a77092b0c735baa0721c3c934fb63ee", transactionIndex: "5", from: "0x00208f5e88146ccd9a439e20af621ea958ff7c1b", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "214420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769f313629c87764c6a5a070ed062a6244d8e756e800fa6f779106723f875efb72f04c93686617c4a689384a2d65f1cfa21958bb2bfa9531249832d4a93c9738708", contractAddress: "", cumulativeGasUsed: "343455", gasUsed: "114420", confirmations: "3254102"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xf313629c87764c6a5a070ed062a6244d8e756e800fa6f779106723f875efb72f"}, {type: "bytes32", name: "senderPubkey", value: "0x04c93686617c4a689384a2d65f1cfa21958bb2bfa9531249832d4a93c9738708"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xf313629c87764c6a5a070ed062a6244d8e756e800fa6f779106723f875efb72f", "0x04c93686617c4a689384a2d65f1cfa21958bb2bfa9531249832d4a93c9738708", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509550943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x00208f5e88146ccd9a439e20af621ea958ff7c1b"}, {name: "ballot", type: "bytes32", value: "0xf313629c87764c6a5a070ed062a6244d8e756e800fa6f779106723f875efb72f"}, {name: "pubkey", type: "bytes32", value: "0x04c93686617c4a689384a2d65f1cfa21958bb2bfa9531249832d4a93c9738708"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "90916052000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x8b9303eaa13781ecafc446a993f301618148... )", async function( ) {
		const txOriginal = {blockNumber: "4471097", timeStamp: "1509551715", hash: "0x932b5532328b65778d0b7dc5fef491b86c7467c61a13371cc732a6c125010df9", nonce: "3", blockHash: "0xc46623d550e95e95f73812a9e60fcbc60965e256a3b797e368e55e6d271cfe5e", transactionIndex: "19", from: "0xc356909ac6dca18f748c6c9524c0ccfe520015c4", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047698b9303eaa13781ecafc446a993f301618148b87d51be8a70e6fabd3321f35973b4b6938220a9501ded0749d3150aead79ff6a171a107174fdd0080add7338c23", contractAddress: "", cumulativeGasUsed: "1043407", gasUsed: "114356", confirmations: "3254050"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x8b9303eaa13781ecafc446a993f301618148b87d51be8a70e6fabd3321f35973"}, {type: "bytes32", name: "senderPubkey", value: "0xb4b6938220a9501ded0749d3150aead79ff6a171a107174fdd0080add7338c23"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x8b9303eaa13781ecafc446a993f301618148b87d51be8a70e6fabd3321f35973", "0xb4b6938220a9501ded0749d3150aead79ff6a171a107174fdd0080add7338c23", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509551715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xc356909ac6dca18f748c6c9524c0ccfe520015c4"}, {name: "ballot", type: "bytes32", value: "0x8b9303eaa13781ecafc446a993f301618148b87d51be8a70e6fabd3321f35973"}, {name: "pubkey", type: "bytes32", value: "0xb4b6938220a9501ded0749d3150aead79ff6a171a107174fdd0080add7338c23"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "147000000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x8cec94be8adcbca2cbe2301a169e1078925c... )", async function( ) {
		const txOriginal = {blockNumber: "4472093", timeStamp: "1509566010", hash: "0x49004a247e628b2258f477ec09388118551c23af7c95ac7680a4162cf99ecfc6", nonce: "3", blockHash: "0x9598967d4759594abadaa51f5ab7bf834fdc7e9b0cc963f42c05c97340652b55", transactionIndex: "41", from: "0x9b59b887ab5016566ea0f6da83f47c5892a758a5", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047698cec94be8adcbca2cbe2301a169e1078925ca4f082f688f4335d48887f871457c5ea80f24683d40252fa9d11131a11ed3e998a18bf050bb39b3c869818239c07", contractAddress: "", cumulativeGasUsed: "1959960", gasUsed: "114420", confirmations: "3253054"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x8cec94be8adcbca2cbe2301a169e1078925ca4f082f688f4335d48887f871457"}, {type: "bytes32", name: "senderPubkey", value: "0xc5ea80f24683d40252fa9d11131a11ed3e998a18bf050bb39b3c869818239c07"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x8cec94be8adcbca2cbe2301a169e1078925ca4f082f688f4335d48887f871457", "0xc5ea80f24683d40252fa9d11131a11ed3e998a18bf050bb39b3c869818239c07", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509566010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x9b59b887ab5016566ea0f6da83f47c5892a758a5"}, {name: "ballot", type: "bytes32", value: "0x8cec94be8adcbca2cbe2301a169e1078925ca4f082f688f4335d48887f871457"}, {name: "pubkey", type: "bytes32", value: "0xc5ea80f24683d40252fa9d11131a11ed3e998a18bf050bb39b3c869818239c07"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "484881322489077336" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xe8ce3da6bd6242534a7555d1e83b618089a6... )", async function( ) {
		const txOriginal = {blockNumber: "4473014", timeStamp: "1509578826", hash: "0x98289c7d6d03c5c44280c55bd93aa8c7575fe30eb4a81b3541b3758fb5f08b03", nonce: "22", blockHash: "0xd7b9af485396e3177c89b5944ca93567cb42a81ee7082549d5384752589f1319", transactionIndex: "11", from: "0x7d69464bc6398d1977a03a9cba8ef76dc653650a", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769e8ce3da6bd6242534a7555d1e83b618089a6bf05a59deda0e4e801ba99e7d6ad8b705562651c46430a2318df3b1d08292831d82eccb8bf9be0add45d55b2150d", contractAddress: "", cumulativeGasUsed: "733707", gasUsed: "114420", confirmations: "3252133"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xe8ce3da6bd6242534a7555d1e83b618089a6bf05a59deda0e4e801ba99e7d6ad"}, {type: "bytes32", name: "senderPubkey", value: "0x8b705562651c46430a2318df3b1d08292831d82eccb8bf9be0add45d55b2150d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xe8ce3da6bd6242534a7555d1e83b618089a6bf05a59deda0e4e801ba99e7d6ad", "0x8b705562651c46430a2318df3b1d08292831d82eccb8bf9be0add45d55b2150d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509578826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x7d69464bc6398d1977a03a9cba8ef76dc653650a"}, {name: "ballot", type: "bytes32", value: "0xe8ce3da6bd6242534a7555d1e83b618089a6bf05a59deda0e4e801ba99e7d6ad"}, {name: "pubkey", type: "bytes32", value: "0x8b705562651c46430a2318df3b1d08292831d82eccb8bf9be0add45d55b2150d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "452599130000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x3bc81d0c3b496979ee17ce1487708e3c0176... )", async function( ) {
		const txOriginal = {blockNumber: "4476296", timeStamp: "1509625137", hash: "0x5327d66b143dbfec4a4262aa5bc9171499fe7d3b5f44418803ab36e64906df5d", nonce: "4", blockHash: "0x5a69c9625db67480c87d3a057500a9d50036a82adbb94105b1d07c84210d285a", transactionIndex: "40", from: "0x98afc5d79ab11fc822eaf44c4173331482e23c77", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047693bc81d0c3b496979ee17ce1487708e3c017636c910d30b930b4faa0470ca605e5b4b7f665fab8f6c039cdae085f470997e4f38f056a0152ee18995adabec5a1a", contractAddress: "", cumulativeGasUsed: "1560427", gasUsed: "114420", confirmations: "3248851"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x3bc81d0c3b496979ee17ce1487708e3c017636c910d30b930b4faa0470ca605e"}, {type: "bytes32", name: "senderPubkey", value: "0x5b4b7f665fab8f6c039cdae085f470997e4f38f056a0152ee18995adabec5a1a"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x3bc81d0c3b496979ee17ce1487708e3c017636c910d30b930b4faa0470ca605e", "0x5b4b7f665fab8f6c039cdae085f470997e4f38f056a0152ee18995adabec5a1a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509625137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x98afc5d79ab11fc822eaf44c4173331482e23c77"}, {name: "ballot", type: "bytes32", value: "0x3bc81d0c3b496979ee17ce1487708e3c017636c910d30b930b4faa0470ca605e"}, {name: "pubkey", type: "bytes32", value: "0x5b4b7f665fab8f6c039cdae085f470997e4f38f056a0152ee18995adabec5a1a"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "16150254000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x1fb37dc0c54d37930f7e3ff736e086c3b5e6... )", async function( ) {
		const txOriginal = {blockNumber: "4477578", timeStamp: "1509643194", hash: "0x66ce8dd944f5efb23f058ddbd01e4fe6e41e1e2af659f40cfd76e5d2793deac9", nonce: "179", blockHash: "0xa0f0b76c0cb8ac9d2b706a432b78225b3ef42a36503970f3a9631d1cd7eda9ee", transactionIndex: "36", from: "0x739066ed2d1718fd100cec4d9f347382ec6440dc", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "171630", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x13c047691fb37dc0c54d37930f7e3ff736e086c3b5e6393f7ad0e5c894617f71330edfb8da954e8b83efddeb20e313f2fcd580a1a045d92c6ed971f6dfdba0316ccac97c", contractAddress: "", cumulativeGasUsed: "1294340", gasUsed: "114420", confirmations: "3247569"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x1fb37dc0c54d37930f7e3ff736e086c3b5e6393f7ad0e5c894617f71330edfb8"}, {type: "bytes32", name: "senderPubkey", value: "0xda954e8b83efddeb20e313f2fcd580a1a045d92c6ed971f6dfdba0316ccac97c"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x1fb37dc0c54d37930f7e3ff736e086c3b5e6393f7ad0e5c894617f71330edfb8", "0xda954e8b83efddeb20e313f2fcd580a1a045d92c6ed971f6dfdba0316ccac97c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509643194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x739066ed2d1718fd100cec4d9f347382ec6440dc"}, {name: "ballot", type: "bytes32", value: "0x1fb37dc0c54d37930f7e3ff736e086c3b5e6393f7ad0e5c894617f71330edfb8"}, {name: "pubkey", type: "bytes32", value: "0xda954e8b83efddeb20e313f2fcd580a1a045d92c6ed971f6dfdba0316ccac97c"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "150033898400456533725" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x8481ecebb36b1ce7a81a5ce54e80095ee948... )", async function( ) {
		const txOriginal = {blockNumber: "4479474", timeStamp: "1509669882", hash: "0xe9899677381b91e8507a89d8a7a09a6fede40fb55d5be943753e0c58bf02afc1", nonce: "4", blockHash: "0xf0ae364370b00033c7a934aa6346369226988855d6685e54ac2f94e9c486e46e", transactionIndex: "3", from: "0x22105df9c86d07947fe602bb97968069838127eb", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047698481ecebb36b1ce7a81a5ce54e80095ee9488ad29f009a512d3773e616ff886147a1550c8f8247fa92911069cf886f8217abb6ccdbacfcfd0b917d4eccbeed7d", contractAddress: "", cumulativeGasUsed: "469354", gasUsed: "114356", confirmations: "3245673"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x8481ecebb36b1ce7a81a5ce54e80095ee9488ad29f009a512d3773e616ff8861"}, {type: "bytes32", name: "senderPubkey", value: "0x47a1550c8f8247fa92911069cf886f8217abb6ccdbacfcfd0b917d4eccbeed7d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x8481ecebb36b1ce7a81a5ce54e80095ee9488ad29f009a512d3773e616ff8861", "0x47a1550c8f8247fa92911069cf886f8217abb6ccdbacfcfd0b917d4eccbeed7d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509669882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x22105df9c86d07947fe602bb97968069838127eb"}, {name: "ballot", type: "bytes32", value: "0x8481ecebb36b1ce7a81a5ce54e80095ee9488ad29f009a512d3773e616ff8861"}, {name: "pubkey", type: "bytes32", value: "0x47a1550c8f8247fa92911069cf886f8217abb6ccdbacfcfd0b917d4eccbeed7d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "1091003911777777777" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xc8fe2f7c1913348ff26f97fdb91bcb99927f... )", async function( ) {
		const txOriginal = {blockNumber: "4480944", timeStamp: "1509690485", hash: "0xe45ea9b71790ca4160b8f6fc5875ce276ea81a6bf3433b357800c27a3ac450cd", nonce: "38", blockHash: "0x559529ac64d1c96be93d35dc3e5ba07dafc20243650e110d42d3a575d3c3f73f", transactionIndex: "12", from: "0x692ca7329615e7d6a3c31371769c897f8bdc223b", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769c8fe2f7c1913348ff26f97fdb91bcb99927fbf3e540ee85473de4e3ed5c5bf96bb0c8c7d50742a0d50f4dc9e404d78add4e03c820d85d3f24cdf13f77f008a34", contractAddress: "", cumulativeGasUsed: "559775", gasUsed: "114356", confirmations: "3244203"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xc8fe2f7c1913348ff26f97fdb91bcb99927fbf3e540ee85473de4e3ed5c5bf96"}, {type: "bytes32", name: "senderPubkey", value: "0xbb0c8c7d50742a0d50f4dc9e404d78add4e03c820d85d3f24cdf13f77f008a34"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xc8fe2f7c1913348ff26f97fdb91bcb99927fbf3e540ee85473de4e3ed5c5bf96", "0xbb0c8c7d50742a0d50f4dc9e404d78add4e03c820d85d3f24cdf13f77f008a34", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509690485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x692ca7329615e7d6a3c31371769c897f8bdc223b"}, {name: "ballot", type: "bytes32", value: "0xc8fe2f7c1913348ff26f97fdb91bcb99927fbf3e540ee85473de4e3ed5c5bf96"}, {name: "pubkey", type: "bytes32", value: "0xbb0c8c7d50742a0d50f4dc9e404d78add4e03c820d85d3f24cdf13f77f008a34"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "3002042159840147" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x741f06b8da6f232a85e5e3d4ab2d9cad2d02... )", async function( ) {
		const txOriginal = {blockNumber: "4482099", timeStamp: "1509706573", hash: "0x36f34766d2407de5c58392ebe2bfff1a78d1189829f95ffc251d91cf03e3ff69", nonce: "218", blockHash: "0xd83c447cbd5ae3de71c06305a0205dc031e0e21a42eccb06366d14dd01ba51e1", transactionIndex: "0", from: "0xead71beb50e36e45547b248246365917cf91fc6a", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114356", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d", contractAddress: "", cumulativeGasUsed: "114356", gasUsed: "114356", confirmations: "3243048"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d"}, {type: "bytes32", name: "senderPubkey", value: "0x252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d", "0x252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509706573 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xead71beb50e36e45547b248246365917cf91fc6a"}, {name: "ballot", type: "bytes32", value: "0x741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d"}, {name: "pubkey", type: "bytes32", value: "0x252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "208077102500587814" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x741f06b8da6f232a85e5e3d4ab2d9cad2d02... )", async function( ) {
		const txOriginal = {blockNumber: "4482107", timeStamp: "1509706737", hash: "0xd8c48064c492630a7a9d6e0dd692280ffec01fb0041edf4856555714da24cfeb", nonce: "219", blockHash: "0x85049711c9dad8cccf2be207909c8091b533090e70cbba2c1f378e20e07b5a5d", transactionIndex: "2", from: "0xead71beb50e36e45547b248246365917cf91fc6a", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "134356", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d", contractAddress: "", cumulativeGasUsed: "141356", gasUsed: "99356", confirmations: "3243040"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d"}, {type: "bytes32", name: "senderPubkey", value: "0x252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d", "0x252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509706737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xead71beb50e36e45547b248246365917cf91fc6a"}, {name: "ballot", type: "bytes32", value: "0x741f06b8da6f232a85e5e3d4ab2d9cad2d02e878f24d690b878ef5be5581899d"}, {name: "pubkey", type: "bytes32", value: "0x252eb825000dedf055c39aa524744067dc4d94c47e19b9d293769a198cf1e20d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "208077102500587814" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x2e671b5d91d23b5ffd7154ffb77137ed894a... )", async function( ) {
		const txOriginal = {blockNumber: "4482880", timeStamp: "1509717397", hash: "0xf22e7fef109912a510e0808bf3d64f03dcc1421b90cb7e5a5cc4dfa8a668a9ce", nonce: "0", blockHash: "0x9eaa33b676478569140fb22aff01c3db0796235a01762f232f3aab84f868b2eb", transactionIndex: "5", from: "0xa72fc2c380f13d4a1fb7c2f2a876359dc8bbeb9c", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047692e671b5d91d23b5ffd7154ffb77137ed894aaf6e63ef67661d3817d6a7e2bccb02fd7d1755fc936107719ee14ec3a8abc654565d969425dcaf80921728e08312", contractAddress: "", cumulativeGasUsed: "340236", gasUsed: "114420", confirmations: "3242267"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x2e671b5d91d23b5ffd7154ffb77137ed894aaf6e63ef67661d3817d6a7e2bccb"}, {type: "bytes32", name: "senderPubkey", value: "0x02fd7d1755fc936107719ee14ec3a8abc654565d969425dcaf80921728e08312"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x2e671b5d91d23b5ffd7154ffb77137ed894aaf6e63ef67661d3817d6a7e2bccb", "0x02fd7d1755fc936107719ee14ec3a8abc654565d969425dcaf80921728e08312", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509717397 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xa72fc2c380f13d4a1fb7c2f2a876359dc8bbeb9c"}, {name: "ballot", type: "bytes32", value: "0x2e671b5d91d23b5ffd7154ffb77137ed894aaf6e63ef67661d3817d6a7e2bccb"}, {name: "pubkey", type: "bytes32", value: "0x02fd7d1755fc936107719ee14ec3a8abc654565d969425dcaf80921728e08312"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "14368686000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x135b70bd4726414dfa816850ac67e0f80c01... )", async function( ) {
		const txOriginal = {blockNumber: "4484107", timeStamp: "1509734414", hash: "0x0bdc778d96df4bc09177778e441b86bbbf7056e216966fae9e42e829facc274a", nonce: "10", blockHash: "0x206171a02917bfb32f7ce44e728416b5ebdd95337ba9cd8c9474e3ec3866cc73", transactionIndex: "31", from: "0x382932df1ed58cd95e570e530e2dec5bd87b6e4b", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769135b70bd4726414dfa816850ac67e0f80c01e9e37aad8cedc8a5f0d1349af4819b62107435c83d22129201f35b5f684ae2f3845545640b222b89eabae188680d", contractAddress: "", cumulativeGasUsed: "888684", gasUsed: "114420", confirmations: "3241040"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x135b70bd4726414dfa816850ac67e0f80c01e9e37aad8cedc8a5f0d1349af481"}, {type: "bytes32", name: "senderPubkey", value: "0x9b62107435c83d22129201f35b5f684ae2f3845545640b222b89eabae188680d"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x135b70bd4726414dfa816850ac67e0f80c01e9e37aad8cedc8a5f0d1349af481", "0x9b62107435c83d22129201f35b5f684ae2f3845545640b222b89eabae188680d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509734414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x382932df1ed58cd95e570e530e2dec5bd87b6e4b"}, {name: "ballot", type: "bytes32", value: "0x135b70bd4726414dfa816850ac67e0f80c01e9e37aad8cedc8a5f0d1349af481"}, {name: "pubkey", type: "bytes32", value: "0x9b62107435c83d22129201f35b5f684ae2f3845545640b222b89eabae188680d"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "173308019811874000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x11faf80ab495d33b7d30604223c60b9ad52c... )", async function( ) {
		const txOriginal = {blockNumber: "4484214", timeStamp: "1509736005", hash: "0xbf18e8073ed4721721175a286892b750b54e6ba70beb10c1a37dc6005dd7ff5b", nonce: "60", blockHash: "0xe67bc329e1ff0da6fda8bbb8d603c42c6bd55626c5d89ccbaca9b13a49bc27dc", transactionIndex: "31", from: "0xcab61b858a344ad4c878c60de62b2019d3e00aed", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476911faf80ab495d33b7d30604223c60b9ad52cd674d50989105946c430730ae1cd5385f31b0948ad7de45c395ebbd9362989f3cd4772b1b8fc81faaeb41b795f1f", contractAddress: "", cumulativeGasUsed: "2731438", gasUsed: "114420", confirmations: "3240933"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x11faf80ab495d33b7d30604223c60b9ad52cd674d50989105946c430730ae1cd"}, {type: "bytes32", name: "senderPubkey", value: "0x5385f31b0948ad7de45c395ebbd9362989f3cd4772b1b8fc81faaeb41b795f1f"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x11faf80ab495d33b7d30604223c60b9ad52cd674d50989105946c430730ae1cd", "0x5385f31b0948ad7de45c395ebbd9362989f3cd4772b1b8fc81faaeb41b795f1f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509736005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xcab61b858a344ad4c878c60de62b2019d3e00aed"}, {name: "ballot", type: "bytes32", value: "0x11faf80ab495d33b7d30604223c60b9ad52cd674d50989105946c430730ae1cd"}, {name: "pubkey", type: "bytes32", value: "0x5385f31b0948ad7de45c395ebbd9362989f3cd4772b1b8fc81faaeb41b795f1f"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "6491503000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x33a5c0f36313187b43d11b9148b4af35bfae... )", async function( ) {
		const txOriginal = {blockNumber: "4484374", timeStamp: "1509738130", hash: "0x16c176259833b43cae300b86cc55b330022a631927cf1aa374e1424b12c32a5e", nonce: "4", blockHash: "0x8c75f867b03c29b0941b779603ccf8c9ef6b1432b7169fa28c907bb189ce3883", transactionIndex: "36", from: "0x550d286e78dbf0a74b99ea52bfe1703d86f98e1e", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476933a5c0f36313187b43d11b9148b4af35bfae9d76c6c5f478e39395854172336edd9e6a8097a45253af5d9ead870a2512d831e6bd3ab24f0d33848c1c1105bf68", contractAddress: "", cumulativeGasUsed: "1116447", gasUsed: "114420", confirmations: "3240773"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x33a5c0f36313187b43d11b9148b4af35bfae9d76c6c5f478e39395854172336e"}, {type: "bytes32", name: "senderPubkey", value: "0xdd9e6a8097a45253af5d9ead870a2512d831e6bd3ab24f0d33848c1c1105bf68"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x33a5c0f36313187b43d11b9148b4af35bfae9d76c6c5f478e39395854172336e", "0xdd9e6a8097a45253af5d9ead870a2512d831e6bd3ab24f0d33848c1c1105bf68", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509738130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x550d286e78dbf0a74b99ea52bfe1703d86f98e1e"}, {name: "ballot", type: "bytes32", value: "0x33a5c0f36313187b43d11b9148b4af35bfae9d76c6c5f478e39395854172336e"}, {name: "pubkey", type: "bytes32", value: "0xdd9e6a8097a45253af5d9ead870a2512d831e6bd3ab24f0d33848c1c1105bf68"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xbea577169f691341b8c8769b6d49153ff74b... )", async function( ) {
		const txOriginal = {blockNumber: "4484393", timeStamp: "1509738498", hash: "0x85ae10166ae1d3c65f4270ccbfea35a84798daa6f64568c239f13c8f4d227fe0", nonce: "4", blockHash: "0xee3afc54ad9496c8a53c23edb6a46a5ff69597602cd9ecb95fc44fcff400f130", transactionIndex: "32", from: "0x9950280174c69bd239f07a03c40bba9139c3907f", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769bea577169f691341b8c8769b6d49153ff74b99253d2e50ba12cc44a1f163ed51dc7122668ebf8da32f968cb161ab2931711c6fcde9035fa28e5c212826e15b3f", contractAddress: "", cumulativeGasUsed: "1517139", gasUsed: "114420", confirmations: "3240754"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xbea577169f691341b8c8769b6d49153ff74b99253d2e50ba12cc44a1f163ed51"}, {type: "bytes32", name: "senderPubkey", value: "0xdc7122668ebf8da32f968cb161ab2931711c6fcde9035fa28e5c212826e15b3f"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xbea577169f691341b8c8769b6d49153ff74b99253d2e50ba12cc44a1f163ed51", "0xdc7122668ebf8da32f968cb161ab2931711c6fcde9035fa28e5c212826e15b3f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509738498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x9950280174c69bd239f07a03c40bba9139c3907f"}, {name: "ballot", type: "bytes32", value: "0xbea577169f691341b8c8769b6d49153ff74b99253d2e50ba12cc44a1f163ed51"}, {name: "pubkey", type: "bytes32", value: "0xdc7122668ebf8da32f968cb161ab2931711c6fcde9035fa28e5c212826e15b3f"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "34412851000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x4ff5dc7aa75b3216a8e97a88b4d921754ea4... )", async function( ) {
		const txOriginal = {blockNumber: "4484484", timeStamp: "1509739652", hash: "0xdfb895f64a5de15ed19f84a5598352f44c52a5a350694ffb64e1d4e2e980fc65", nonce: "103", blockHash: "0xf6921354d1af547d3a098debd390e9ec7a2f6a0dff4e6b47c2f57c5dc13f2cd5", transactionIndex: "45", from: "0x6a7f63709422a986a953904c64f10d945c8afba1", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114356", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x13c047694ff5dc7aa75b3216a8e97a88b4d921754ea44ec8f74534dcec2fa76ff9afbb26cdf242e833bcabda7f7a207d14a58e281243819b003fb30a0d212ae271e71f7f", contractAddress: "", cumulativeGasUsed: "1644722", gasUsed: "114356", confirmations: "3240663"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x4ff5dc7aa75b3216a8e97a88b4d921754ea44ec8f74534dcec2fa76ff9afbb26"}, {type: "bytes32", name: "senderPubkey", value: "0xcdf242e833bcabda7f7a207d14a58e281243819b003fb30a0d212ae271e71f7f"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x4ff5dc7aa75b3216a8e97a88b4d921754ea44ec8f74534dcec2fa76ff9afbb26", "0xcdf242e833bcabda7f7a207d14a58e281243819b003fb30a0d212ae271e71f7f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509739652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x6a7f63709422a986a953904c64f10d945c8afba1"}, {name: "ballot", type: "bytes32", value: "0x4ff5dc7aa75b3216a8e97a88b4d921754ea44ec8f74534dcec2fa76ff9afbb26"}, {name: "pubkey", type: "bytes32", value: "0xcdf242e833bcabda7f7a207d14a58e281243819b003fb30a0d212ae271e71f7f"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "350572587000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xcd4607e8a77e6a99eb422ec1ac6dc3bd504d... )", async function( ) {
		const txOriginal = {blockNumber: "4484968", timeStamp: "1509746108", hash: "0x23324448c8620802c9d81dc42281ac3e9991cd614be4d478495c0a61d91620a0", nonce: "0", blockHash: "0xd1795d1b5b2c25796a5fab031667e1a2b135dae7a718879c68600ee7c4218e6e", transactionIndex: "22", from: "0x364b503b0e86b20b7ac1484c247de50f10dfd8cf", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114356", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769cd4607e8a77e6a99eb422ec1ac6dc3bd504d9df13a66bd0eacf165e9ae9aace6699cc200d30f0ae8c9cebf93d53d88e9d1dc59a45084f5755aff63f881129b45", contractAddress: "", cumulativeGasUsed: "3878261", gasUsed: "114356", confirmations: "3240179"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xcd4607e8a77e6a99eb422ec1ac6dc3bd504d9df13a66bd0eacf165e9ae9aace6"}, {type: "bytes32", name: "senderPubkey", value: "0x699cc200d30f0ae8c9cebf93d53d88e9d1dc59a45084f5755aff63f881129b45"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xcd4607e8a77e6a99eb422ec1ac6dc3bd504d9df13a66bd0eacf165e9ae9aace6", "0x699cc200d30f0ae8c9cebf93d53d88e9d1dc59a45084f5755aff63f881129b45", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509746108 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x364b503b0e86b20b7ac1484c247de50f10dfd8cf"}, {name: "ballot", type: "bytes32", value: "0xcd4607e8a77e6a99eb422ec1ac6dc3bd504d9df13a66bd0eacf165e9ae9aace6"}, {name: "pubkey", type: "bytes32", value: "0x699cc200d30f0ae8c9cebf93d53d88e9d1dc59a45084f5755aff63f881129b45"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "106940212000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x6831e358d31cfd67caea1845ef304217a6b4... )", async function( ) {
		const txOriginal = {blockNumber: "4485046", timeStamp: "1509747036", hash: "0xea821a4d84fa346b9d0ee93efa9db6ac45fd0df9e7795f5a64c8d6b039866d9b", nonce: "0", blockHash: "0x3e4babda0a6491620ce95a373afdddf62ac4fa28016eb6e768842e7952b07e42", transactionIndex: "2", from: "0x887dbacd9a0e58b46065f93cc1f82a52defdb979", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047696831e358d31cfd67caea1845ef304217a6b4b051579dfcd8a50b878cc043fa4cf933a0abb4940a9f6258bff89eaf8be510b452045e8f71eeb2db9114cf6cd316", contractAddress: "", cumulativeGasUsed: "216920", gasUsed: "114420", confirmations: "3240101"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x6831e358d31cfd67caea1845ef304217a6b4b051579dfcd8a50b878cc043fa4c"}, {type: "bytes32", name: "senderPubkey", value: "0xf933a0abb4940a9f6258bff89eaf8be510b452045e8f71eeb2db9114cf6cd316"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x6831e358d31cfd67caea1845ef304217a6b4b051579dfcd8a50b878cc043fa4c", "0xf933a0abb4940a9f6258bff89eaf8be510b452045e8f71eeb2db9114cf6cd316", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509747036 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0x887dbacd9a0e58b46065f93cc1f82a52defdb979"}, {name: "ballot", type: "bytes32", value: "0x6831e358d31cfd67caea1845ef304217a6b4b051579dfcd8a50b878cc043fa4c"}, {name: "pubkey", type: "bytes32", value: "0xf933a0abb4940a9f6258bff89eaf8be510b452045e8f71eeb2db9114cf6cd316"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "44088113401407795" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x6301a0330894dddca13e635bbfa4334f45fc... )", async function( ) {
		const txOriginal = {blockNumber: "4485064", timeStamp: "1509747329", hash: "0x5dba1056baf9858b2e4a9f403291b217652a4c467a447b1e86ef9b86f9bb26fb", nonce: "0", blockHash: "0x5b0d711af669a6a8ffed4c61ded3d0938183dd6eb3c604f412fd20fac21d30d0", transactionIndex: "7", from: "0xf66fe29ad1e87104a8816ad1a8427976d83cb033", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c047696301a0330894dddca13e635bbfa4334f45fc6511f80a9f8202375e5e5a676c70892e8381451b64addfbef0a9314a1c7b180d41f82676abb8790aca6238889944", contractAddress: "", cumulativeGasUsed: "381500", gasUsed: "114420", confirmations: "3240083"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x6301a0330894dddca13e635bbfa4334f45fc6511f80a9f8202375e5e5a676c70"}, {type: "bytes32", name: "senderPubkey", value: "0x892e8381451b64addfbef0a9314a1c7b180d41f82676abb8790aca6238889944"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x6301a0330894dddca13e635bbfa4334f45fc6511f80a9f8202375e5e5a676c70", "0x892e8381451b64addfbef0a9314a1c7b180d41f82676abb8790aca6238889944", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509747329 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xf66fe29ad1e87104a8816ad1a8427976d83cb033"}, {name: "ballot", type: "bytes32", value: "0x6301a0330894dddca13e635bbfa4334f45fc6511f80a9f8202375e5e5a676c70"}, {name: "pubkey", type: "bytes32", value: "0x892e8381451b64addfbef0a9314a1c7b180d41f82676abb8790aca6238889944"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "116938868000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x743c896fa93d8f405bab9e86e37b71f9d0c4... )", async function( ) {
		const txOriginal = {blockNumber: "4485070", timeStamp: "1509747444", hash: "0x8108272ddcf0a5d0e6ba7146f0e94ee4d6a5132cfde324d678ddf66f7bad95e2", nonce: "0", blockHash: "0xdf1a0d26ccc20783556a334500a61e979dc7872670b3e1edf4fd101d8bbd336e", transactionIndex: "14", from: "0xe223771699665bcb0aaf7930277c35d3dec573af", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769743c896fa93d8f405bab9e86e37b71f9d0c413530d8079c88cccb18808c9b3d0cdd7739fb4db7b6c1934a2995ec63a26b1117d80e8f65efddf4075a391f0ce09", contractAddress: "", cumulativeGasUsed: "505846", gasUsed: "114420", confirmations: "3240077"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x743c896fa93d8f405bab9e86e37b71f9d0c413530d8079c88cccb18808c9b3d0"}, {type: "bytes32", name: "senderPubkey", value: "0xcdd7739fb4db7b6c1934a2995ec63a26b1117d80e8f65efddf4075a391f0ce09"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x743c896fa93d8f405bab9e86e37b71f9d0c413530d8079c88cccb18808c9b3d0", "0xcdd7739fb4db7b6c1934a2995ec63a26b1117d80e8f65efddf4075a391f0ce09", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509747444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xe223771699665bcb0aaf7930277c35d3dec573af"}, {name: "ballot", type: "bytes32", value: "0x743c896fa93d8f405bab9e86e37b71f9d0c413530d8079c88cccb18808c9b3d0"}, {name: "pubkey", type: "bytes32", value: "0xcdd7739fb4db7b6c1934a2995ec63a26b1117d80e8f65efddf4075a391f0ce09"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "16938868000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0xf6dbf4e4886f358c4637946f8c86f38b8ac5... )", async function( ) {
		const txOriginal = {blockNumber: "4485080", timeStamp: "1509747575", hash: "0xa62114df7a671012ea951fd5319c9c444f18da6d18c65da85b01bd70e7a8d9c5", nonce: "0", blockHash: "0x808c147eb278f43a7a2ccb3ca5b12e2ed4cb1c8e4bad5ade6a085957a80eff07", transactionIndex: "18", from: "0xb6dc48e8583c8c6e320daf918cadef65f2d85b46", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114420", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c04769f6dbf4e4886f358c4637946f8c86f38b8ac5ba4b8b886acbd16f402f317b5bda0c9474225e6e6fb39efd52dc92d0c6619f3801932970f486e2d5ccc7a1ca3174", contractAddress: "", cumulativeGasUsed: "526215", gasUsed: "114420", confirmations: "3240067"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[51], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0xf6dbf4e4886f358c4637946f8c86f38b8ac5ba4b8b886acbd16f402f317b5bda"}, {type: "bytes32", name: "senderPubkey", value: "0x0c9474225e6e6fb39efd52dc92d0c6619f3801932970f486e2d5ccc7a1ca3174"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0xf6dbf4e4886f358c4637946f8c86f38b8ac5ba4b8b886acbd16f402f317b5bda", "0x0c9474225e6e6fb39efd52dc92d0c6619f3801932970f486e2d5ccc7a1ca3174", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509747575 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xb6dc48e8583c8c6e320daf918cadef65f2d85b46"}, {name: "ballot", type: "bytes32", value: "0xf6dbf4e4886f358c4637946f8c86f38b8ac5ba4b8b886acbd16f402f317b5bda"}, {name: "pubkey", type: "bytes32", value: "0x0c9474225e6e6fb39efd52dc92d0c6619f3801932970f486e2d5ccc7a1ca3174"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[51], balance: "16938868000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[51], balance: ( await web3.eth.getBalance( addressList[51], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: submitBallot( \"0x21fab5b91e0051c159634e3da56f1ab304aa... )", async function( ) {
		const txOriginal = {blockNumber: "4485091", timeStamp: "1509747681", hash: "0xd65fbd2530fcb60a9535006ac96c3188e181fe2a0e973e4d6919662987028849", nonce: "0", blockHash: "0xa2dba1af6bfcc06017dad01f7c599a01cd7ff969a3546ace624b8fc1e04cfefa", transactionIndex: "3", from: "0xf02d417c8c6736dbc7eb089dc6738b950c2f444e", to: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f", value: "0", gas: "114356", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x13c0476921fab5b91e0051c159634e3da56f1ab304aa882ad188fa4f81fce75f717b81ee2f797d69414b366941fcb812905fe773e41634552f5eb94df1e346121a2f9922", contractAddress: "", cumulativeGasUsed: "182493", gasUsed: "114356", confirmations: "3240056"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[52], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "encryptedBallot", value: "0x21fab5b91e0051c159634e3da56f1ab304aa882ad188fa4f81fce75f717b81ee"}, {type: "bytes32", name: "senderPubkey", value: "0x2f797d69414b366941fcb812905fe773e41634552f5eb94df1e346121a2f9922"}], name: "submitBallot", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitBallot(bytes32,bytes32)" ]( "0x21fab5b91e0051c159634e3da56f1ab304aa882ad188fa4f81fce75f717b81ee", "0x2f797d69414b366941fcb812905fe773e41634552f5eb94df1e346121a2f9922", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509747681 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "voter", type: "address"}, {indexed: false, name: "ballot", type: "bytes32"}, {indexed: false, name: "pubkey", type: "bytes32"}], name: "SuccessfulVote", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SuccessfulVote", events: [{name: "voter", type: "address", value: "0xf02d417c8c6736dbc7eb089dc6738b950c2f444e"}, {name: "ballot", type: "bytes32", value: "0x21fab5b91e0051c159634e3da56f1ab304aa882ad188fa4f81fce75f717b81ee"}, {name: "pubkey", type: "bytes32", value: "0x2f797d69414b366941fcb812905fe773e41634552f5eb94df1e346121a2f9922"}], address: "0x2bb10945e9f0c9483022dc473ab4951bc2a77d0f"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[52], balance: "16940212000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[52], balance: ( await web3.eth.getBalance( addressList[52], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
